
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.IOException;
import java.net.URI;

public class AzureDirectoryDeleter {

    public static void deleteDirectory(String azurePath, Configuration hadoopConf) throws IOException {
        FileSystem fs = FileSystem.get(URI.create(azurePath), hadoopConf);
        Path path = new Path(azurePath);

        if (fs.exists(path)) {
            boolean deleted = fs.delete(path, true); // true = recursive delete
            if (deleted) {
                System.out.println("Répertoire supprimé avec succès : " + azurePath);
            } else {
                System.out.println("Échec de suppression du répertoire : " + azurePath);
            }
        } else {
            System.out.println("Le répertoire n'existe pas : " + azurePath);
        }
    }

    public static void main(String[] args) throws Exception {
        // Exemple d'utilisation
        String azureDirectory = "abfs://container@account.dfs.core.windows.net/chemin/vers/dossier";

        Configuration conf = new Configuration();
        conf.set("fs.azure.account.auth.type.account.dfs.core.windows.net", "OAuth");
        conf.set("fs.azure.account.oauth.provider.type.account.dfs.core.windows.net",
                "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
        conf.set("fs.azure.account.oauth2.client.id.account.dfs.core.windows.net", "TON_CLIENT_ID");
        conf.set("fs.azure.account.oauth2.client.secret.account.dfs.core.windows.net", "TON_SECRET");
        conf.set("fs.azure.account.oauth2.client.endpoint.account.dfs.core.windows.net",
                "https://login.microsoftonline.com/TON_TENANT_ID/oauth2/token");

        deleteDirectory(azureDirectory, conf);
    }
}
