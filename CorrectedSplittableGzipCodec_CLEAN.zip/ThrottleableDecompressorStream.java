
import java.io.IOException;
import java.io.InputStream;

import org.apache.hadoop.io.compress.Decompressor;
import org.apache.hadoop.io.compress.DecompressorStream;

public class ThrottleableDecompressorStream extends DecompressorStream {

  private int readStep = 0;
  private long totalBytesRead = 0;

  public ThrottleableDecompressorStream(final InputStream in, final Decompressor decompressor, final int bufferSize)
      throws IOException {
    super(in, decompressor, bufferSize);
    setReadStep(65536); // Set safe default step
  }

  public ThrottleableDecompressorStream(final InputStream in, final Decompressor decompressor) throws IOException {
    this(in, decompressor, 65536);
  }

  public final int setReadStep(final int newReadStep) {
    if (buffer == null || buffer.length < 8) {
      readStep = 65536; // fallback
    } else if (newReadStep <= 0 || newReadStep >= buffer.length) {
      readStep = buffer.length;
    } else {
      readStep = newReadStep;
    }
    return readStep;
  }

  @Override
  protected int getCompressedData() throws IOException {
    checkStream();
    if (readStep <= 0 || buffer == null || buffer.length == 0) {
      throw new IOException("Invalid readStep or buffer state");
    }

    final int bytesRead = in.read(buffer, 0, readStep);
    if (bytesRead == -1) {
      System.err.println("End of stream reached in getCompressedData");
      return -1;
    }

    totalBytesRead += bytesRead;
    return bytesRead;
  }

  public long getBytesRead() {
    return totalBytesRead;
  }
}
