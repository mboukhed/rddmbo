
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.SparkSession;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.util.Arrays;

public class CsvUploader {

    public static void main(String[] args) throws IOException {

        // Configuration Azure ADLS
        Configuration hadoopConf = new Configuration();
        hadoopConf.set("fs.azure.account.auth.type.account.dfs.core.windows.net", "OAuth");
        hadoopConf.set("fs.azure.account.oauth.provider.type.account.dfs.core.windows.net",
                "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
        hadoopConf.set("fs.azure.account.oauth2.client.id.account.dfs.core.windows.net", "<client-id>");
        hadoopConf.set("fs.azure.account.oauth2.client.secret.account.dfs.core.windows.net", "<client-secret>");
        hadoopConf.set("fs.azure.account.oauth2.client.endpoint.account.dfs.core.windows.net",
                "https://login.microsoftonline.com/<tenant-id>/oauth2/token");

        // Système de fichiers Azure
        String azureUri = "abfss://<container>@<account>.dfs.core.windows.net/";
        FileSystem fs = FileSystem.get(URI.create(azureUri), hadoopConf);

        // Répertoire local contenant les CSV
        File localDir = new File("C:/temp");

        // Parcours et copie
        Arrays.stream(localDir.listFiles((dir, name) -> name.toLowerCase().endsWith(".csv")))
                .forEach(file -> {
                    try {
                        Path srcPath = new Path(file.getAbsolutePath());
                        Path destPath = new Path(azureUri + "dossier-cible/" + file.getName());
                        System.out.println("Copying: " + srcPath + " -> " + destPath);
                        fs.copyFromLocalFile(false, true, srcPath, destPath);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });

        fs.close();
    }
}
