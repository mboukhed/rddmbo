@Component
public class CucumberHooks {
    // ... Le code complet est inséré ici
}