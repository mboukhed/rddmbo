
// Fichier: CucumberHooks.java
// Ce fichier contient deux versions : reset complet par réflexion pure, et version simplifiée.

import io.cucumber.java.After;
import org.springframework.context.ApplicationContext;

import java.io.File;
import java.lang.reflect.*;
import java.net.URL;
import java.util.*;
import java.util.concurrent.atomic.*;

public class CucumberHooks {

    @After
    public void resetAfterScenario() {
        ApplicationContext context = getApplicationContext();

        if (context != null) {
            resetAllBeansByReflection(context);
            resetAllStaticFieldsByReflection();
            clearAllCachesByReflection();
        }
    }

    private ApplicationContext getApplicationContext() {
        return YourMainClass.getApplicationContext();
    }

    private void resetAllBeansByReflection(ApplicationContext context) {
        String[] beanNames = context.getBeanDefinitionNames();

        for (String beanName : beanNames) {
            try {
                Object bean = context.getBean(beanName);
                resetBeanCompletely(bean);
            } catch (Exception ignored) {}
        }
    }

    private void resetBeanCompletely(Object bean) {
        Class<?> clazz = bean.getClass();
        while (clazz != null && clazz != Object.class) {
            for (Field field : clazz.getDeclaredFields()) {
                if (shouldResetField(field)) {
                    resetFieldValue(field, bean);
                }
            }
            clazz = clazz.getSuperclass();
        }
    }

    private boolean shouldResetField(Field field) {
        int modifiers = field.getModifiers();
        return !Modifier.isStatic(modifiers) && !Modifier.isFinal(modifiers) && !field.getName().startsWith("$");
    }

    private void resetFieldValue(Field field, Object bean) {
        try {
            field.setAccessible(true);
            Object value = field.get(bean);
            if (value == null) return;
            Class<?> type = field.getType();

            if (value instanceof Collection) ((Collection<?>) value).clear();
            else if (value instanceof Map) ((Map<?, ?>) value).clear();
            else if (type.isArray()) resetArray(field, bean, type);
            else if (value instanceof AtomicInteger) ((AtomicInteger) value).set(0);
            else if (value instanceof AtomicLong) ((AtomicLong) value).set(0L);
            else if (value instanceof AtomicBoolean) ((AtomicBoolean) value).set(false);
            else if (type.isPrimitive()) setDefaultPrimitiveValue(field, bean, type);
            else if (isWrapperType(type) || type == String.class) field.set(bean, null);
            else if (value instanceof StringBuilder) ((StringBuilder) value).setLength(0);
            else if (value instanceof StringBuffer) ((StringBuffer) value).setLength(0);
            else if (isCustomObject(type)) field.set(bean, null);
        } catch (Exception ignored) {}
    }

    private void resetArray(Field field, Object bean, Class<?> type) throws IllegalAccessException {
        Class<?> componentType = type.getComponentType();
        Object newArray = componentType.isPrimitive() ? Array.newInstance(componentType, 0) : null;
        field.set(bean, newArray);
    }

    private void setDefaultPrimitiveValue(Field field, Object bean, Class<?> type) throws IllegalAccessException {
        if (type == int.class) field.setInt(bean, 0);
        else if (type == long.class) field.setLong(bean, 0L);
        else if (type == boolean.class) field.setBoolean(bean, false);
        else if (type == double.class) field.setDouble(bean, 0.0);
        else if (type == float.class) field.setFloat(bean, 0.0f);
        else if (type == short.class) field.setShort(bean, (short) 0);
        else if (type == byte.class) field.setByte(bean, (byte) 0);
        else if (type == char.class) field.setChar(bean, '\0');
    }

    private boolean isWrapperType(Class<?> type) {
        return Set.of(Integer.class, Long.class, Boolean.class, Double.class, Float.class,
                Short.class, Byte.class, Character.class).contains(type);
    }

    private boolean isCustomObject(Class<?> type) {
        return !type.isPrimitive() && !isWrapperType(type) &&
               type != String.class && !type.getName().startsWith("java.") &&
               !type.getName().startsWith("javax.") && !type.getName().startsWith("org.springframework.");
    }

    private void resetAllStaticFieldsByReflection() {
        String[] packagesToScan = { "com.yourpackage", "com.yourcompany" };
        for (String pkg : packagesToScan) resetStaticFieldsInPackage(pkg);
    }

    private void resetStaticFieldsInPackage(String pkg) {
        try {
            ClassLoader cl = Thread.currentThread().getContextClassLoader();
            URL resource = cl.getResource(pkg.replace('.', '/'));
            if (resource != null) {
                File dir = new File(resource.getFile());
                if (dir.exists()) scanDirectory(dir, pkg);
            }
        } catch (Exception ignored) {}
    }

    private void scanDirectory(File dir, String pkg) {
        File[] files = dir.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) scanDirectory(f, pkg + "." + f.getName());
                else if (f.getName().endsWith(".class")) {
                    String className = pkg + "." + f.getName().replaceAll(".class$", "");
                    resetStaticFieldsInClass(className);
                }
            }
        }
    }

    private void resetStaticFieldsInClass(String className) {
        try {
            Class<?> clazz = Class.forName(className);
            for (Field field : clazz.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers()) && !Modifier.isFinal(field.getModifiers()) &&
                    !field.getName().startsWith("$")) {
                    resetStaticField(field);
                }
            }
        } catch (Exception ignored) {}
    }

    private void resetStaticField(Field field) {
        try {
            field.setAccessible(true);
            Object value = field.get(null);
            if (value == null) return;
            Class<?> type = field.getType();

            if (value instanceof Collection) ((Collection<?>) value).clear();
            else if (value instanceof Map) ((Map<?, ?>) value).clear();
            else if (value instanceof AtomicInteger) ((AtomicInteger) value).set(0);
            else if (value instanceof AtomicLong) ((AtomicLong) value).set(0L);
            else if (value instanceof AtomicBoolean) ((AtomicBoolean) value).set(false);
            else if (type.isPrimitive()) setDefaultStaticPrimitiveValue(field, type);
            else if (isCustomObject(type)) field.set(null, null);
        } catch (Exception ignored) {}
    }

    private void setDefaultStaticPrimitiveValue(Field field, Class<?> type) throws IllegalAccessException {
        if (type == int.class) field.setInt(null, 0);
        else if (type == long.class) field.setLong(null, 0L);
        else if (type == boolean.class) field.setBoolean(null, false);
        else if (type == double.class) field.setDouble(null, 0.0);
        else if (type == float.class) field.setFloat(null, 0.0f);
        else if (type == short.class) field.setShort(null, (short) 0);
        else if (type == byte.class) field.setByte(null, (byte) 0);
        else if (type == char.class) field.setChar(null, '\0');
    }

    private void clearAllCachesByReflection() {
        ApplicationContext context = getApplicationContext();
        for (String beanName : context.getBeanDefinitionNames()) {
            try {
                Object bean = context.getBean(beanName);
                clearBeanCaches(bean);
            } catch (Exception ignored) {}
        }
    }

    private void clearBeanCaches(Object bean) {
        for (Method method : bean.getClass().getDeclaredMethods()) {
            String name = method.getName().toLowerCase();
            if (method.getParameterCount() == 0 && 
               (name.contains("clear") || name.contains("reset") ||
                name.contains("evict") || name.contains("flush"))) {
                try {
                    method.setAccessible(true);
                    method.invoke(bean);
                } catch (Exception ignored) {}
            }
        }
    }
}
