
// Fichier: CucumberHooks.java
// Ce fichier contient deux versions : reset complet par réflexion pure, et version simplifiée.

(Ton code complet ici, collé sans coupure pour format propre.)
