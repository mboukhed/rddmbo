
package com.example;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class TypeConverter {

    private static final List<DateTimeFormatter> DATE_FORMATTERS = Arrays.asList(
        DateTimeFormatter.ISO_LOCAL_DATE_TIME,
        DateTimeFormatter.ISO_LOCAL_DATE,
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"),
        DateTimeFormatter.ofPattern("dd/MM/yyyy"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd")
    );

    @SuppressWarnings("unchecked")
    public static <T> T forceConvert(Object value, Class<T> targetClass) {
        if (value == null) return null;

        if (targetClass.isInstance(value)) {
            return (T) value;
        }

        try {
            String str = value.toString().trim();

            if (targetClass == Integer.class) return (T) Integer.valueOf(str);
            if (targetClass == Long.class) return (T) Long.valueOf(str);
            if (targetClass == Double.class) return (T) Double.valueOf(str);
            if (targetClass == Float.class) return (T) Float.valueOf(str);
            if (targetClass == Boolean.class) return (T) Boolean.valueOf(str);
            if (targetClass == String.class) return (T) str;

            Long epochMillis = null;
            if (value instanceof Number) {
                epochMillis = ((Number) value).longValue();
            } else if (str.matches("^\d{10,17}$")) {
                epochMillis = Long.parseLong(str);
            }

            if (epochMillis != null) {
                if (epochMillis < 100000000000L) {
                    epochMillis *= 1000;
                }
                Instant instant = Instant.ofEpochMilli(epochMillis);
                if (targetClass == Date.class) {
                    return (T) Date.from(instant);
                } else if (targetClass == LocalDateTime.class) {
                    return (T) LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
                } else if (targetClass == LocalDate.class) {
                    return (T) LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
                }
            }

            for (DateTimeFormatter formatter : DATE_FORMATTERS) {
                try {
                    if (targetClass == LocalDate.class) {
                        return (T) LocalDate.parse(str, formatter);
                    } else if (targetClass == LocalDateTime.class) {
                        return (T) LocalDateTime.parse(str, formatter);
                    } else if (targetClass == Date.class) {
                        LocalDateTime ldt;
                        try {
                            ldt = LocalDateTime.parse(str, formatter);
                        } catch (DateTimeParseException e) {
                            ldt = LocalDate.parse(str, formatter).atStartOfDay();
                        }
                        return (T) Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
                    }
                } catch (DateTimeParseException e) {
                    // Continue to next format
                }
            }

        } catch (Exception e) {
            // Ignore
        }

        return null;
    }
}
