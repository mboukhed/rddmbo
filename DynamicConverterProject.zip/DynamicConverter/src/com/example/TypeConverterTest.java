
package com.example;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class TypeConverterTest {

    public static void main(String[] args) {
        test("String to Integer", "123", Integer.class);
        test("String to Double", "123.45", Double.class);
        test("String to Boolean (true)", "true", Boolean.class);
        test("String to Boolean (false)", "false", Boolean.class);
        test("String to LocalDate", "2024-06-03", LocalDate.class);
        test("String to LocalDate (fr)", "03/06/2024", LocalDate.class);
        test("String to LocalDateTime", "2024-06-03T13:30:00", LocalDateTime.class);
        test("String to Date", "2024-06-03 13:30", Date.class);
        test("Timestamp (Long sec) to Date", 1717412400L, Date.class);
        test("Timestamp (Long ms) to LocalDate", 1717412400000L, LocalDate.class);
        test("Timestamp String (sec) to LocalDateTime", "1717412400", LocalDateTime.class);
        test("Timestamp String (ms) to Date", "1717412400000", Date.class);
        test("Double to Integer", 123.99, Integer.class);
        test("String to Float", "1.23", Float.class);
        test("Long to String", 123456789L, String.class);
        test("Invalid String to Integer", "abc", Integer.class);
        test("String date invalid", "31-13-2024", LocalDate.class);
    }

    private static <T> void test(String label, Object input, Class<T> targetClass) {
        T result = TypeConverter.forceConvert(input, targetClass);
        System.out.printf("%-40s | %-20s -> %-20s => %s%n",
                label, input + " (" + input.getClass().getSimpleName() + ")",
                targetClass.getSimpleName(),
                (result != null ? result + " ✅" : "null ❌"));
    }
}
