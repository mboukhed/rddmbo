
package com.example;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.StructField;

import java.io.Serializable;
import java.util.*;

public class ParquetDynamicReader {

    public static <T> List<T> readParquetWithDynamicConversion(SparkSession spark, String path, Class<T> targetClass, RowMapper<T> mapper) {
        Dataset<Row> df = spark.read().option("mergeSchema", "true").parquet(path);
        List<Row> rows = df.collectAsList();
        List<T> result = new ArrayList<>();

        for (Row row : rows) {
            Map<String, Object> rawMap = new HashMap<>();
            StructField[] fields = row.schema().fields();
            for (int i = 0; i < fields.length; i++) {
                String name = fields[i].name();
                Object value = row.get(i);
                rawMap.put(name, value);
            }
            T obj = mapper.map(rawMap, targetClass);
            result.add(obj);
        }

        return result;
    }

    public interface RowMapper<T> extends Serializable {
        T map(Map<String, Object> rowData, Class<T> targetClass);
    }
}
