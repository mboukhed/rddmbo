
package com.example;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.spark.sql.SparkSession;

import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

public class ParquetReaderSteps {

    SparkSession spark;
    List<TestData> result;

    @Given("a parquet file at path {string}")
    public void a_parquet_file_at_path(String path) {
        spark = SparkSession.builder().appName("Test").master("local[*]").getOrCreate();
        result = ParquetDynamicReader.readParquetWithDynamicConversion(spark, path, TestData.class, (rowData, cls) -> {
            TestData td = new TestData();
            td.setId(TypeConverter.forceConvert(rowData.get("id"), Integer.class));
            td.setName(TypeConverter.forceConvert(rowData.get("name"), String.class));
            td.setCreatedAt(TypeConverter.forceConvert(rowData.get("createdAt"), java.time.LocalDateTime.class));
            return td;
        });
    }

    @Then("data should be loaded and mapped")
    public void data_should_be_loaded_and_mapped() {
        assertNotNull(result);
        assert(!result.isEmpty());
    }
}
