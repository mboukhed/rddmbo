package it.steps;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.connector.catalog.Identifier;
import org.apache.spark.sql.connector.catalog.SupportsDeleteV2;
import org.apache.spark.sql.connector.catalog.SupportsNamespaces;
import org.apache.spark.sql.connector.catalog.SupportsWrite;
import org.apache.spark.sql.connector.catalog.Table;
import org.apache.spark.sql.connector.catalog.TableCatalog;
import org.apache.spark.sql.connector.catalog.TableCapability;
import org.apache.spark.sql.connector.expressions.Transform;
import org.apache.spark.sql.connector.write.BatchWrite;
import org.apache.spark.sql.connector.write.DataWriterFactory;
import org.apache.spark.sql.connector.write.LogicalWriteInfo;
import org.apache.spark.sql.connector.write.PhysicalWriteInfo;
import org.apache.spark.sql.connector.write.WriteBuilder;
import org.apache.spark.sql.connector.write.WriterCommitMessage;
import org.apache.spark.sql.sources.EqualTo;
import org.apache.spark.sql.sources.Filter;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.sql.util.CaseInsensitiveStringMap;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class FakeClickHouseCatalog implements TableCatalog, SupportsNamespaces {

    private String catalogName;
    private String warehouse;
    private SparkSession spark;

    @Override
    public void initialize(String name, CaseInsensitiveStringMap options) {
        this.catalogName = name;
        this.warehouse = options.getOrDefault("warehouse", "src/test/resources/data/clickhouse");
        this.spark = SparkSession.active();
    }

    @Override
    public String name() {
        return catalogName;
    }

    private String tableKey(Identifier ident) {
        String namespace = ident.namespace() == null || ident.namespace().length == 0
                ? "default"
                : String.join(".", ident.namespace());
        return namespace + "." + ident.name();
    }

    private String tablePath(Identifier ident) {
        return warehouse + "/" + tableKey(ident);
    }

    private static void deleteRecursively(File file) {
        if (file == null || !file.exists()) {
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursively(child);
                }
            }
        }
        if (!file.delete()) {
            throw new RuntimeException("Unable to delete: " + file.getAbsolutePath());
        }
    }

    @Override
    public Table loadTable(Identifier ident) {
        String path = tablePath(ident);
        if (!new File(path).exists()) {
            throw new RuntimeException("Table not found: " + ident);
        }
        return new ParquetBackedTable(ident, path);
    }

    @Override
    public Identifier[] listTables(String[] namespace) {
        File nsDir = new File(warehouse);
        if (!nsDir.exists() || !nsDir.isDirectory()) {
            return new Identifier[0];
        }

        List<Identifier> tables = new ArrayList<>();
        String ns = (namespace == null || namespace.length == 0) ? "default" : String.join(".", namespace);

        File[] children = nsDir.listFiles();
        if (children == null) {
            return new Identifier[0];
        }

        String prefix = ns + ".";
        for (File child : children) {
            if (child.isDirectory() && child.getName().startsWith(prefix)) {
                String tableName = child.getName().substring(prefix.length());
                tables.add(Identifier.of(namespace == null || namespace.length == 0 ? new String[]{"default"} : namespace, tableName));
            }
        }

        return tables.toArray(new Identifier[0]);
    }

    @Override
    public Table createTable(
            Identifier ident,
            StructType schema,
            Transform[] partitions,
            Map<String, String> properties
    ) {
        String path = tablePath(ident);
        File dir = new File(path);
        if (dir.exists()) {
            throw new RuntimeException("Table already exists: " + ident);
        }

        spark.createDataFrame(new ArrayList<Row>(), schema)
                .write()
                .mode(SaveMode.Overwrite)
                .parquet(path);

        return loadTable(ident);
    }

    @Override
    public boolean tableExists(Identifier ident) {
        return new File(tablePath(ident)).exists();
    }

    @Override
    public boolean dropTable(Identifier ident) {
        File dir = new File(tablePath(ident));
        if (!dir.exists()) {
            return false;
        }
        deleteRecursively(dir);
        return true;
    }

    @Override
    public void renameTable(Identifier oldIdent, Identifier newIdent) {
        File oldDir = new File(tablePath(oldIdent));
        File newDir = new File(tablePath(newIdent));

        if (!oldDir.exists()) {
            throw new RuntimeException("Table not found: " + oldIdent);
        }
        if (newDir.exists()) {
            throw new RuntimeException("Target table already exists: " + newIdent);
        }
        File parent = newDir.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new RuntimeException("Unable to create directory: " + parent.getAbsolutePath());
        }
        if (!oldDir.renameTo(newDir)) {
            throw new RuntimeException("Unable to rename table " + oldIdent + " to " + newIdent);
        }
    }

    @Override
    public String[][] listNamespaces() {
        return new String[][] { new String[] { "default" } };
    }

    @Override
    public String[][] listNamespaces(String[] namespace) {
        return new String[0][];
    }

    @Override
    public boolean namespaceExists(String[] namespace) {
        return true;
    }

    @Override
    public Map<String, String> loadNamespaceMetadata(String[] namespace) {
        return Map.of();
    }

    @Override
    public void createNamespace(String[] namespace, Map<String, String> metadata) {
        // no-op
    }

    @Override
    public boolean dropNamespace(String[] namespace, boolean cascade) {
        return false;
    }

    @Override
    public String[] defaultNamespace() {
        return new String[] { "default" };
    }

    private final class ParquetBackedTable implements Table, SupportsWrite, SupportsDeleteV2 {

        private final Identifier ident;
        private final String path;

        private ParquetBackedTable(Identifier ident, String path) {
            this.ident = ident;
            this.path = path;
        }

        @Override
        public String name() {
            return tableKey(ident);
        }

        @Override
        public StructType schema() {
            return spark.read().parquet(path).schema();
        }

        @Override
        public Set<TableCapability> capabilities() {
            return Set.of(
                    TableCapability.BATCH_READ,
                    TableCapability.BATCH_WRITE,
                    TableCapability.TRUNCATE,
                    TableCapability.OVERWRITE_BY_FILTER
            );
        }

        @Override
        public WriteBuilder newWriteBuilder(LogicalWriteInfo info) {
            return new WriteBuilder() {

                @Override
                public WriteBuilder truncate() {
                    return this;
                }

                @Override
                public WriteBuilder overwrite(Filter[] filters) {
                    return this;
                }

                @Override
                public BatchWrite buildForBatch() {
                    return new BatchWrite() {
                        @Override
                        public DataWriterFactory createBatchWriterFactory(PhysicalWriteInfo info) {
                            return null;
                        }

                        @Override
                        public void commit(WriterCommitMessage[] messages) {
                            // no-op
                        }

                        @Override
                        public void abort(WriterCommitMessage[] messages) {
                            // no-op
                        }
                    };
                }
            };
        }

        @Override
        public boolean canDeleteWhere(Filter[] filters) {
            return filters != null
                    && filters.length == 1
                    && filters[0] instanceof EqualTo;
        }

        @Override
        public void deleteWhere(Filter[] filters) {
            if (filters == null || filters.length != 1) {
                throw new UnsupportedOperationException("Only single EqualTo filter is supported");
            }

            Filter filter = filters[0];
            if (!(filter instanceof EqualTo)) {
                throw new UnsupportedOperationException("Only EqualTo filter is supported");
            }

            EqualTo eq = (EqualTo) filter;

            String column = eq.attribute();
            Object value = eq.value();

            Dataset<Row> df = spark.read().parquet(path);
            df.createOrReplaceTempView("tmp_fake_clickhouse_delete");

            String condition;
            if (value == null) {
                condition = "`" + column + "` IS NULL";
            } else if (value instanceof Number || value instanceof Boolean) {
                condition = "`" + column + "` = " + value;
            } else {
                String escaped = value.toString().replace("'", "''");
                condition = "`" + column + "` = '" + escaped + "'";
            }

            spark.sql("SELECT * FROM tmp_fake_clickhouse_delete WHERE NOT (" + condition + ")")
                    .write()
                    .mode(SaveMode.Overwrite)
                    .parquet(path);

            spark.catalog().dropTempView("tmp_fake_clickhouse_delete");
        }
    }
}
