
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class FileDateFilter {

    private static final Logger logger = Logger.getLogger(FileDateFilter.class.getName());

    public static Map<java.sql.Date, String> filterFilesByDate(List<String> filePaths, LocalDate inputDate, boolean trueHHMMSS) {
        if (inputDate == null) {
            inputDate = LocalDate.now();
        }

        SimpleDateFormat fileDateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        return filePaths.parallelStream()
                .map(path -> {
                    try {
                        String filename = extractFilename(path);
                        String datePart = filename.substring(0, 14);
                        Date parsedDate = fileDateFormat.parse(datePart);

                        if (trueHHMMSS) {
                            LocalDateTime fileDateTime = parsedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
                            if (fileDateTime.toLocalDate().isEqual(inputDate)) {
                                return new AbstractMap.SimpleEntry<>(java.sql.Date.valueOf(fileDateTime.toLocalDate()), path);
                            }
                        } else {
                            LocalDate fileLocalDate = parsedDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
                            if (fileLocalDate.isEqual(inputDate)) {
                                return new AbstractMap.SimpleEntry<>(java.sql.Date.valueOf(fileLocalDate), path);
                            }
                        }
                    } catch (ParseException | StringIndexOutOfBoundsException e) {
                        logger.log(Level.WARNING, "Fichier mal formé ignoré: " + path, e);
                    }
                    return null;
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (v1, v2) -> v1));
    }

    private static String extractFilename(String path) {
        int lastSlash = path.lastIndexOf("/");
        if (lastSlash != -1) {
            return path.substring(lastSlash + 1);
        }
        return path;
    }
}
