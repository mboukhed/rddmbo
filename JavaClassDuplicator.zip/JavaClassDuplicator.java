
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class JavaClassDuplicator {

    public static void main(String[] args) {
        // Remplace ce chemin par celui de ta classe à dupliquer
        String originalFilePath = "src/main/java/com/example/MyClass.java";

        try {
            Path originalPath = Paths.get(originalFilePath);
            if (!Files.exists(originalPath)) {
                System.err.println("Fichier non trouvé: " + originalFilePath);
                return;
            }

            // Lire le contenu de la classe
            String content = Files.readString(originalPath);

            // Créer un nouveau nom avec "_copy"
            String fileName = originalPath.getFileName().toString(); // ex: MyClass.java
            String baseName = fileName.substring(0, fileName.lastIndexOf('.'));
            String newFileName = baseName + "_copy.java";

            Path newPath = originalPath.getParent().resolve(newFileName);

            // Écrire le contenu dans le nouveau fichier
            Files.writeString(newPath, content);

            System.out.println("Copie créée : " + newPath.toAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
