
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class JavaClassDuplicator {

    public static void main(String[] args) {
        // Remplace ce chemin par celui de ta classe à dupliquer
        String originalFilePath = "src/main/java/com/example/MyClass.java";

        try {
            Path originalPath = Paths.get(originalFilePath);
            if (!Files.exists(originalPath)) {
                System.err.println("Fichier non trouvé: " + originalFilePath);
                return;
            }

            // Lire les lignes de la classe
            List<String> lines = Files.readAllLines(originalPath);

            // Modifier les lignes si besoin (exemple : supprimer les lignes vides)
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                // Exemple : convertir en minuscule tout le contenu (ou toute autre logique)
                lines.set(i, line.toLowerCase());
            }

            // Créer un nouveau nom avec "_copy"
            String fileName = originalPath.getFileName().toString();
            String baseName = fileName.substring(0, fileName.lastIndexOf('.'));
            String newFileName = baseName + "_copy.java";

            Path newPath = originalPath.getParent().resolve(newFileName);

            // Écrire les lignes modifiées dans le nouveau fichier
            Files.write(newPath, lines);

            System.out.println("Copie modifiée créée : " + newPath.toAbsolutePath());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
