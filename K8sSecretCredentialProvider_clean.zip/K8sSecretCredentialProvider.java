
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Profile("k8s")
@Component
public class K8sSecretCredentialProvider implements ICredentialProvider {

    @Value("${k8s.secrets.path:/var/run/secrets/custom-secrets/}")
    private String basePath;

    private String readSecret(String name) {
        try {
            return Files.readString(Paths.get(basePath + name)).trim();
        } catch (IOException e) {
            throw new RuntimeException("Erreur lecture secret : " + name, e);
        }
    }

    @Override
    public String getClientId() {
        return readSecret("client-id");
    }

    @Override
    public String getClientSecret() {
        return readSecret("client-secret");
    }

    @Override
    public String getTenantId() {
        return readSecret("tenant-id");
    }
}
