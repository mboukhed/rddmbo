
package com.example;

import org.apache.spark.sql.*;
import org.apache.spark.sql.types.*;

import java.io.File;
import java.util.*;

public class PartitionSafeParquetReader {

    /**
     * Lit un dossier Parquet partitionné où les types peuvent varier (ex : date vs string),
     * en les castant dynamiquement vers un type cible commun.
     */
    public static Dataset<Row> readAndUnionPartitions(
            SparkSession spark,
            String directoryPath,
            Map<String, String> castColumns
    ) {
        File dir = new File(directoryPath);
        List<Dataset<Row>> datasets = new ArrayList<>();

        File[] parquetFiles = dir.listFiles((d, name) -> name.endsWith(".parquet"));

        if (parquetFiles == null) {
            throw new RuntimeException("No parquet files found in: " + directoryPath);
        }

        for (File file : parquetFiles) {
            Dataset<Row> partDf = spark.read()
                .option("mergeSchema", "false")
                .parquet(file.getAbsolutePath());

            for (Map.Entry<String, String> entry : castColumns.entrySet()) {
                String col = entry.getKey();
                String type = entry.getValue();
                if (Arrays.asList(partDf.columns()).contains(col)) {
                    partDf = partDf.withColumn(col, partDf.col(col).cast(type));
                }
            }

            datasets.add(partDf);
        }

        return datasets.stream()
                .reduce((d1, d2) -> d1.unionByName(d2, true))
                .orElseThrow(() -> new RuntimeException("No data found in any partition"));
    }
}
