
package com.example.pathutils;

import java.io.File;

public final class PathUtils {

    private PathUtils() {
        // Util class : no instance
    }

    /**
     * Résout dynamiquement le chemin pour Spark compatible avec tous les environnements :
     * - Local IntelliJ / Jenkins (src/...)
     * - Chemins absolus (Linux, Windows)
     * - file:/ protocol
     * - Cloud storage (abfs://, wasbs://, s3://, gs://, https://)
     */
    public static String resolvePath(String pathOrResource) {
        if (pathOrResource.startsWith("src/")) {
            return resolveLocalTestPath(pathOrResource);
        }
        if (isCloudPath(pathOrResource)) {
            return pathOrResource;
        }
        if (isAbsoluteLocalPath(pathOrResource)) {
            return toLocalFilePath(pathOrResource);
        }
        if (pathOrResource.startsWith("file:/")) {
            return fixFileProtocol(pathOrResource);
        }
        return pathOrResource;
    }

    private static boolean isCloudPath(String path) {
        String lowerPath = path.toLowerCase();
        return lowerPath.startsWith("abfs://") || lowerPath.startsWith("wasbs://") ||
               lowerPath.startsWith("s3://") || lowerPath.startsWith("s3a://") ||
               lowerPath.startsWith("gs://") || lowerPath.startsWith("https://");
    }

    private static boolean isAbsoluteLocalPath(String path) {
        return path.startsWith("/") || path.matches("^[A-Za-z]:\\\\.*") || path.matches("^[A-Za-z]:/.*");
    }

    private static String toLocalFilePath(String absolutePath) {
        String correctedPath = absolutePath.replace("\\", "/").replace("\", "/");
        if (correctedPath.startsWith("/")) {
            return "file://" + correctedPath;
        } else if (correctedPath.matches("^[A-Za-z]:/.*")) {
            return "file:///" + correctedPath;
        } else {
            return "file://" + correctedPath;
        }
    }

    private static String fixFileProtocol(String path) {
        if (path.startsWith("file:/") && !path.startsWith("file:///")) {
            return path.replaceFirst("file:/", "file:///");
        }
        return path;
    }

    private static String resolveLocalTestPath(String resourceRelativePath) {
        File file = new File(resourceRelativePath);
        if (!file.exists()) {
            throw new IllegalArgumentException("Fichier de test introuvable : " + file.getAbsolutePath());
        }
        return toLocalFilePath(file.getAbsolutePath());
    }
}
