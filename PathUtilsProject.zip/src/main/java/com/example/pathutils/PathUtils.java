
package com.example.pathutils;

import java.io.File;
import java.net.URL;
import java.nio.file.Paths;

public final class PathUtils {

    public static String resolvePath(String pathOrResource) {
        try {
            if (isCloudPath(pathOrResource)) {
                return pathOrResource;
            } else if (isAbsoluteLocalPath(pathOrResource)) {
                return toLocalFilePath(pathOrResource);
            } else if (pathOrResource.startsWith("file:/")) {
                return fixFileProtocol(pathOrResource);
            } else {
                return getTestResourcePath(pathOrResource);
            }
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la résolution du chemin: " + pathOrResource, e);
        }
    }

    private static boolean isCloudPath(String path) {
        String lowerPath = path.toLowerCase();
        return lowerPath.startsWith("abfs://") || lowerPath.startsWith("wasbs://") ||
               lowerPath.startsWith("s3://") || lowerPath.startsWith("s3a://") ||
               lowerPath.startsWith("gs://") || lowerPath.startsWith("https://");
    }

    private static boolean isAbsoluteLocalPath(String path) {
        return path.startsWith("/") || path.matches("^[A-Za-z]:\\\\.*");
    }

    private static String toLocalFilePath(String absolutePath) {
        String correctedPath = absolutePath.replace("\\", "/").replace("\", "/");
        if (correctedPath.startsWith("/")) {
            return "file://" + correctedPath;
        } else if (correctedPath.matches("^[A-Za-z]:/.*")) {
            return "file:///" + correctedPath;
        } else {
            return "file://" + correctedPath;
        }
    }

    private static String fixFileProtocol(String path) {
        if (path.startsWith("file:/") && !path.startsWith("file:///")) {
            return path.replaceFirst("file:/", "file:///");
        }
        return path;
    }

    private static String getTestResourcePath(String resourceRelativePath) {
        try {
            URL resourceUrl = PathUtils.class.getClassLoader().getResource(resourceRelativePath);
            if (resourceUrl == null) {
                throw new IllegalArgumentException("Fichier de test introuvable : " + resourceRelativePath);
            }
            File file = Paths.get(resourceUrl.toURI()).toFile();
            return toLocalFilePath(file.getAbsolutePath());
        } catch (Exception e) {
            throw new RuntimeException("Erreur chargement ressource de test: " + resourceRelativePath, e);
        }
    }
}
