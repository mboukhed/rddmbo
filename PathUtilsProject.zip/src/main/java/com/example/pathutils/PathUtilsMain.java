
package com.example.pathutils;

public class PathUtilsMain {
    public static void main(String[] args) {
        String test1 = PathUtils.resolvePath("src/test/resources/data/input/file.csv");
        System.out.println("Test resource path: " + test1);

        String test2 = PathUtils.resolvePath("file:/C:/data/project/input/file.csv");
        System.out.println("File protocol path: " + test2);

        String test3 = PathUtils.resolvePath("abfs://container@account.dfs.core.windows.net/dir/file.csv");
        System.out.println("ABFS cloud path: " + test3);

        String test4 = PathUtils.resolvePath("/home/user/data/file.csv");
        System.out.println("Absolute unix path: " + test4);
    }
}
