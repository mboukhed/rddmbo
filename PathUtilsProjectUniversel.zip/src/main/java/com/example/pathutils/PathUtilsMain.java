
package com.example.pathutils;

public class PathUtilsMain {
    public static void main(String[] args) {
        try {
            System.out.println("==== TEST src/ ====");
            String test1 = PathUtils.resolvePath("src/test/resources/data/input/file.csv");
            System.out.println("Test resource path: " + test1);
        } catch (Exception e) {
            System.out.println("Ressource test non trouvée : " + e.getMessage());
        }

        System.out.println("==== TEST file:/ ====");
        String test2 = PathUtils.resolvePath("file:/C:/data/project/input/file.csv");
        System.out.println("File protocol path: " + test2);

        System.out.println("==== TEST ABFS ====");
        String test3 = PathUtils.resolvePath("abfs://container@account.dfs.core.windows.net/dir/file.csv");
        System.out.println("ABFS cloud path: " + test3);

        System.out.println("==== TEST absolu unix ====");
        String test4 = PathUtils.resolvePath("/home/user/data/file.csv");
        System.out.println("Absolute unix path: " + test4);
    }
}
