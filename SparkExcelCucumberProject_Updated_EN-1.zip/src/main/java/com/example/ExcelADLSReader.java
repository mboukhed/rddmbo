
package com.example;

import org.apache.spark.sql.*;

public class ExcelADLSReader {
    public static Dataset<Row> readExcel(SparkSession spark, String path) {
        return spark.read()
            .format("com.crealytics.spark.excel")
            .option("header", "true")
            .option("inferSchema", "true")
            .load(path);
    }
}
