
package com.example;

import io.cucumber.java.en.*;
import org.apache.spark.sql.*;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class ExcelSteps {

    private Dataset<Row> dataset;

    @Given("an Excel file located at {string}")
    public void an_excel_file(String path) {
        SparkSession spark = SparkSession.builder()
            .appName("TestExcel")
            .master("local[*]")
            .getOrCreate();
        dataset = ExcelADLSReader.readExcel(spark, path);
    }

    @When("I read it using Spark")
    public void i_read_it_using_spark() {
        // Already read in Given
    }

    @Then("the dataset should contain some rows")
    public void the_dataset_should_contain_some_rows() {
        assertTrue("Dataset is empty", dataset.count() > 0);
    }

    @Then("the dataset should contain a column {string}")
    public void the_dataset_should_contain_a_column(String column) {
        List<String> columns = Arrays.asList(dataset.columns());
        assertTrue("Missing column: " + column, columns.contains(column));
    }

    @Then("the dataset should contain a row with ID {string} and AMOUNT {string}")
    public void the_dataset_should_contain_a_row_with_id_and_amount(String id, String amount) {
        long count = dataset.filter(
            functions.col("ID").equalTo(id)
            .and(functions.col("AMOUNT").equalTo(amount))
        ).count();
        assertTrue("No matching row found for ID=" + id + " and AMOUNT=" + amount, count > 0);
    }
}
