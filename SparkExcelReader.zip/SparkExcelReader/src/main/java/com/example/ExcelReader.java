
package com.example;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class ExcelReader {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
            .appName("Excel Reader")
            .master("local[*]")
            .getOrCreate();

        String excelPath = "data/fichier.xlsx"; // à adapter

        Dataset<Row> feuille1 = spark.read()
            .format("com.crealytics.spark.excel")
            .option("dataAddress", "'Feuille1'!A1")
            .option("useHeader", "true")
            .option("inferSchema", "true")
            .load(excelPath);

        Dataset<Row> feuille2 = spark.read()
            .format("com.crealytics.spark.excel")
            .option("dataAddress", "'Feuille2'!A1")
            .option("useHeader", "true")
            .option("inferSchema", "true")
            .load(excelPath);

        feuille1.show();
        feuille2.show();

        spark.stop();
    }
}
