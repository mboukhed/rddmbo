package com.example;

public class MainApp {
    public static void main(String[] args) {
        System.out.println("App launched");
        for (String arg : args) {
            System.out.println(arg);
        }
    }
}