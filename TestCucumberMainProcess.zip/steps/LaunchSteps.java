package steps;

import io.cucumber.java.en.*;
import java.io.*;
import java.util.*;

public class LaunchSteps {

    private List<String> args;
    private String output;

    @Given("je prépare les arguments {string}")
    public void je_prepare_les_arguments(String arguments) {
        args = Arrays.asList(arguments.split("\s+"));
    }

    @When("je lance MainApp via un processus")
    public void je_lance_MainApp_via_un_processus() throws Exception {
        List<String> command = new ArrayList<>();
        command.add("java");
        command.add("-cp");
        command.add("."); // dossier racine contenant com/example
        command.add("com.example.MainApp");
        command.addAll(args);

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.redirectErrorStream(true);
        Process p = pb.start();

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            output = reader.lines().reduce("", (acc, line) -> acc + line + "\n");
        }

        int code = p.waitFor();
        if (code != 0) throw new RuntimeException("Process exited with code: " + code);
    }

    @Then("la sortie doit contenir {string}")
    public void la_sortie_doit_contenir(String expected) {
        if (!output.contains(expected)) {
            throw new AssertionError("La sortie ne contient pas : " + expected + "\nSortie:\n" + output);
        }
    }
}