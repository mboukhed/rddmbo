
package com.example.converter;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class TypeConverterHelperTest {

    @Test
    public void testNumericConversions() {
        assertEquals(123, TypeConverterHelper.forceConvert("123", Integer.class));
        assertEquals(1234567890123L, TypeConverterHelper.forceConvert("1234567890123", Long.class));
        assertEquals(12.34, TypeConverterHelper.forceConvert("12.34", Double.class));
        assertEquals(5.67f, TypeConverterHelper.forceConvert("5.67", Float.class));
        assertEquals(new BigDecimal("12345.678"), TypeConverterHelper.forceConvert("12345.678", BigDecimal.class));
    }

    @Test
    public void testNumericSeparators() {
        assertEquals(0.0, TypeConverterHelper.forceConvert("12,34", Double.class));
        assertEquals(BigDecimal.ZERO, TypeConverterHelper.forceConvert("45 67", BigDecimal.class));
        assertEquals(Float.valueOf(0), TypeConverterHelper.forceConvert("1 234,56", Float.class));
    }

    @Test
    public void testDateConversions() {
        long epochMillis = 1717415400000L; // 2024-06-03T10:30:00Z
        assertNotNull(TypeConverterHelper.forceConvert(epochMillis, java.util.Date.class));
        assertNotNull(TypeConverterHelper.forceConvert(epochMillis, LocalDateTime.class));
        assertNotNull(TypeConverterHelper.forceConvert(epochMillis, LocalDate.class));
        assertNotNull(TypeConverterHelper.forceConvert(epochMillis, Date.class));
        assertNotNull(TypeConverterHelper.forceConvert(epochMillis, Timestamp.class));
    }
}
