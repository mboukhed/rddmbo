
package com.example.converter;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.Instant;
import java.time.format.DateTimeFormatter;

public abstract class TypeConverterHelper {

    public static <T> T forceConvert(Object value, Class<T> targetClass) {
        if (value == null) return null;

        String str = value.toString().trim();

        try {
            if (targetClass == Double.class || targetClass == Float.class || targetClass == BigDecimal.class) {
                str = str.replace(",", ".").replaceAll("\s+", "");
            }

            // Fallback java.sql.Date via LocalDate parsing
            if (targetClass == Date.class) {
                try {
                    return (T) Date.valueOf(str); // yyyy-MM-dd
                } catch (Exception e) {
                    for (DateTimeFormatter formatter : DATE_FORMATTERS) {
                        try {
                            LocalDate parsedDate = LocalDate.parse(str, formatter);
                            return (T) Date.valueOf(parsedDate);
                        } catch (Exception ignored) {}
                    }
                }
            }

            if (targetClass == Integer.class) return (T) Integer.valueOf(str);
            if (targetClass == Long.class) return (T) Long.valueOf(str);
            if (targetClass == Double.class) return (T) Double.valueOf(str);
            if (targetClass == Float.class) return (T) Float.valueOf(str);
            if (targetClass == Boolean.class) return (T) Boolean.valueOf(str);
            if (targetClass == String.class) return (T) str;
            if (targetClass == BigDecimal.class) return (T) new BigDecimal(str);

            Long epochMillis = null;
            if (value instanceof Number) {
                epochMillis = ((Number) value).longValue();
            } else if (str.matches("^\d{10,17}$")) {
                epochMillis = Long.parseLong(str);
            }

            if (epochMillis != null) {
                if (epochMillis < 100000000000L) {
                    epochMillis *= 1000;
                }
                Instant instant = Instant.ofEpochMilli(epochMillis);

                if (targetClass == Timestamp.class) {
                    return (T) Timestamp.from(instant);
                }
            }

            for (DateTimeFormatter formatter : DATE_FORMATTERS) {
                try {
                    LocalDateTime ldt;
                    try {
                        ldt = LocalDateTime.parse(str, formatter);
                    } catch (Exception ex) {
                        if (str.matches("^\d{4}-\d{2}-\d{2}$") ||
                            str.matches("^\d{2}/\d{2}/\d{4}$") ||
                            str.matches("^\d{4}/\d{2}/\d{2}$") ||
                            str.matches("^\d{2}\.\d{2}\.\d{4}$") ||
                            str.matches("^\d{4}\.\d{2}\.\d{2}$")) {
                            str = str + " 00:00:00";
                        }
                        ldt = LocalDateTime.parse(str, formatter);
                    }

                    if (targetClass == Timestamp.class) return (T) Timestamp.valueOf(ldt);
                } catch (Exception ignored) {}
            }

        } catch (Exception e) {
            return null;
        }

        return null;
    }

    private static final DateTimeFormatter[] DATE_FORMATTERS = new DateTimeFormatter[] {
        DateTimeFormatter.ISO_LOCAL_DATE_TIME,
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd"),
        DateTimeFormatter.ofPattern("dd/MM/yyyy"),
        DateTimeFormatter.ofPattern("dd-MM-yyyy"),
        DateTimeFormatter.ofPattern("yyyyMMdd"),
        DateTimeFormatter.ofPattern("yyyy/MM/dd"),
        DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS"),
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"),
        DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm"),
        DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"),
        DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm"),
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"),
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"),
        DateTimeFormatter.ofPattern("dd.MM.yyyy"),
        DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss"),
        DateTimeFormatter.ofPattern("yyyy.MM.dd"),
        DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss"),
        DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"),
        DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm")
    };
}
