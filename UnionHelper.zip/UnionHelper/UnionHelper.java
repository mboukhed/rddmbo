
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.functions;

import java.sql.Date;
import java.util.Map;

public class UnionHelper {

    public static Dataset<Row> loadAndUnionWithDate(Map<Date, String> filesFiltred) {

        Dataset<Row> dsUnion = filesFiltred.entrySet().stream()
            .map(entry -> {
                Dataset<Row> dsTmp = loadData(MyClass.class, entry.getValue());
                return dsTmp.withColumn("processingDate", functions.lit(new java.sql.Date(entry.getKey().getTime())));
            })
            .reduce((ds1, ds2) -> ds1.union(ds2))
            .orElse(sparkSession.emptyDataFrame());

        return dsUnion;
    }

    // Mock de la méthode loadData à adapter à ton projet
    private static Dataset<Row> loadData(Class<?> clazz, String path) {
        // Ici tu mets ton vrai code de chargement dataset
        return null;
    }

    // À adapter à ton contexte : injecte ton sparkSession ici
    private static final org.apache.spark.sql.SparkSession sparkSession = org.apache.spark.sql.SparkSession.active();

}
