# Configuration Ultra-Agressive pour Timeout 90s ABFS - Azure Data Lake Gen2

Cette configuration est destinée à contourner les limites de timeout persistantes (comme le `timeout=90`) sur les lectures via ABFS dans Spark / Databricks.

---

## 1. Script d'initialisation système (init script)

```bash
#!/bin/bash
# /databricks/driver/conf/00-abfs-network.sh

echo "net.ipv4.tcp_keepalive_time = 120" >> /etc/sysctl.conf
echo "net.ipv4.tcp_keepalive_intvl = 30" >> /etc/sysctl.conf
echo "net.ipv4.tcp_keepalive_probes = 6" >> /etc/sysctl.conf
echo "net.ipv4.tcp_fin_timeout = 30" >> /etc/sysctl.conf
echo "net.core.netdev_max_backlog = 5000" >> /etc/sysctl.conf
echo "net.core.rmem_max = 268435456" >> /etc/sysctl.conf
echo "net.core.wmem_max = 268435456" >> /etc/sysctl.conf
echo "net.ipv4.tcp_window_scaling = 1" >> /etc/sysctl.conf
echo "net.ipv4.tcp_timestamps = 1" >> /etc/sysctl.conf
echo "net.ipv4.tcp_sack = 1" >> /etc/sysctl.conf
sysctl -p

# JVM tuning
echo "-Dcom.sun.management.jmxremote.ssl=false" >> /databricks/driver/conf/driver-java-opts
echo "-Dcom.sun.management.jmxremote.authenticate=false" >> /databricks/driver/conf/driver-java-opts
echo "-Djava.net.preferIPv4Stack=true" >> /databricks/driver/conf/driver-java-opts
echo "-Dcom.microsoft.azure.storage.httpclient.timeout=600000" >> /databricks/driver/conf/driver-java-opts
```

---

## 2. Configuration ABFS ultra-étendue

```java
spark.conf().set("fs.azure.timeout", "1800000");
spark.conf().set("fs.azure.http.timeout", "1800000");
spark.conf().set("fs.azure.http.read.timeout", "1800000");
spark.conf().set("fs.azure.http.connection.timeout", "1800000");
spark.conf().set("fs.azure.retry.count", "15");
spark.conf().set("fs.azure.retry.interval", "60000");
spark.conf().set("fs.azure.io.retry.max.requests", "15");
spark.conf().set("fs.azure.io.retry.backoff.interval", "30000");
spark.conf().set("fs.azure.read.buffer.size", "8388608");
spark.conf().set("spark.network.timeout", "1800s");
spark.conf().set("spark.rpc.askTimeout", "1800s");
spark.conf().set("spark.executor.extraJavaOptions", "-Djava.net.preferIPv4Stack=true");
```

---

## 3. Méthode Java de lecture avec Circuit Breaker

```java
public class AbfsCircuitBreakerReader {
    // Réessaie jusqu'à 5 fois avec delays progressifs
    // Voir code complet dans le fichier
}
```

---

## 4. Alternative : lecture par Azure SDK

Utilisation d'`AzureStorage SDK` pour lire les fichiers `.gz` depuis ADLS, les décompresser manuellement, et injecter dans Spark via RDDs.

---

## 5. Configuration cluster Databricks

```
spark.executor.memory 16g
spark.driver.memory 8g
spark.network.timeout 3600s
spark.sql.broadcastTimeout 3600
fs.azure.timeout 3600000
fs.azure.retry.count 20
fs.azure.retry.interval 60000
```

---

## 6. Diagnostic rapide

```java
public void diagnoseAbfsTimeout(SparkSession spark, String path) {
    // Test de connectivité + lecture d'un seul petit fichier
}
```

---

## 7. Solution immédiate ultra-conservative

```java
SparkSession spark = SparkSession.getActiveSession().get();
spark.conf().set("spark.network.timeout", "3600s");
spark.conf().set("fs.azure.timeout", "3600000");

Dataset<Row> df = spark.read()
    .option("compression", "gzip")
    .option("maxFilesPerTrigger", "1")
    .format("text")
    .load("abfss://container@account.dfs.core.windows.net/path/*.gz")
    .limit(1000);

df.count();
```

---

## ✅ Si même cette approche échoue :
- Split des fichiers > 5 Go
- Téléchargement via Azure SDK + prétraitement local
- Passage temporaire via Azure Data Factory