
package com.example.adls;

import org.apache.hadoop.fs.*;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

public class AdlsFileService {

    private final AdlsFileSystemCache fsCache;
    private final String accountName;

    public AdlsFileService(AdlsFileSystemCache fsCache, String accountName) {
        this.fsCache = fsCache;
        this.accountName = accountName;
    }

    public void createDirectory(String containerName, String directoryPath) throws IOException, URISyntaxException {
        FileSystem fs = fsCache.getFileSystem(containerName, accountName);
        Path path = new Path("/" + directoryPath);
        fs.mkdirs(path);
    }

    public void deleteDirectory(String containerName, String directoryPath) throws IOException, URISyntaxException {
        FileSystem fs = fsCache.getFileSystem(containerName, accountName);
        Path path = new Path("/" + directoryPath);
        fs.delete(path, true);
    }

    public void copyDirectory(String containerName, String sourcePath, String targetPath) throws IOException, URISyntaxException {
        FileSystem fs = fsCache.getFileSystem(containerName, accountName);
        Path src = new Path("/" + sourcePath);
        Path dst = new Path("/" + targetPath);
        FileUtil.copy(fs, src, fs, dst, false, fs.getConf());
    }

    public List<String> listFiles(String containerName, String directoryPath, boolean isChildren, boolean isFolder) throws IOException, URISyntaxException {
        FileSystem fs = fsCache.getFileSystem(containerName, accountName);
        Path path = new Path("/" + directoryPath);
        List<String> result = new ArrayList<>();

        if (isChildren) {
            RemoteIterator<LocatedFileStatus> files = fs.listFiles(path, true);
            while (files.hasNext()) {
                LocatedFileStatus file = files.next();
                if (file.isDirectory() && !isFolder) continue;
                result.add(file.getPath().toString());
            }
        } else {
            FileStatus[] statuses = fs.listStatus(path);
            for (FileStatus status : statuses) {
                if (status.isDirectory() && !isFolder) continue;
                result.add(status.getPath().toString());
            }
        }
        return result;
    }
}
