
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

@SpringConfiguration
public class AdlsConfigurationFactory {

    @Value("${adls.account-name:}")
    private String accountName;

    @Value("${adls.auth-type:auto}")
    private String authType;

    @Bean
    public Configuration hadoopConfiguration() {
        Configuration hadoopConf = new Configuration();

        if ("auto".equalsIgnoreCase(authType)) {
            if (isManagedIdentityAvailable()) {
                authType = "managed-identity";
            } else if (areSpnEnvVarsAvailable()) {
                authType = "service-principal";
            } else {
                authType = "local";
            }
        }

        if ("local".equalsIgnoreCase(authType)) {
            hadoopConf.set("fs.defaultFS", "file:///");
            return hadoopConf;
        }

        if (accountName == null || accountName.isBlank()) {
            throw new RuntimeException("Missing account-name for non-local mode");
        }

        String accountFqdn = accountName + ".dfs.core.windows.net";

        if ("service-principal".equalsIgnoreCase(authType)) {
            String clientId = System.getenv("ADLS_CLIENT_ID");
            String clientSecret = System.getenv("ADLS_CLIENT_SECRET");
            String tenantId = System.getenv("ADLS_TENANT_ID");

            if (isEmpty(clientId) || isEmpty(clientSecret) || isEmpty(tenantId)) {
                throw new RuntimeException("Missing environment variables for service-principal authentication");
            }

            hadoopConf.set("fs.azure.account.auth.type." + accountFqdn, "OAuth");
            hadoopConf.set("fs.azure.account.oauth.provider.type." + accountFqdn,
                    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
            hadoopConf.set("fs.azure.account.oauth2.client.id." + accountFqdn, clientId);
            hadoopConf.set("fs.azure.account.oauth2.client.secret." + accountFqdn, clientSecret);
            hadoopConf.set("fs.azure.account.oauth2.client.endpoint." + accountFqdn,
                    "https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
        } else if ("managed-identity".equalsIgnoreCase(authType)) {
            hadoopConf.set("fs.azure.account.auth.type." + accountFqdn, "ManagedIdentity");
            hadoopConf.set("fs.azure.account.oauth2.msi.endpoint." + accountFqdn,
                    "http://169.254.169.254/metadata/identity/oauth2/token");
        } else {
            throw new RuntimeException("Unsupported ADLS auth-type: " + authType);
        }
        return hadoopConf;
    }

    private boolean isManagedIdentityAvailable() {
        try {
            URL url = new URL("http://169.254.169.254/metadata/instance?api-version=2021-02-01");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Metadata", "true");
            conn.setConnectTimeout(500);
            conn.setReadTimeout(500);
            int responseCode = conn.getResponseCode();
            return responseCode == 200;
        } catch (IOException e) {
            return false;
        }
    }

    private boolean areSpnEnvVarsAvailable() {
        return !isEmpty(System.getenv("ADLS_CLIENT_ID")) &&
               !isEmpty(System.getenv("ADLS_CLIENT_SECRET")) &&
               !isEmpty(System.getenv("ADLS_TENANT_ID"));
    }

    private boolean isEmpty(String s) {
        return s == null || s.isBlank();
    }
}
