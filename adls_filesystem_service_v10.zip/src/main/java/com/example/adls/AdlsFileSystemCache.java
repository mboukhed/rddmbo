
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ConcurrentHashMap;

public class AdlsFileSystemCache {

    private final Configuration hadoopConf;
    private final ConcurrentHashMap<String, FileSystem> fsCache = new ConcurrentHashMap<>();

    public AdlsFileSystemCache(Configuration hadoopConf) {
        this.hadoopConf = hadoopConf;
    }

    public FileSystem getFileSystem(String fullPath) throws IOException, URISyntaxException {
        URI uri = new URI(fullPath);
        String scheme = uri.getScheme();

        if ("file".equalsIgnoreCase(scheme)) {
            return FileSystem.get(uri, hadoopConf);
        } else if ("abfss".equalsIgnoreCase(scheme)) {
            String fsKey = uri.getAuthority();
            return fsCache.computeIfAbsent(fsKey, key -> {
                try {
                    return FileSystem.get(uri, hadoopConf);
                } catch (Exception e) {
                    throw new RuntimeException("Erreur FileSystem pour " + fsKey, e);
                }
            });
        } else {
            throw new IllegalArgumentException("Schéma non supporté: " + scheme);
        }
    }
}
