
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration;
import java.util.Map;

@SpringConfiguration
public class AdlsConfigurationFactory {

    @Value("${adls.auth-type:auto}")
    private String authType;

    @Value("#{${adls.accounts:{}}}")
    private Map<String, String> storageAccounts;

    @Bean
    public Configuration hadoopConfiguration() {
        Configuration hadoopConf = new Configuration();

        if ("local".equalsIgnoreCase(authType)) {
            hadoopConf.set("fs.defaultFS", "file:///");
            return hadoopConf;
        }

        for (Map.Entry<String, String> entry : storageAccounts.entrySet()) {
            String accountName = entry.getKey();
            String mode = entry.getValue();
            String fqdn = accountName + ".dfs.core.windows.net";

            if ("managed-identity".equalsIgnoreCase(mode)) {
                hadoopConf.set("fs.azure.account.auth.type." + fqdn, "ManagedIdentity");
                hadoopConf.set("fs.azure.account.oauth2.msi.endpoint." + fqdn,
                        "http://169.254.169.254/metadata/identity/oauth2/token");
            } else if ("service-principal".equalsIgnoreCase(mode)) {
                String clientId = System.getenv("ADLS_CLIENT_ID");
                String clientSecret = System.getenv("ADLS_CLIENT_SECRET");
                String tenantId = System.getenv("ADLS_TENANT_ID");
                hadoopConf.set("fs.azure.account.auth.type." + fqdn, "OAuth");
                hadoopConf.set("fs.azure.account.oauth.provider.type." + fqdn,
                        "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
                hadoopConf.set("fs.azure.account.oauth2.client.id." + fqdn, clientId);
                hadoopConf.set("fs.azure.account.oauth2.client.secret." + fqdn, clientSecret);
                hadoopConf.set("fs.azure.account.oauth2.client.endpoint." + fqdn,
                        "https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
            }
        }
        return hadoopConf;
    }
}
