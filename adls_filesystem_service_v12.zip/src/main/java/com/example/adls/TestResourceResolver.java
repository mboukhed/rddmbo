
package com.example.adls;

import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TestResourceResolver {

    public static String resolveTestResourcePath(String resourceRelativePath) {
        try {
            ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
            URL resourceUrl = classLoader.getResource(resourceRelativePath);
            if (resourceUrl == null) {
                throw new IllegalArgumentException("Ressource de test introuvable : " + resourceRelativePath);
            }
            Path path = Paths.get(resourceUrl.toURI());
            return path.toUri().toString();
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la résolution de la ressource de test", e);
        }
    }
}
