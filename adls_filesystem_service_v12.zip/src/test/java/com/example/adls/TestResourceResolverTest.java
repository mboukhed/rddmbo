
package com.example.adls;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestResourceResolverTest {

    @Test
    public void testResolve() {
        // Simulation de test path dynamique
        String path = TestResourceResolver.resolveTestResourcePath("dummyfile.csv");
        assertTrue(path.startsWith("file:///"));
    }
}
