
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration;

@SpringConfiguration
public class AdlsConfigurationFactory {

    @Value("${adls.account-name}")
    private String accountName;

    @Value("${adls.auth-type}")
    private String authType;

    @Value("${adls.client-id:}")
    private String clientId;

    @Value("${adls.client-secret:}")
    private String clientSecret;

    @Value("${adls.tenant-id:}")
    private String tenantId;

    @Bean
    public Configuration hadoopConfiguration() {
        Configuration hadoopConf = new Configuration();
        String accountFqdn = accountName + ".dfs.core.windows.net";

        if ("service-principal".equalsIgnoreCase(authType)) {
            hadoopConf.set("fs.azure.account.auth.type." + accountFqdn, "OAuth");
            hadoopConf.set("fs.azure.account.oauth.provider.type." + accountFqdn,
                    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
            hadoopConf.set("fs.azure.account.oauth2.client.id." + accountFqdn, clientId);
            hadoopConf.set("fs.azure.account.oauth2.client.secret." + accountFqdn, clientSecret);
            hadoopConf.set("fs.azure.account.oauth2.client.endpoint." + accountFqdn,
                    "https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
        } else if ("managed-identity".equalsIgnoreCase(authType)) {
            hadoopConf.set("fs.azure.account.auth.type." + accountFqdn, "ManagedIdentity");
            hadoopConf.set("fs.azure.account.oauth2.msi.endpoint." + accountFqdn,
                    "http://169.254.169.254/metadata/identity/oauth2/token");
        } else {
            throw new RuntimeException("Unsupported ADLS auth-type: " + authType);
        }

        return hadoopConf;
    }
}
