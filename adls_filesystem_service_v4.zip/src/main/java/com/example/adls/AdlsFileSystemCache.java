
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.concurrent.ConcurrentHashMap;

public class AdlsFileSystemCache {

    private final Configuration hadoopConf;
    private final ConcurrentHashMap<String, FileSystem> fsCache = new ConcurrentHashMap<>();

    public AdlsFileSystemCache(Configuration hadoopConf) {
        this.hadoopConf = hadoopConf;
    }

    public FileSystem getFileSystem(String containerName, String accountName) throws IOException, URISyntaxException {
        String fsKey = containerName + "@" + accountName;
        return fsCache.computeIfAbsent(fsKey, key -> {
            try {
                String fsUri = String.format("abfss://%s@%s.dfs.core.windows.net/", containerName, accountName);
                return FileSystem.get(new URI(fsUri), hadoopConf);
            } catch (Exception e) {
                throw new RuntimeException("Erreur initialisation FileSystem pour " + fsKey, e);
            }
        });
    }
}
