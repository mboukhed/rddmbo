
package com.example.adls;

import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.fs.FileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdlsFileServiceTest {

    private AdlsFileSystemCache fsCache;
    private AdlsFileService fileService;
    private FileSystem mockFileSystem;

    @BeforeEach
    public void setUp() throws IOException, URISyntaxException {
        fsCache = mock(AdlsFileSystemCache.class);
        mockFileSystem = mock(FileSystem.class);
        when(fsCache.getFileSystem(anyString(), anyString())).thenReturn(mockFileSystem);
        fileService = new AdlsFileService(fsCache, "accountName");
    }

    @Test
    public void testCreateDirectory() throws IOException, URISyntaxException {
        fileService.createDirectory("container", "testDir");
        verify(mockFileSystem).mkdirs(new Path("/testDir"));
    }

    @Test
    public void testDeleteDirectory() throws IOException, URISyntaxException {
        fileService.deleteDirectory("container", "testDir");
        verify(mockFileSystem).delete(new Path("/testDir"), true);
    }

    @Test
    public void testListFilesNoChildren() throws IOException, URISyntaxException {
        FileStatus status = mock(FileStatus.class);
        when(status.isDirectory()).thenReturn(false);
        when(status.getPath()).thenReturn(new Path("/testDir/file1.txt"));
        when(mockFileSystem.listStatus(any())).thenReturn(new FileStatus[]{status});

        List<String> files = fileService.listFiles("container", "testDir", false, true);
        assertEquals(1, files.size());
        assertTrue(files.get(0).endsWith("file1.txt"));
    }
}
