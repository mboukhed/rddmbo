
package com.example.adls;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;

public class AdlsFileServiceStepDefs {

    private String directoryPath;

    @Given("I have a new directory path {string}")
    public void i_have_a_new_directory_path(String path) {
        this.directoryPath = path;
    }

    @When("I create the directory")
    public void i_create_the_directory() {
        // Ici appel au vrai service si besoin, mocké dans le cadre de démo
        System.out.println("Mock Create directory: " + directoryPath);
    }

    @Then("The directory should be created")
    public void the_directory_should_be_created() {
        Assertions.assertNotNull(directoryPath);
    }

    @When("I delete the directory")
    public void i_delete_the_directory() {
        System.out.println("Mock Delete directory: " + directoryPath);
    }

    @Then("The directory should be deleted")
    public void the_directory_should_be_deleted() {
        Assertions.assertNotNull(directoryPath);
    }
}
