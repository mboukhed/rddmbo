
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

public class SparkCsvToParquetJob {

    public static void main(String[] args) {
        if (args.length < 3) {
            System.err.println("Usage: SparkCsvToParquetJob <account-name> <input-path> <output-path>");
            System.exit(1);
        }

        String accountName = args[0];
        String inputPath = args[1];
        String outputPath = args[2];

        SparkSession spark = SparkSession.builder()
                .appName("ADLS Csv To Parquet")
                .getOrCreate();

        Configuration hadoopConf = spark.sparkContext().hadoopConfiguration();

        // Simplicité : on injecte directement les conf Hadoop selon le mode d'auth déjà fait via Spring factory

        System.out.println("Reading CSV from: " + inputPath);
        Dataset<Row> csvData = spark.read()
                .option("header", "true")
                .option("inferSchema", "true")
                .csv(inputPath);

        csvData.show();

        System.out.println("Writing Parquet to: " + outputPath);
        csvData.write()
                .mode("overwrite")
                .parquet(outputPath);

        spark.stop();
    }
}
