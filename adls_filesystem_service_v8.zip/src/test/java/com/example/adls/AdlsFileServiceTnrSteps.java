
package com.example.adls;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.junit.jupiter.api.Assertions;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

public class AdlsFileServiceTnrSteps {

    private final AdlsFileService fileService = new AdlsFileService(new AdlsFileSystemCache(new org.apache.hadoop.conf.Configuration()), "accountName");
    private String directoryPath;

    @Given("I have a directory path {string}")
    public void i_have_a_directory_path(String path) {
        this.directoryPath = path;
    }

    @When("I create this directory")
    public void i_create_this_directory() throws IOException, URISyntaxException {
        System.out.println("Mock Create directory: " + directoryPath);
    }

    @Then("The directory should exist")
    public void the_directory_should_exist() {
        Assertions.assertNotNull(directoryPath);
    }

    @When("I list files under the directory")
    public void i_list_files_under_the_directory() {
        System.out.println("Mock list directory: " + directoryPath);
    }

    @Then("The list should contain {string}")
    public void the_list_should_contain(String expected) {
        Assertions.assertTrue(directoryPath.contains(expected));
    }

    @When("I delete this directory")
    public void i_delete_this_directory() throws IOException, URISyntaxException {
        System.out.println("Mock Delete directory: " + directoryPath);
    }

    @Then("The directory should not exist")
    public void the_directory_should_not_exist() {
        Assertions.assertNotNull(directoryPath);
    }
}
