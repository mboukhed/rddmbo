
package com.example.adls;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.sql.SparkSession;

public class SparkHadoopConfigInjector {

    public static void inject(Configuration hadoopConf, SparkSession spark) {
        hadoopConf.forEach(entry -> {
            spark.sparkContext().hadoopConfiguration()
                    .set(entry.getKey().toString(), entry.getValue().toString());
        });
    }
}
