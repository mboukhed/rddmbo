import picocli.CommandLine.Option;
import jakarta.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.Map;

public class AppArguments {

    @Option(names = "--source", required = true, description = "Nom de la source")
    @NotNull
    private String source;

    @Option(names = "--table", required = true, description = "Nom de la table cible")
    @NotNull
    private String table;

    private final Map<String, String> dynamicOptions = new HashMap<>();

    public String getSource() {
        return source;
    }

    public String getTable() {
        return table;
    }

    public Map<String, String> getDynamicOptions() {
        return dynamicOptions;
    }

    public void putDynamic(String key, String value) {
        dynamicOptions.put(key, value);
    }
}
