import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import picocli.CommandLine;
import java.util.ArrayList;
import java.util.List;

@Configuration
public class ArgsConfig {

    private final String[] args;

    public ArgsConfig(String[] args) {
        this.args = args;
    }

    @Bean
    public AppArguments appArguments() {
        AppArguments parsed = new AppArguments();
        List<String> staticArgs = new ArrayList<>();

        for (int i = 0; i < args.length; i++) {
            String current = args[i];
            if ("--source".equals(current) || "--table".equals(current)) {
                staticArgs.add(current);
                if (i + 1 < args.length) {
                    staticArgs.add(args[++i]);
                }
            } else if (current.startsWith("--")) {
                String key = current.substring(2);
                String value = (i + 1 < args.length) ? args[++i] : "";
                parsed.putDynamic(key, value);
            }
        }

        new CommandLine(parsed).parseArgs(staticArgs.toArray(new String[0]));
        return parsed;
    }
}
