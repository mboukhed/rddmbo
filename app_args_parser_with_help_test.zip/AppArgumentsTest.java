import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import picocli.CommandLine;

public class AppArgumentsTest {

    @Test
    public void testParseStaticAndDynamicArgs() {
        String[] args = {
            "--source", "mySource",
            "--table", "myTable",
            "--env", "dev",
            "--runId", "123"
        };

        AppArguments parsed = new AppArguments();
        CommandLine cmd = new CommandLine(parsed);

        // Simuler prétraitement dynamique
        for (int i = 0; i < args.length; i++) {
            String current = args[i];
            if ("--source".equals(current) || "--table".equals(current)) {
                continue;
            } else if (current.startsWith("--")) {
                String key = current.substring(2);
                String value = (i + 1 < args.length) ? args[++i] : "";
                parsed.putDynamic(key, value);
            }
        }

        cmd.parseArgs("--source", "mySource", "--table", "myTable");

        assertEquals("mySource", parsed.getSource());
        assertEquals("myTable", parsed.getTable());
        assertEquals("dev", parsed.getDynamicOptions().get("env"));
        assertEquals("123", parsed.getDynamicOptions().get("runId"));
    }
}
