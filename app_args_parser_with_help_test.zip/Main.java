import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.registerBean(ArgsConfig.class, () -> new ArgsConfig(args));
        ctx.scan(""); // scanner le package par défaut
        ctx.refresh();

        AppArguments appArgs = ctx.getBean(AppArguments.class);
        System.out.println("Source: " + appArgs.getSource());
        System.out.println("Table: " + appArgs.getTable());
        System.out.println("Dynamic options: " + appArgs.getDynamicOptions());
    }
}
