package com.example.azureauth;

import com.azure.core.credential.TokenCredential;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AzureKeyVaultReader {

    private final SecretClient secretClient;

    public AzureKeyVaultReader(AzureCredentialProvider provider, @Value("${azure.keyvault.name}") String vaultName) {
        TokenCredential credential = provider.getCredential();

        this.secretClient = new SecretClientBuilder()
                .vaultUrl("https://" + vaultName + ".vault.azure.net")
                .credential(credential)
                .buildClient();
    }

    public String getSecretValue(String secretName) {
        return secretClient.getSecret(secretName).getValue();
    }
}