package com.example.azureauth;

import com.azure.identity.ManagedIdentityCredentialBuilder;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.core.credential.TokenCredential;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Profile("vault-client-secret")
public class VaultBackedClientSecretCredentialProvider implements AzureCredentialProvider {

    @Value("${azure.keyvault.name}")
    private String vaultName;

    private SecretClient secretClient;

    @PostConstruct
    public void init() {
        TokenCredential managedIdentity = new ManagedIdentityCredentialBuilder().build();

        this.secretClient = new SecretClientBuilder()
                .vaultUrl("https://" + vaultName + ".vault.azure.net")
                .credential(managedIdentity)
                .buildClient();
    }

    @Override
    public TokenCredential getCredential() {
        String clientId     = secretClient.getSecret("client-id").getValue();
        String clientSecret = secretClient.getSecret("client-secret").getValue();
        String tenantId     = secretClient.getSecret("tenant-id").getValue();

        return new ClientSecretCredentialBuilder()
                .tenantId(tenantId)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .build();
    }
}