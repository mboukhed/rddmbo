package com.example.azureauth;

import com.azure.core.credential.TokenCredential;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AzureBlobStorageClient {

    private final BlobServiceClient blobServiceClient;

    public AzureBlobStorageClient(AzureCredentialProvider provider,
                                   @Value("${azure.storage.account-name}") String accountName) {

        TokenCredential credential = provider.getCredential();
        String endpoint = String.format("https://%s.blob.core.windows.net", accountName);

        this.blobServiceClient = new BlobServiceClientBuilder()
                .endpoint(endpoint)
                .credential(credential)
                .buildClient();
    }

    public void listContainers() {
        blobServiceClient.listBlobContainers().forEach(container -> {
            System.out.println("Container: " + container.getName());
        });
    }
}