package com.example.azureauth;

import com.azure.core.credential.TokenCredential;

public interface AzureCredentialProvider {
    TokenCredential getCredential();
}