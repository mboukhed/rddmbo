package com.example.azureauth;

import com.azure.core.credential.TokenCredential;
import com.azure.identity.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("chained-auth")
public class AzureChainedCredentialProvider implements AzureCredentialProvider {

    @Value("${azure.client-id:}")
    private String clientId;

    @Value("${azure.client-secret:}")
    private String clientSecret;

    @Value("${azure.tenant-id:}")
    private String tenantId;

    @Override
    public TokenCredential getCredential() {
        return new ChainedTokenCredentialBuilder()
                .addFirst(new ManagedIdentityCredentialBuilder().build())
                .addLast(new ClientSecretCredentialBuilder()
                        .clientId(clientId)
                        .clientSecret(clientSecret)
                        .tenantId(tenantId)
                        .build())
                .addLast(new AzureCliCredentialBuilder().build())
                .addLast(new VisualStudioCodeCredentialBuilder().build())
                .build();
    }
}