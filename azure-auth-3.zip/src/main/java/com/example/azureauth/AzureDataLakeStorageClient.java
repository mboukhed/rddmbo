package com.example.azureauth;

import com.azure.core.credential.TokenCredential;
import com.azure.storage.file.datalake.DataLakeServiceClient;
import com.azure.storage.file.datalake.DataLakeServiceClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AzureDataLakeStorageClient {

    private final DataLakeServiceClient dataLakeServiceClient;

    public AzureDataLakeStorageClient(AzureCredentialProvider provider,
                                      @Value("${azure.storage.account-name}") String accountName) {

        TokenCredential credential = provider.getCredential();
        String endpoint = String.format("https://%s.dfs.core.windows.net", accountName);

        this.dataLakeServiceClient = new DataLakeServiceClientBuilder()
                .endpoint(endpoint)
                .credential(credential)
                .buildClient();
    }

    public void listFileSystems() {
        dataLakeServiceClient.listFileSystems().forEach(fs -> {
            System.out.println("Filesystem: " + fs.getName());
        });
    }
}