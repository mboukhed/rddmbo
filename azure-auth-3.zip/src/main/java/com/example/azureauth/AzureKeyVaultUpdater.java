package com.example.azureauth;

import com.azure.core.credential.TokenCredential;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AzureKeyVaultUpdater {

    private final SecretClient secretClient;

    public AzureKeyVaultUpdater(AzureCredentialProvider provider,
                                 @Value("${azure.keyvault.name}") String vaultName) {
        TokenCredential credential = provider.getCredential();

        this.secretClient = new SecretClientBuilder()
                .vaultUrl("https://" + vaultName + ".vault.azure.net")
                .credential(credential)
                .buildClient();
    }

    public void updateSecret(String name, String value) {
        KeyVaultSecret secret = secretClient.setSecret(name, value);
        System.out.println("Secret updated: " + secret.getName() + " = " + secret.getValue());
    }
}