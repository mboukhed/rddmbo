
def launch_proxy() {
    // Contenu supprimé pour confidentialité (proxy, domaine, etc.)
}


def getAzureCredentials(String envName) {
    def envKey = envName.trim().toLowerCase()
    def suffix = ''

    switch (envKey) {
        case 'dev':
            suffix = 'dev'
            break
        case 'prod':
            suffix = 'prod'
            break
        case 'iso':
            suffix = 'iso'
            break
        default:
            error "Environnement inconnu : ${envName}"
    }

    def creds = [:]

    withCredentials([
        azureServicePrincipal(
            credentialsId: "azure_spn_eqd_${suffix}",
            subscriptionIdVariable: 'AZ_SUBSCRIPTION_ID',
            clientIdVariable: 'AZ_CLIENT_ID',
            clientSecretVariable: 'AZ_CLIENT_SECRET',
            tenantIdVariable: 'AZ_TENANT_ID'
        ),
        string(credentialsId: "az_account_name_${suffix}", variable: 'AZ_ACCOUNT_NAME'),
        string(credentialsId: "az_container_name_${suffix}", variable: 'AZ_CONTAINER')
    ]) {
        creds.CLIENT_ID        = env.AZ_CLIENT_ID
        creds.CLIENT_SECRET    = env.AZ_CLIENT_SECRET
        creds.TENANT_ID        = env.AZ_TENANT_ID
        creds.SUBSCRIPTION_ID = env.AZ_SUBSCRIPTION_ID
        creds.ACCOUNT_NAME     = env.AZ_ACCOUNT_NAME
        creds.CONTAINER        = env.AZ_CONTAINER
    }

    return creds
}
