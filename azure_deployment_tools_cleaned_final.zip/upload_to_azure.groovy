
def uploadAndUnzipToAzure(String zipPath, String envName, String accountName, String container) {
    azure_login(envName)

    def zipFile = new File(zipPath)
    if (!zipFile.exists()) {
        error "ZIP file not found: ${zipPath}"
    }

    def zipFileName = zipFile.name
    def baseName = zipFileName.replaceAll(/\.zip$/, '')

    sh """
        echo "🧹 Delete existing target directory: ${baseName}/"
        az storage blob delete-batch \
          --account-name ${accountName} \
          --source "${container}" \
          --pattern "${baseName}/*" \
          --auth-mode login || true

        echo "📤 Upload zip to root: $zipFileName"
        az storage blob upload \
          --account-name ${accountName} \
          --container-name ${container} \
          --file "${zipPath}" \
          --name "$zipFileName" \
          --auth-mode login

        echo "📦 Unzipping locally"
        mkdir -p unzip_tmp
        unzip -o "${zipPath}" -d unzip_tmp

        echo "⬆ Upload unzipped content to ${baseName}/"
        az storage blob upload-batch \
          --account-name ${accountName} \
          --destination "${container}/${baseName}" \
          --source unzip_tmp \
          --auth-mode login

        rm -rf unzip_tmp

        echo "🗑 Delete uploaded zip: $zipFileName"
        az storage blob delete \
          --account-name ${accountName} \
          --container-name ${container} \
          --name "$zipFileName" \
          --auth-mode login

        echo "✅ DONE: Deployed into ${container}/${baseName}/"
    """
}


def uploadDirectoryToAzure(String envName, String localDirPath, String accountName, String container, String remotePath) {
    azure_login(envName) // Se connecte à Azure avec SPN et proxy si activé

    sh """
        echo "🧹 Deleting existing content at ${container}/${remotePath}/"
        az storage blob delete-batch \
            --account-name ${accountName} \
            --source "${container}" \
            --pattern "${remotePath}/*" \
            --auth-mode login || true

        echo "⬆ Uploading entire directory ${localDirPath} to ${container}/${remotePath}/"
        az storage blob upload-batch \
            --account-name ${accountName} \
            --destination "${container}/${remotePath}" \
            --source "${localDirPath}" \
            --auth-mode login

        echo "✅ Upload complete at ${container}/${remotePath}/"
    """
}
