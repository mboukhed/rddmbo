
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileStatus;

import java.util.List;
import java.util.Map;

public class AzureFileExample {
    public static void main(String[] args) throws Exception {
        String directory = "abfs://container@account.dfs.core.windows.net/path/to/folder";

        Configuration conf = new Configuration();
        conf.set("fs.defaultFS", "abfs://...");
        conf.set("fs.azure.account.auth.type.account.dfs.core.windows.net", "OAuth");
        conf.set("fs.azure.account.oauth.provider.type.account.dfs.core.windows.net", 
                 "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
        conf.set("fs.azure.account.oauth2.client.id.account.dfs.core.windows.net", "XXX");
        conf.set("fs.azure.account.oauth2.client.secret.account.dfs.core.windows.net", "YYY");
        conf.set("fs.azure.account.oauth2.client.endpoint.account.dfs.core.windows.net", 
                 "https://login.microsoftonline.com/tenantId/oauth2/token");

        List<FileStatus> files = AzureFileLister.listFilesFromAzure(directory, conf);
        Map<String[], java.sql.Date> fileMap = AzureFileProcessor.mapFilesWithTypeAndDate(files);

        for (Map.Entry<String[], java.sql.Date> entry : fileMap.entrySet()) {
            System.out.println("Path: " + entry.getKey()[0] + ", Type: " + entry.getKey()[1] + ", Date: " + entry.getValue());
        }
    }
}
