
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AzureFileLister {

    public static List<FileStatus> listFilesFromAzure(String directoryPath, Configuration hadoopConf) throws IOException {
        FileSystem fs = FileSystem.get(hadoopConf);
        Path dirPath = new Path(directoryPath);
        List<FileStatus> files = new ArrayList<>();

        RemoteIterator<LocatedFileStatus> fileIterator = fs.listFiles(dirPath, false);
        while (fileIterator.hasNext()) {
            files.add(fileIterator.next());
        }

        return files;
    }
}
