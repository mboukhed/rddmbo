
import java.sql.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.hadoop.fs.FileStatus;

public class AzureFileProcessor {

    public static Map<String[], Date> mapFilesWithTypeAndDate(List<FileStatus> fileStatusList) {
        Map<String[], Date> result = new HashMap<>();

        for (FileStatus fileStatus : fileStatusList) {
            String fullPath = fileStatus.getPath().toString();
            String fileName = fileStatus.getPath().getName();

            String typeSuffix = extractTypeFromName(fileName);
            Date modificationDate = new Date(fileStatus.getModificationTime());

            result.put(new String[]{fullPath, typeSuffix}, modificationDate);
        }

        return result;
    }

    private static String extractTypeFromName(String fileName) {
        return fileName.replaceAll("\D+", "");
    }
}
