def isRunning = sh(
    script: 'ss -ltnp | grep -q ":3128" || netstat -tulpen | grep -q ":3128"',
    returnStatus: true
) == 0

if (isRunning) {
    echo "[CNTLM] Déjà lancé → on saute le démarrage"
    return
}
