import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.HashMap;
import java.nio.file.Files;
import java.nio.file.Paths;

@Component
public class CredentialManager {
    @Value("${spring.profiles.active:local}")
    private String profile;
    @Value("${vault.url:}")
    private String vaultUrl;
    @Value("${vault.token:}")
    private String vaultToken;
    @Value("${vault.role-id:}")
    private String roleId;
    @Value("${vault.secret-id:}")
    private String secretId;
    @Value("${azure.keyvault.url:}")
    private String keyVaultUrl;
    @Value("${azure.client.id:}")
    private String clientId;

    private final RestTemplate rest = new RestTemplate();
    private final ObjectMapper mapper = new ObjectMapper();

    public Credentials getCredentials() {
        switch(profile.toLowerCase()) {
            case "local": return getLocalCredentials();
            case "dev": return getVaultCredentials();
            case "test": return getK8sCredentials();
            case "prod": return getAzureCredentials();
            default: throw new RuntimeException("Profil non supporté: " + profile);
        }
    }

    private Credentials getLocalCredentials() {
        Credentials c = new Credentials();
        c.sparkHost = "http://localhost:8080";
        c.sparkToken = "local-token";
        c.sparkCluster = "local-cluster";
        c.fsAccessKey = "local-access";
        c.fsSecretKey = "local-secret";
        return c;
    }

    private Credentials getVaultCredentials() {
        try {
            String token = vaultToken.isEmpty() ? getVaultToken() : vaultToken;
            JsonNode spark = getVaultSecret(token, "secret/spark/dev");
            JsonNode fs = getVaultSecret(token, "secret/filesystem/dev");
            Credentials c = new Credentials();
            c.sparkHost = spark.get("host").asText();
            c.sparkToken = spark.get("token").asText();
            c.sparkCluster = spark.get("cluster_id").asText();
            c.fsAccessKey = fs.get("access_key").asText();
            c.fsSecretKey = fs.get("secret_key").asText();
            return c;
        } catch (Exception e) {
            throw new RuntimeException("Erreur Vault", e);
        }
    }

    private Credentials getK8sCredentials() {
        try {
            Credentials c = new Credentials();
            c.sparkHost = readSecret("spark-secrets/host");
            c.sparkToken = readSecret("spark-secrets/token");
            c.sparkCluster = readSecret("spark-secrets/cluster-id");
            c.fsAccessKey = readSecret("fs-secrets/access-key");
            c.fsSecretKey = readSecret("fs-secrets/secret-key");
            return c;
        } catch (Exception e) {
            throw new RuntimeException("Erreur K8s secrets", e);
        }
    }

    private Credentials getAzureCredentials() {
        try {
            String token = getManagedIdentityToken();
            Credentials c = new Credentials();
            c.sparkHost = getKeyVaultSecret(token, "spark-host");
            c.sparkToken = getKeyVaultSecret(token, "spark-token");
            c.sparkCluster = getKeyVaultSecret(token, "spark-cluster-id");
            c.fsManagedId = clientId;
            c.fsAccountName = getKeyVaultSecret(token, "storage-account-name");
            return c;
        } catch (Exception e) {
            throw new RuntimeException("Erreur Azure", e);
        }
    }

    private String getVaultToken() throws Exception {
        Map<String, String> auth = new HashMap<>();
        auth.put("role_id", roleId);
        auth.put("secret_id", secretId);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        ResponseEntity<String> response = rest.postForEntity(vaultUrl + "/v1/auth/approle/login", new HttpEntity<>(auth, headers), String.class);
        return mapper.readTree(response.getBody()).get("auth").get("client_token").asText();
    }

    private JsonNode getVaultSecret(String token, String path) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Vault-Token", token);
        ResponseEntity<String> response = rest.exchange(vaultUrl + "/v1/" + path, HttpMethod.GET, new HttpEntity<>(headers), String.class);
        return mapper.readTree(response.getBody()).get("data");
    }

    private String readSecret(String path) throws Exception {
        return new String(Files.readAllBytes(Paths.get("/var/run/secrets/" + path))).trim();
    }

    private String getManagedIdentityToken() throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Metadata", "true");
        String url = "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net";
        if (!clientId.isEmpty()) url += "&client_id=" + clientId;
        ResponseEntity<String> response = rest.exchange(url, HttpMethod.GET, new HttpEntity<>(headers), String.class);
        return mapper.readTree(response.getBody()).get("access_token").asText();
    }

    private String getKeyVaultSecret(String token, String secretName) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + token);
        ResponseEntity<String> response = rest.exchange(keyVaultUrl + "/secrets/" + secretName + "?api-version=7.3", HttpMethod.GET, new HttpEntity<>(headers), String.class);
        return mapper.readTree(response.getBody()).get("value").asText();
    }
}
