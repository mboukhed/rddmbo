package com.example;

public class Credentials {
    public String sparkHost, sparkToken, sparkUser, sparkPassword, sparkCluster;
    public String fsAccessKey, fsSecretKey, fsAccountName, fsAccountKey, fsSasToken, fsManagedId;
}
