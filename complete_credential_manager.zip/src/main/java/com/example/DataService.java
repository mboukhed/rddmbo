package com.example;

import org.springframework.stereotype.Component;

@Component
public class DataService {
    private final CredentialManager credManager;

    public DataService(CredentialManager credManager) {
        this.credManager = credManager;
    }

    public void process() {
        Credentials creds = credManager.getCredentials();
        String sparkUrl = creds.sparkHost + "/api/clusters/" + creds.sparkCluster;

        if (creds.fsManagedId != null) {
            System.setProperty("spark.hadoop.fs.azure.account.auth.type." + creds.fsAccountName + ".dfs.core.windows.net", "OAuth");
            System.setProperty("spark.hadoop.fs.azure.account.oauth.provider.type." + creds.fsAccountName + ".dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.MsiTokenProvider");
            System.setProperty("spark.hadoop.fs.azure.account.oauth2.msi.endpoint", "http://169.254.169.254/metadata/identity/oauth2/token");
            System.setProperty("spark.hadoop.fs.azure.account.oauth2.client.id", creds.fsManagedId);
        } else if (creds.fsAccessKey != null) {
            System.setProperty("spark.hadoop.fs.s3a.access.key", creds.fsAccessKey);
            System.setProperty("spark.hadoop.fs.s3a.secret.key", creds.fsSecretKey);
        }
    }
}
