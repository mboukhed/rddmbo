package com.yourcompany.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

@Configuration
public class CommonAppConfig {

    @Value("classpath:${spring.profiles.active}/application.properties")
    private Resource resource;

    @Bean
    public Properties applicationProperties() throws IOException {
        Properties properties = new Properties();

        try (InputStream inputStream = resource.getInputStream()) {
            properties.load(inputStream);
        }

        return properties;
    }
}
