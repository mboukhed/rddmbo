package com.yourcompany.config;

import org.springframework.context.annotation.*;
import org.springframework.core.env.Environment;

import java.util.Properties;

@Configuration
@PropertySource("classpath:${spring.profiles.active}/application.properties")
public class CommonAppConfig {

    @Bean
    public Properties applicationProperties(Environment env) {
        Properties properties = new Properties();
        properties.setProperty("example", env.getProperty("example", "default-value"));
        return properties;
    }
}
