package com.example.auth;

public interface CredentialProvider {
    String getClientId();
    String getClientSecret();
    String getTenantId();
    String getAuthenticationMode();
}
