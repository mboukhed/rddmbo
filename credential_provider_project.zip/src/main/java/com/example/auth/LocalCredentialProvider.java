package com.example.auth;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("local")
public class LocalCredentialProvider implements CredentialProvider {

    @Override
    public String getClientId() {
        return System.getenv("CLIENT_ID");
    }

    @Override
    public String getClientSecret() {
        return System.getenv("CLIENT_SECRET");
    }

    @Override
    public String getTenantId() {
        return System.getenv("TENANT_ID");
    }

    @Override
    public String getAuthenticationMode() {
        return "local_env";
    }
}
