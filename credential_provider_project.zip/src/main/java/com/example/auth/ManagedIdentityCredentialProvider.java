package com.example.auth;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("aks")
public class ManagedIdentityCredentialProvider implements CredentialProvider {

    @Override
    public String getClientId() {
        return null;
    }

    @Override
    public String getClientSecret() {
        return null;
    }

    @Override
    public String getTenantId() {
        return System.getenv("AZURE_TENANT_ID");
    }

    @Override
    public String getAuthenticationMode() {
        return "managed_identity";
    }
}
