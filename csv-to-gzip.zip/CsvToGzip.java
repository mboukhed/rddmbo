import java.io.*;
import java.util.zip.GZIPOutputStream;

public class CsvToGzip {

    public static void compressCsvToGz(String inputCsvPath, String outputGzPath) throws IOException {
        try (
            FileInputStream fis = new FileInputStream(inputCsvPath);
            FileOutputStream fos = new FileOutputStream(outputGzPath);
            GZIPOutputStream gzipOS = new GZIPOutputStream(fos)
        ) {
            byte[] buffer = new byte[1024];
            int len;
            while ((len = fis.read(buffer)) != -1) {
                gzipOS.write(buffer, 0, len);
            }
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.err.println("Usage: java CsvToGzip <input.csv> <output.gz>");
            System.exit(1);
        }
        compressCsvToGz(args[0], args[1]);
    }
}