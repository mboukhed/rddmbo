
package utils;

public interface CucumberRunnerProvider {
    String getRunnerClassName();
}
