
package utils;

import java.util.ArrayList;
import java.util.List;

public class CucumberUtils {

    public static int launchCucumberInSeparateJVM(CucumberRunnerProvider provider, String tagName) {
        List<String> args = new ArrayList<>();

        args.add("--add-opens=java.base/java.lang=ALL-UNNAMED");
        args.add("-Dfile.encoding=UTF-8");
        args.add("-cp");
        args.add(System.getProperty("java.class.path"));
        args.add("org.junit.platform.console.ConsoleLauncher");
        args.add("--disable-banner");
        args.add("--select-class=" + provider.getRunnerClassName());

        if (tagName != null && !tagName.isEmpty()) {
            args.add("--config");
            args.add("cucumber.filter.tags=" + tagName);
        }

        return executeJavaProcess(args);
    }

    private static int executeJavaProcess(List<String> args) {
        try {
            ProcessBuilder pb = new ProcessBuilder("java", args.toArray(new String[0]));
            pb.inheritIO();
            Process process = pb.start();
            return process.waitFor();
        } catch (Exception e) {
            throw new RuntimeException("Failed to launch test runner", e);
        }
    }
}
