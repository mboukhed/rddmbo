
import runner.CucumberPipelineRunnerProvider;
import utils.CucumberUtils;

public class TestLauncher {
    public static void main(String[] args) {
        int exitCode = CucumberUtils.launchCucumberInSeparateJVM(
            new CucumberPipelineRunnerProvider(),
            "@monTag"
        );
        System.exit(exitCode);
    }
}
