
package runner;

import utils.CucumberRunnerProvider;

public class CucumberPipelineRunnerProvider implements CucumberRunnerProvider {
    @Override
    public String getRunnerClassName() {
        return "runner.CucumberPipelineRunner";
    }
}
