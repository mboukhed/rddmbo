package com.example.steps;

import io.cucumber.java.en.Given;

public class SimpleSteps {

    @Given("I print the current process PID")
    public void printPid() {
        System.out.println("PID: " + ProcessHandle.current().pid());
    }
}
