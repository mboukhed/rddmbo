package com.example.steps;

import io.cucumber.java.en.*;
import static org.junit.jupiter.api.Assertions.*;

public class SampleSteps {

    private int a, b, result;

    @Given("I have numbers {int} and {int}")
    public void i_have_numbers(int x, int y) {
        this.a = x;
        this.b = y;
    }

    @When("I add them")
    public void i_add_them() {
        this.result = a + b;
    }

    @Then("the result should be {int}")
    public void the_result_should_be(int expected) {
        assertEquals(expected, result);
    }
}
