@Component
public class CucumberHooks {
    // ... [contenu tronqué pour concision dans le code Python]
}
