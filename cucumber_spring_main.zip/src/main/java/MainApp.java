public class MainApp {
    public static org.springframework.context.annotation.AnnotationConfigApplicationContext context;

    public static void main(String[] args) {
        context = new org.springframework.context.annotation.AnnotationConfigApplicationContext(AppConfig.class);
        context.getBean(MyService.class).run();

        if (!"test".equals(System.getProperty("env"))) {
            context.registerShutdownHook();
        }
    }
}
