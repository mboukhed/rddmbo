public class MyService {
    public void run() {
        System.out.println("Service lancé !");
    }
}
