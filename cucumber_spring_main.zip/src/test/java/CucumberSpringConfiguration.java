import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.context.annotation.Configuration;

@CucumberContextConfiguration
@ContextConfiguration(classes = AppConfig.class)
@Configuration
public class CucumberSpringConfiguration {
}
