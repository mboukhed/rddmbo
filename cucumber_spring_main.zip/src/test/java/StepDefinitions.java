import io.cucumber.java.en.Given;

public class StepDefinitions {
    @Given("je lance le main")
    public void jeLanceLeMain() {
        if (MainApp.context == null) {
            System.setProperty("env", "test");
            MainApp.main(new String[]{});
        }

        MyService service = MainApp.context.getBean(MyService.class);
        service.run();
    }
}
