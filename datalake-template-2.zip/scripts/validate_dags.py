#!/usr/bin/env python3
import os
import sys
from airflow.models.dagbag import DagBag

def validate_dags(dag_folder):
    dag_bag = DagBag(dag_folder, include_examples=False)
    if dag_bag.import_errors:
        print("Some DAGs failed to import:")
        for dag_id, error in dag_bag.import_errors.items():
            print(f"{dag_id}: {error}")
        return False
    print(f"All {len(dag_bag.dags)} DAGs successfully loaded.")
    return True

if __name__ == '__main__':
    path = sys.argv[1] if len(sys.argv) > 1 else 'dags'
    if not validate_dags(path):
        sys.exit(1)
