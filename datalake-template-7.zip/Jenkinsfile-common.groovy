def launch_proxy() {
    withCredentials([usernamePassword(credentialsId: 'PROXY_CREDENTIALS', usernameVariable: 'PROXY_USER', passwordVariable: 'PROXY_PASS')]) {
        sh '''
        echo "username ${PROXY_USER}" > /etc/cntlm.conf
        echo "password ${PROXY_PASS}" >> /etc/cntlm.conf
        echo "domain WORKGROUP" >> /etc/cntlm.conf
        echo "proxy YOUR_PROXY_HOST:PORT" >> /etc/cntlm.conf
        echo "listen 3128" >> /etc/cntlm.conf
        cntlm -f -c /etc/cntlm.conf &
        '''
    }
}

def azure_login() {
    withCredentials([usernamePassword(credentialsId: 'AZURE_CREDENTIALS', usernameVariable: 'AZURE_CLIENT_ID', passwordVariable: 'AZURE_SECRET')]) {
        sh '''
        az login --service-principal -u $AZURE_CLIENT_ID -p $AZURE_SECRET --tenant YOUR_TENANT_ID
        '''
    }
}

def prepareAzureDirectory(accountName, containerName, targetDir) {
    def exists = sh(
        script: """
            az storage fs directory exists \
              --account-name ${accountName} \
              --file-system ${containerName} \
              --name ${targetDir} \
              --auth-mode login \
              --query exists -o tsv
        """,
        returnStdout: true
    ).trim()

    if (exists == "true") {
        echo "Directory exists. Deleting contents..."
        sh """
            az storage fs file delete-batch \
              --account-name ${accountName} \
              --source ${containerName}/${targetDir} \
              --auth-mode login --yes
        """
    } else {
        echo "Creating directory in Azure..."
        sh """
            az storage fs directory create \
              --account-name ${accountName} \
              --file-system ${containerName} \
              --name ${targetDir} \
              --auth-mode login
        """
    }
}

def push_to_jfrog(moduleName) {
    withCredentials([file(credentialsId: 'MAVEN_SETTINGS', variable: 'MAVEN_SETTINGS')]) {
        sh """
            mvn deploy:deploy-file -s $MAVEN_SETTINGS \
                -DgroupId=com.example \
                -DartifactId=${moduleName} \
                -Dversion=1.0.0 \
                -Dpackaging=jar \
                -Dfile=./${moduleName}/target/${moduleName}-1.0.0.jar \
                -DrepositoryId=central \
                -Durl=https://your.jfrog.server/artifactory/libs-release-local
        """
    }
}

def copy_to_azure(accountName, containerName, directory) {
    sh """
        az storage blob upload-batch \
          --account-name ${accountName} \
          --destination ${containerName}/${directory} \
          --source ./target \
          --auth-mode login
    """
}

def upload_dag() {
    sh """
        git clone https://your.git.repo/airflow-dags.git
        az storage blob upload-batch \
          --account-name $AZURE_STORAGE_ACCOUNT \
          --destination $AZURE_CONTAINER_NAME/$AZURE_DIRECTORY/airflow_dags \
          --source airflow-dags \
          --auth-mode login
    """
}


def clean_previous_versions(accountName, containerName, baseDir, keepVersion) {
    if (keepVersion.toBoolean()) {
        echo "✅ Option enabled: keeping existing versioned directories."
        return
    }

    echo "🧹 Cleaning existing directories under ${baseDir}..."

    def directories = sh(
        script: """
        az storage fs directory list \
          --account-name ${accountName} \
          --file-system ${containerName} \
          --auth-mode login \
          --query "[?starts_with(name, '${baseDir}/')].name" -o tsv
        """,
        returnStdout: true
    ).trim().split("\n")

    for (dir in directories) {
        if (!dir.endsWith("latest")) {
            echo "Deleting: ${dir}"
            sh """
                az storage fs file delete-batch \
                  --account-name ${accountName} \
                  --source ${containerName}/${dir} \
                  --auth-mode login --yes
            """
        }
    }
}
