

## 🔗 Azure versioning & symbolic link (simulé)

Lors du déploiement vers Azure (ADLS Gen2), les artefacts sont copiés dans un sous-répertoire :

    /<container>/<branch>/<version>/

Pour faciliter l’accès à la version "active", un lien symbolique logique est simulé
en copiant les fichiers dans :

    /<container>/<branch>/latest/

Ainsi, vous pouvez changer dynamiquement la version visible via :

- Re-synchronisation manuelle (`az storage blob copy`)
- Ou suppression du dossier `latest` + re-upload

