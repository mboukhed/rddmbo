# Datalake Jenkins Pipeline Template

This Jenkins pipeline is intended for building and deploying selected Maven modules to both JFrog and Azure Data Lake (ADLS Gen2). It also supports optional DAG upload for Airflow.

## Features

- GitHub Multibranch support (branch auto-detected)
- Azure ADLS target directory creation or cleanup
- Modular Maven build (specify which modules to compile)
- Push artifacts to JFrog
- Copy artifacts to Azure
- Proxy support and dynamic DAG upload

## Required Jenkins Credentials

- `AZURE_STORAGE_ACCOUNT`
- `AZURE_CONTAINER_NAME`
- `AZURE_CREDENTIALS` (optional if using `az login` already)

## Usage

Define your Jenkins job as a **Multibranch Pipeline** pointing to a GitHub repository containing:

- `Jenkinsfile`
- `Jenkinsfile-common.groovy`

Customize module names, target directories, and DAG logic as needed.
