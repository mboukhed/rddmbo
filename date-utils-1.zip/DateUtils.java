import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class DateUtils {

    public static Date toValidatedSqlDate(String value, String format) throws IllegalArgumentException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            LocalDate localDate = LocalDate.parse(value, formatter);
            int year = localDate.getYear();
            if (year < 1582 || year > 9999) {
                throw new IllegalArgumentException("Année invalide : " + year);
            }
            return Date.valueOf(localDate);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Format ou valeur de date invalide : " + value + " avec format " + format, e);
        }
    }

    public static Timestamp toValidatedSqlTimestamp(String value, String format) throws IllegalArgumentException {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
            LocalDateTime dateTime = LocalDateTime.parse(value, formatter);
            int year = dateTime.getYear();
            if (year < 1582 || year > 9999) {
                throw new IllegalArgumentException("Année invalide : " + year);
            }
            return Timestamp.valueOf(dateTime);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Format ou valeur de timestamp invalide : " + value + " avec format " + format, e);
        }
    }
}