import org.junit.jupiter.api.Test;
import java.sql.Date;
import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.*;

public class DateUtilsTest {

    @Test
    public void testValidDate() {
        Date date = DateUtils.toValidatedSqlDate("07-02-2025", "dd-MM-yyyy");
        assertEquals(Date.valueOf("2025-02-07"), date);
    }

    @Test
    public void testInvalidDateYearTooLow() {
        assertThrows(IllegalArgumentException.class, () -> {
            DateUtils.toValidatedSqlDate("01-01-1500", "dd-MM-yyyy");
        });
    }

    @Test
    public void testValidTimestamp() {
        Timestamp ts = DateUtils.toValidatedSqlTimestamp("2025-02-07 08:00:00", "yyyy-MM-dd HH:mm:ss");
        assertEquals(Timestamp.valueOf("2025-02-07 08:00:00"), ts);
    }

    @Test
    public void testInvalidTimestampYearTooHigh() {
        assertThrows(IllegalArgumentException.class, () -> {
            DateUtils.toValidatedSqlTimestamp("99999-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss");
        });
    }
}