import java.math.BigDecimal;

public class DecimalUtils {

    public static BigDecimal toScaledBigDecimal(String value, int scale) throws IllegalArgumentException {
        try {
            BigDecimal bd = new BigDecimal(value);
            return bd.setScale(scale, BigDecimal.ROUND_HALF_UP);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Valeur invalide pour BigDecimal : " + value, e);
        }
    }
}