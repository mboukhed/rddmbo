import org.junit.jupiter.api.Test;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

public class DecimalUtilsTest {

    @Test
    public void testValidScale() {
        BigDecimal bd = DecimalUtils.toScaledBigDecimal("1234.56789", 2);
        assertEquals(new BigDecimal("1234.57"), bd);
    }

    @Test
    public void testInvalidValue() {
        assertThrows(IllegalArgumentException.class, () -> {
            DecimalUtils.toScaledBigDecimal("abc", 2);
        });
    }

    @Test
    public void testZeroScale() {
        BigDecimal bd = DecimalUtils.toScaledBigDecimal("1234.56789", 0);
        assertEquals(new BigDecimal("1235"), bd);
    }
}