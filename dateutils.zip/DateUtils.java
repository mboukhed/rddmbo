import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class DateUtils {

    private static final List<String> DATE_FORMATS = Arrays.asList(
        "yyyy-MM-dd",
        "dd/MM/yyyy",
        "MM/dd/yyyy",
        "dd-MM-yyyy",
        "yyyy/MM/dd",
        "dd MMM yyyy",
        "dd.MM.yyyy",
        "yyyyMMdd",
        "dd MMMM yyyy",
        "EEE, dd MMM yyyy",
        "ddMMyyyy"
    );

    public static Date parseToSqlDate(String dateStr) {
        for (String format : DATE_FORMATS) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(format, Locale.FRANCE);
                sdf.setLenient(false);
                java.util.Date parsed = sdf.parse(dateStr);
                return new Date(parsed.getTime());
            } catch (ParseException ignored) {
            }
        }
        throw new IllegalArgumentException("Date invalide ou format non pris en charge: " + dateStr);
    }
}