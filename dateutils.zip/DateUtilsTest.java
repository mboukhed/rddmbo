import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class DateUtilsTest {

    @Test
    @DisplayName("Test format ISO yyyy-MM-dd")
    void testIsoFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("2025-06-29"));
    }

    @Test
    @DisplayName("Test format européen dd/MM/yyyy")
    void testEuropeanFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29/06/2025"));
    }

    @Test
    @DisplayName("Test format US MM/dd/yyyy")
    void testUsFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("06/29/2025"));
    }

    @Test
    @DisplayName("Test format avec tirets dd-MM-yyyy")
    void testDashFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29-06-2025"));
    }

    @Test
    @DisplayName("Test format compact ddMMyyyy")
    void testCompactFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29062025"));
    }

    @Test
    @DisplayName("Test format yyyyMMdd")
    void testNoSeparatorFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("20250629"));
    }

    @Test
    @DisplayName("Test format dd.MM.yyyy")
    void testDotFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29.06.2025"));
    }

    @Test
    @DisplayName("Test format texte court dd MMM yyyy")
    void testShortTextFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29 juin 2025"));
    }

    @Test
    @DisplayName("Test format texte long dd MMMM yyyy")
    void testLongTextFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("29 juin 2025"));
    }

    @Test
    @DisplayName("Test format avec jour texte EEE, dd MMM yyyy")
    void testDayTextFormat() {
        Date expected = Date.valueOf("2025-06-29");
        assertEquals(expected, DateUtils.parseToSqlDate("dim., 29 juin 2025"));
    }

    @Test
    @DisplayName("Test date invalide")
    void testInvalidDate() {
        assertThrows(IllegalArgumentException.class, () -> {
            DateUtils.parseToSqlDate("invalid-date");
        });
    }
}