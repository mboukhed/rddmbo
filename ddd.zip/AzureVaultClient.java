
import java.io.*;
import java.net.*;
import java.util.*;

public class AzureVaultClient {

    private final String clientId;
    private final String clientSecret;
    private final String tenantId;
    private final String vaultBaseUrl;

    public AzureVaultClient(String clientId, String clientSecret, String tenantId, String vaultBaseUrl) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.tenantId = tenantId;
        this.vaultBaseUrl = vaultBaseUrl;
    }

    public Optional<String> getSecret(String secretName) {
        try {
            String accessToken = fetchAccessToken();
            return fetchSecretValue(secretName, accessToken);
        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private String fetchAccessToken() throws IOException {
        String tokenEndpoint = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

        String body = "client_id=" + URLEncoder.encode(clientId, "UTF-8") +
                "&scope=" + URLEncoder.encode("https://vault.azure.net/.default", "UTF-8") +
                "&client_secret=" + URLEncoder.encode(clientSecret, "UTF-8") +
                "&grant_type=client_credentials";

        HttpURLConnection conn = (HttpURLConnection) new URL(tokenEndpoint).openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes());
        }

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("Token request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return extractJsonField(json, "access_token");
    }

    private Optional<String> fetchSecretValue(String secretName, String accessToken) throws IOException {
        String apiUrl = vaultBaseUrl + "/secrets/" + secretName + "?api-version=7.4";

        HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("Secret request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return Optional.ofNullable(extractJsonField(json, "value"));
    }

    private String readResponse(InputStream in) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
            }
            return out.toString();
        }
    }

    private String extractJsonField(String json, String field) {
        String pattern = """ + field + ""\s*:\s*"([^"]+)"";
        return json.matches(".*" + pattern + ".*")
                ? json.replaceAll(".*" + pattern + ".*", "$1")
                : null;
    }
}
