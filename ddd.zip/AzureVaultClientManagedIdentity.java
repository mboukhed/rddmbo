
import java.io.*;
import java.net.*;
import java.util.Optional;

public class AzureVaultClientManagedIdentity {

    private final String vaultBaseUrl;

    public AzureVaultClientManagedIdentity(String vaultBaseUrl) {
        this.vaultBaseUrl = vaultBaseUrl;
    }

    public Optional<String> getSecret(String secretName) {
        try {
            String accessToken = fetchManagedIdentityToken();
            return fetchSecretValue(secretName, accessToken);
        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private String fetchManagedIdentityToken() throws IOException {
        String msiUrl = "http://169.254.169.254/metadata/identity/oauth2/token"
                + "?api-version=2018-02-01"
                + "&resource=" + URLEncoder.encode("https://vault.azure.net", "UTF-8");

        HttpURLConnection conn = (HttpURLConnection) new URL(msiUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Metadata", "true");

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("MSI token request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return extractJsonField(json, "access_token");
    }

    private Optional<String> fetchSecretValue(String secretName, String accessToken) throws IOException {
        String apiUrl = vaultBaseUrl + "/secrets/" + secretName + "?api-version=7.4";

        HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("Secret request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return Optional.ofNullable(extractJsonField(json, "value"));
    }

    private String readResponse(InputStream in) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
            }
            return out.toString();
        }
    }

    private String extractJsonField(String json, String field) {
        String pattern = """ + field + ""\s*:\s*"([^"]+)"";
        return json.matches(".*" + pattern + ".*")
                ? json.replaceAll(".*" + pattern + ".*", "$1")
                : null;
    }
}
