
import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.cert.CertificateException;
import java.util.Optional;

public class AzureVaultClientWithCertificate {

    private final String vaultBaseUrl;
    private final String tenantId;
    private final String clientId;
    private final String certPath;
    private final String certPassword;

    public AzureVaultClientWithCertificate(String vaultBaseUrl, String tenantId, String clientId,
                                           String certPath, String certPassword) {
        this.vaultBaseUrl = vaultBaseUrl;
        this.tenantId = tenantId;
        this.clientId = clientId;
        this.certPath = certPath;
        this.certPassword = certPassword;
    }

    public Optional<String> getSecret(String secretName) {
        try {
            String accessToken = fetchAccessTokenWithCert();
            return fetchSecretValue(secretName, accessToken);
        } catch (Exception e) {
            e.printStackTrace();
            return Optional.empty();
        }
    }

    private String fetchAccessTokenWithCert() throws Exception {
        String tokenUrl = "https://login.microsoftonline.com/" + tenantId + "/oauth2/v2.0/token";

        String body = "client_id=" + URLEncoder.encode(clientId, "UTF-8") +
                "&scope=" + URLEncoder.encode("https://vault.azure.net/.default", "UTF-8") +
                "&grant_type=client_credentials";

        HttpsURLConnection conn = (HttpsURLConnection) new URL(tokenUrl).openConnection();
        conn.setSSLSocketFactory(buildSSLSocketFactory(certPath, certPassword));
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

        try (OutputStream os = conn.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("Token request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return extractJsonField(json, "access_token");
    }

    private Optional<String> fetchSecretValue(String secretName, String accessToken) throws IOException {
        String apiUrl = vaultBaseUrl + "/secrets/" + secretName + "?api-version=7.4";

        HttpURLConnection conn = (HttpURLConnection) new URL(apiUrl).openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("Authorization", "Bearer " + accessToken);

        int status = conn.getResponseCode();
        if (status != 200) throw new IOException("Secret request failed with HTTP " + status);

        String json = readResponse(conn.getInputStream());
        return Optional.ofNullable(extractJsonField(json, "value"));
    }

    private SSLSocketFactory buildSSLSocketFactory(String pfxPath, String password)
            throws KeyStoreException, IOException, NoSuchAlgorithmException, CertificateException,
                   UnrecoverableKeyException, KeyManagementException {

        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        try (InputStream is = new FileInputStream(pfxPath)) {
            keyStore.load(is, password.toCharArray());
        }

        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(keyStore, password.toCharArray());

        SSLContext context = SSLContext.getInstance("TLS");
        context.init(kmf.getKeyManagers(), null, new SecureRandom());

        return context.getSocketFactory();
    }

    private String readResponse(InputStream in) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in))) {
            StringBuilder out = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                out.append(line);
            }
            return out.toString();
        }
    }

    private String extractJsonField(String json, String field) {
        String pattern = """ + field + ""\s*:\s*"([^"]+)"";
        return json.matches(".*" + pattern + ".*")
                ? json.replaceAll(".*" + pattern + ".*", "$1")
                : null;
    }
}
