sh '''
    echo "📍 Répertoire actuel : $(pwd)"
    echo "🔍 Contenu de ./"
    ls -la

    echo "🔍 Contenu de ./minecraft-equity/target/"
    ls -la minecraft-equity/target/ || echo "non trouvé"

    echo "🔍 Contenu de release final"
    ls -la minecraft-equity/target/release-equity/release || echo "non trouvé"
'''
