package com.example;

import org.junit.jupiter.api.Test;

public class RunMainTest {

    @Test
    public void testMain() {
        Main.main(new String[]{});
    }
}