
package com.example;

import com.example.model.Client;
import com.example.model.ReferentialClient;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

import java.util.List;
import java.util.Map;

@SpringBootApplication
@Import(SparkConfiguration.class)
public class MainApp implements CommandLineRunner {

    @Autowired
    @Qualifier("clients")
    private List<Client> clientList;

    @Autowired
    @Qualifier("clientsMap")
    private Map<String, Client> clientMap;

    @Autowired
    @Qualifier("clientsBroadcastMap")
    private Broadcast<Map<String, Client>> clientBroadcastMap;

    @Autowired
    @Qualifier("referentialClientMap")
    private Map<?, ReferentialClient> refClientMap;

    public static void main(String[] args) {
        SpringApplication.run(MainApp.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println("Liste des clients :");
        clientList.forEach(c -> System.out.println(" - " + c.getNom()));
        System.out.println("Client via Map : " + clientMap.get("001"));
        System.out.println("Via Broadcast : " + clientBroadcastMap.value().size());
        System.out.println("Via sous-classe avec clé complexe : " + refClientMap.size());
    }
}
