
package com.example;

import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.example.register.DatasetBeanRegistrar;

@Configuration
public class SparkConfiguration {

    @Bean
    public SparkSession sparkSession() {
        return SparkSession.builder()
                .appName("Spark Referential Loader")
                .master("local[*]")
                .config(new SparkConf().set("spark.sql.shuffle.partitions", "1"))
                .getOrCreate();
    }

    @Bean
    public DatasetBeanRegistrar datasetBeanRegistrar() {
        return new DatasetBeanRegistrar();
    }
}
