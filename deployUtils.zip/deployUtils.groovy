
def deployModuleJar(String modulePath, String settings, String repoUrl) {
    def pomFile = "${modulePath}/pom.xml"
    def jarName = sh(script: "ls ${modulePath}/target/*.jar | grep -v original | head -n1", returnStdout: true).trim()
    def version = sh(script: "mvn -s ${settings} -q -Dexec.executable=echo -Dexec.args='\\${project.version}' --non-recursive exec:exec -f ${pomFile}", returnStdout: true).trim()
    def artifactId = sh(script: "mvn -s ${settings} -q -Dexec.executable=echo -Dexec.args='\\${project.artifactId}' --non-recursive exec:exec -f ${pomFile}", returnStdout: true).trim()
    def groupId = sh(script: "mvn -s ${settings} -q -Dexec.executable=echo -Dexec.args='\\${project.groupId}' --non-recursive exec:exec -f ${pomFile}", returnStdout: true).trim()

    echo "Deploying ${jarName} (version ${version})"

    sh """
        mvn -s ${settings} deploy:deploy-file \
            -Dfile=${jarName} \
            -DrepositoryId=dsp-artifacts \
            -Durl=${repoUrl} \
            -DgroupId=${groupId} \
            -DartifactId=${artifactId} \
            -Dversion=${version} \
            -Dpackaging=jar \
            -DpomFile=${pomFile} \
            -DgeneratePom=false \
            -DcreateChecksum=true
    """
}
