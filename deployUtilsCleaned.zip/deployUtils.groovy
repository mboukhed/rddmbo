
def deployModuleJar(String modulePath, String settings, String repoUrl) {
    def pomFile = "${modulePath}/pom.xml"
    def jarName = sh(script: "ls ${modulePath}/target/*.jar | grep -v original | head -n1", returnStdout: true).trim()
    def version = sh(script: "mvn -f ${pomFile} -s ${settings} help:evaluate -Dexpression=project.version -q -DforceStdout", returnStdout: true).trim()
    def artifactId = sh(script: "mvn -f ${pomFile} -s ${settings} help:evaluate -Dexpression=project.artifactId -q -DforceStdout", returnStdout: true).trim()
    def groupId = sh(script: "mvn -f ${pomFile} -s ${settings} help:evaluate -Dexpression=project.groupId -q -DforceStdout", returnStdout: true).trim()

    echo "Deploying ${jarName} (version ${version})"

    sh """
        mvn -s ${settings} deploy:deploy-file \
            -Dfile=${jarName} \
            -DrepositoryId=dsp-artifacts \
            -Durl=${repoUrl} \
            -DgroupId=${groupId} \
            -DartifactId=${artifactId} \
            -Dversion=${version} \
            -Dpackaging=jar \
            -DpomFile=${pomFile} \
            -DgeneratePom=false \
            -DcreateChecksum=true
    """
}
