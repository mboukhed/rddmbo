
def resolveAndSetPomVersion(String modulePath, String settingsPath) {
    def pomPath = "${modulePath}/pom.xml"

    // Récupérer la version réelle depuis Maven
    def resolvedVersion = sh(
        script: "mvn -f ${pomPath} -s ${settingsPath} help:evaluate -Dexpression=project.version -q -DforceStdout",
        returnStdout: true
    ).trim()

    echo "🔧 Mise à jour de ${pomPath} avec version : ${resolvedVersion}"

    // Remplacer uniquement la balise <version> directement sous <project> (pas celles des dépendances ou parent)
    sh '''
      sed -i '0,/<version>.*<\\/version>/s//<version>'"${resolvedVersion}"'<\\/version>/' ${pomPath}
    '''
}
