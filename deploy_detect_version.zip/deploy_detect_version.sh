mvn help:effective-settings

mvn deploy:deploy-file \
  -DrepositoryId=repo-id \
  -Durl=https://your.jfrog.url/artifactory/libs-release-local \
  -DpomFile=your-module/pom.xml \
  -Dfile=$(ls your-module/target/*.jar | grep -v 'original' | head -n1)
