mvn deploy:deploy-file \
  -DrepositoryId=repo-id \
  -Durl=https://your.jfrog.url/artifactory/libs-release-local \
  -DpomFile=your-module/pom.xml \
  -Dfile=your-module/target/your-module.jar
