package com.example.factory;

import com.example.annotation.DatasetSource;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.springframework.beans.factory.FactoryBean;
import java.util.List;

public class LazyBroadcastFactoryBean<T> implements FactoryBean<Broadcast<List<T>>> {
    private final SparkSession spark;
    private final Class<T> modelClass;
    private final DatasetSource source;
    private Broadcast<List<T>> broadcast;

    public LazyBroadcastFactoryBean(SparkSession spark, Class<T> modelClass) {
        this.spark = spark;
        this.modelClass = modelClass;
        this.source = modelClass.getAnnotation(DatasetSource.class);
    }

    @Override
    public synchronized Broadcast<List<T>> getObject() {
        if (broadcast == null) {
            Dataset<Row> df = switch (source.format()) {
                case PARQUET -> spark.read().parquet(source.path());
                case CSV -> spark.read().option("header", true).csv(source.path());
                case EXCEL -> spark.read().format("com.crealytics.spark.excel")
                        .option("header", "true").option("inferSchema", "true").load(source.path());
            };
            List<T> list = df.as(Encoders.bean(modelClass)).collectAsList();
            broadcast = JavaSparkContext.fromSparkContext(spark.sparkContext()).broadcast(list);
        }
        return broadcast;
    }

    @Override
    public Class<?> getObjectType() { return Broadcast.class; }
    @Override
    public boolean isSingleton() { return true; }
}
