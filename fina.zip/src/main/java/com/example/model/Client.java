package com.example.model;

import com.example.annotation.DatasetSource;

@DatasetSource(path = "/data/clients.csv", format = Format.CSV, qualifier = "clients")
public class Client {
    private String nom;
    private int age;

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}
