package com.example.model;

public enum Format {
    CSV,
    PARQUET,
    EXCEL
}
