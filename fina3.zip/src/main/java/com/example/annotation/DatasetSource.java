package com.example.annotation;

import com.example.model.Format;
import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface DatasetSource {
    String path();
    Format format();
    String qualifier() default "";
}
