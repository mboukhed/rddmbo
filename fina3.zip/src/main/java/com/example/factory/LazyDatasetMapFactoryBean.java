
package com.example.factory;

import com.example.annotation.ComplexKey;
import com.example.annotation.DatasetSource;
import com.example.annotation.Key;
import org.apache.spark.sql.*;
import org.springframework.beans.factory.FactoryBean;

import java.util.*;

public class LazyDatasetMapFactoryBean<T, K> implements FactoryBean<Map<K, T>> {

    private final SparkSession spark;
    private final Class<T> modelClass;
    private final DatasetSource source;
    private Map<K, T> map;

    public LazyDatasetMapFactoryBean(SparkSession spark, Class<T> modelClass) {
        this.spark = spark;
        this.modelClass = modelClass;
        this.source = modelClass.getAnnotation(DatasetSource.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    public synchronized Map<K, T> getObject() {
        if (map == null) {
            Dataset<Row> df = switch (source.format()) {
                case PARQUET -> spark.read().parquet(source.path());
                case CSV -> spark.read().option("header", true).csv(source.path());
                case EXCEL -> spark.read().format("com.crealytics.spark.excel")
                        .option("header", "true").option("inferSchema", "true").load(source.path());
            };

            List<T> list = df.as(Encoders.bean(modelClass)).collectAsList();
            Map<K, T> result = new LinkedHashMap<>();

            for (T obj : list) {
                Object key = resolveKey(obj);
                result.put((K) key, obj);
            }

            this.map = result;
        }
        return map;
    }

    private Object resolveKey(T obj) {
        try {
            for (var field : modelClass.getDeclaredFields()) {
                if (field.isAnnotationPresent(Key.class)) {
                    field.setAccessible(true);
                    return field.get(obj);
                }
            }

            for (var field : modelClass.getDeclaredFields()) {
                field.setAccessible(true);
                Object possibleKey = field.get(obj);
                if (possibleKey != null && possibleKey.getClass().isAnnotationPresent(ComplexKey.class)) {
                    return possibleKey;
                }
            }

            throw new IllegalStateException("Aucune clé trouvée sur " + modelClass.getSimpleName());
        } catch (Exception e) {
            throw new RuntimeException("Erreur résolution clé", e);
        }
    }

    @Override
    public Class<?> getObjectType() {
        return Map.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }
}
