
package com.example.job;

import com.example.model.Client;
import com.example.model.ClientComplex;
import com.example.model.ClientKey;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class DemoInjection {

    @Autowired
    @Qualifier("clients")
    private List<Client> clients;

    @Autowired
    @Qualifier("clientsMap")
    private Map<String, Client> clientsMap;

    @Autowired
    @Qualifier("clientsBroadcast")
    private Broadcast<List<Client>> clientsBroadcast;

    @Autowired
    @Qualifier("clientsComplexMap")
    private Map<ClientKey, ClientComplex> clientsComplexMap;

    public void runDemo() {
        System.out.println("Liste simple :");
        clients.forEach(c -> System.out.println("Client: " + c.getNom()));

        System.out.println("\nMap par clé simple :");
        clientsMap.forEach((k, v) -> System.out.println("Code: " + k + " Nom: " + v.getNom()));

        System.out.println("\nBroadcast :");
        clientsBroadcast.value().forEach(c -> System.out.println("Broadcast Client: " + c.getNom()));

        System.out.println("\nMap par clé complexe :");
        clientsComplexMap.forEach((k, v) -> System.out.println("Clé: " + k + " Nom: " + v.getNom()));
    }
}
