
package com.example.model;

import com.example.annotation.DatasetSource;
import com.example.annotation.Key;

@DatasetSource(path = "/data/clients.csv", format = Format.CSV, qualifier = "clients")
public class Client {
    @Key
    private String code;
    private String nom;

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
}
