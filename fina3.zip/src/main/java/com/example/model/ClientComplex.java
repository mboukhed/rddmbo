
package com.example.model;

import com.example.annotation.DatasetSource;

@DatasetSource(path = "/data/clients_complex.csv", format = Format.CSV, qualifier = "clientsComplex")
public class ClientComplex {
    private ClientKey key;
    private String nom;

    public ClientKey getKey() { return key; }
    public void setKey(ClientKey key) { this.key = key; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
}
