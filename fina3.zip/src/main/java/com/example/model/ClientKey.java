
package com.example.model;

import com.example.annotation.ComplexKey;

@ComplexKey
public class ClientKey {
    private String region;
    private String code;

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    @Override
    public String toString() {
        return region + "-" + code;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientKey that = (ClientKey) o;
        return region.equals(that.region) && code.equals(that.code);
    }

    @Override
    public int hashCode() {
        return region.hashCode() + 31 * code.hashCode();
    }
}
