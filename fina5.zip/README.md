# Spring + Spark Referential Dataset Injector

Ce projet permet d'injecter automatiquement des référentiels Spark (List, Map, Broadcast) via une annotation @ReferentialMapping.