
package com.example;

import com.example.job.DemoInjection;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

/**
 * Point d'entrée principal de démonstration.
 */
@SpringBootApplication
public class ReferentialApplication {

    public static void main(String[] args) {
        SpringApplication.run(ReferentialApplication.class, args);
    }

    @Bean
    public SparkSession sparkSession() {
        return SparkSession.builder().appName("ReferentialTest").master("local[*]").getOrCreate();
    }

    @Bean
    public JavaSparkContext javaSparkContext(SparkSession sparkSession) {
        return new JavaSparkContext(sparkSession.sparkContext());
    }

    @Bean
    public CommandLineRunner demoRunner(DemoInjection demo) {
        return args -> {
            demo.runDemo();
        };
    }
}
