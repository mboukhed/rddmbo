
package com.example.annotation;

import com.example.model.Format;
import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface ReferentialMapping {
    String path();
    Format format();
    String beanName();
    boolean broadcast() default true;
    boolean verifyUniqueKey() default false;
    boolean lazyLoading() default false;
}
