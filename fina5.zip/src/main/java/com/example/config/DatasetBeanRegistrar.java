package com.example.config;

import com.example.annotation.DatasetSource;
import com.example.factory.LazyBroadcastFactoryBean;
import com.example.factory.LazyDatasetFactoryBean;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.*;
import org.springframework.context.annotation.*;
import org.springframework.core.ResolvableType;
import org.springframework.core.type.filter.AnnotationTypeFilter;
import org.apache.spark.sql.SparkSession;

import java.beans.Introspector;

@Configuration
public class DatasetBeanRegistrar implements BeanDefinitionRegistryPostProcessor {
    private final SparkSession spark;

    public DatasetBeanRegistrar(SparkSession spark) {
        this.spark = spark;
    }

    @Override
    public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry) {
        var scanner = new ClassPathScanningCandidateComponentProvider(false);
        scanner.addIncludeFilter(new AnnotationTypeFilter(DatasetSource.class));
        for (BeanDefinition bd : scanner.findCandidateComponents("com.example.model")) {
            try {
                Class<?> clazz = Class.forName(bd.getBeanClassName());
                DatasetSource source = clazz.getAnnotation(DatasetSource.class);
                if (source == null) continue;

                String baseName = source.qualifier().isEmpty()
                        ? Introspector.decapitalize(clazz.getSimpleName())
                        : source.qualifier();

                var listDef = new RootBeanDefinition(LazyDatasetFactoryBean.class);
                listDef.getConstructorArgumentValues().addGenericArgumentValue(spark);
                listDef.getConstructorArgumentValues().addGenericArgumentValue(clazz);
                listDef.setLazyInit(true);
                listDef.setTargetType(ResolvableType.forClassWithGenerics(List.class, clazz));
                registry.registerBeanDefinition(baseName, listDef);

                var broadcastDef = new RootBeanDefinition(LazyBroadcastFactoryBean.class);
                broadcastDef.getConstructorArgumentValues().addGenericArgumentValue(spark);
                broadcastDef.getConstructorArgumentValues().addGenericArgumentValue(clazz);
                broadcastDef.setLazyInit(true);
                broadcastDef.setTargetType(ResolvableType.forClassWithGenerics(
                        org.apache.spark.broadcast.Broadcast.class,
                        ResolvableType.forClassWithGenerics(List.class, clazz)));
                registry.registerBeanDefinition(baseName + "Broadcast", broadcastDef);

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory ignored) {}
}
