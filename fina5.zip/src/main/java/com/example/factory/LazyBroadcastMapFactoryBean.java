
package com.example.factory;

import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.api.java.JavaSparkContext;
import org.springframework.beans.factory.FactoryBean;

import java.util.Map;

public class LazyBroadcastMapFactoryBean<T, K> implements FactoryBean<Broadcast<Map<K, T>>> {

    private final JavaSparkContext context;
    private final LazyDatasetMapFactoryBean<T, K> mapFactory;

    public LazyBroadcastMapFactoryBean(JavaSparkContext context, LazyDatasetMapFactoryBean<T, K> mapFactory) {
        this.context = context;
        this.mapFactory = mapFactory;
    }

    @Override
    public Broadcast<Map<K, T>> getObject() throws Exception {
        return context.broadcast(mapFactory.getObject());
    }

    @Override
    public Class<?> getObjectType() {
        return Broadcast.class;
    }

    @Override
    public boolean isSingleton() {
        return true;
    }
}
