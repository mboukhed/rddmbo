package com.example.factory;

import com.example.annotation.DatasetSource;
import org.apache.spark.sql.*;
import org.springframework.beans.factory.FactoryBean;
import java.util.List;

public class LazyDatasetFactoryBean<T> implements FactoryBean<List<T>> {
    private final SparkSession spark;
    private final Class<T> modelClass;
    private final DatasetSource source;
    private List<T> dataset;

    public LazyDatasetFactoryBean(SparkSession spark, Class<T> modelClass) {
        this.spark = spark;
        this.modelClass = modelClass;
        this.source = modelClass.getAnnotation(DatasetSource.class);
    }

    @Override
    public synchronized List<T> getObject() {
        if (dataset == null) {
            Dataset<Row> df = switch (source.format()) {
                case PARQUET -> spark.read().parquet(source.path());
                case CSV -> spark.read().option("header", true).csv(source.path());
                case EXCEL -> spark.read().format("com.crealytics.spark.excel")
                        .option("header", "true").option("inferSchema", "true").load(source.path());
            };
            dataset = df.as(Encoders.bean(modelClass)).collectAsList();
        }
        return dataset;
    }

    @Override
    public Class<?> getObjectType() { return List.class; }
    @Override
    public boolean isSingleton() { return true; }
}
