
package com.example.factory;

import com.example.model.Client;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.junit.jupiter.api.Test;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class LazyBroadcastMapFactoryBeanTest {

    @Test
    void testBroadcastMapInjection() throws Exception {
        JavaSparkContext jsc = mock(JavaSparkContext.class);
        LazyDatasetMapFactoryBean<Client, String> mapFactory = mock(LazyDatasetMapFactoryBean.class);
        Map<String, Client> mockMap = Map.of("C1", new Client());

        @SuppressWarnings("unchecked")
        Broadcast<Map<String, Client>> broadcastMock = mock(Broadcast.class);

        when(mapFactory.getObject()).thenReturn(mockMap);
        when(jsc.broadcast(mockMap)).thenReturn(broadcastMock);

        LazyBroadcastMapFactoryBean<Client, String> factory =
            new LazyBroadcastMapFactoryBean<>(jsc, mapFactory);

        Broadcast<Map<String, Client>> result = factory.getObject();

        assertNotNull(result);
        verify(jsc).broadcast(mockMap);
    }
}
