
package com.example.factory;

import com.example.model.Client;
import com.example.annotation.ReferentialMapping;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class LazyDatasetMapFactoryBeanTest {

    @Test
    void testThrowsIfNoKey() {
        SparkSession spark = Mockito.mock(SparkSession.class);
        assertThrows(RuntimeException.class, () -> {
            LazyDatasetMapFactoryBean<Client, String> factory =
                new LazyDatasetMapFactoryBean<>(spark, Client.class);
            factory.getObject(); // devrait échouer si pas de Spark mock complet
        });
    }
}
