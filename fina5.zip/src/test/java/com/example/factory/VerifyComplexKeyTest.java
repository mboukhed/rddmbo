
package com.example.factory;

import com.example.model.ClientComplex;
import com.example.model.ClientKey;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VerifyComplexKeyTest {

    @Test
    void throwsIfDuplicateComplexKeyDetected() {
        SparkSession spark = mock(SparkSession.class);
        List<ClientComplex> clients = List.of(
            new ClientComplex() {{ setKey(newKey("IDF", "001")); setNom("Alice"); }},
            new ClientComplex() {{ setKey(newKey("IDF", "002")); setNom("Bob"); }},
            new ClientComplex() {{ setKey(newKey("IDF", "001")); setNom("Charlie"); }}
        );

        LazyDatasetMapFactoryBean<ClientComplex, ClientKey> factory =
            new LazyDatasetMapFactoryBean<>(spark, ClientComplex.class) {
                @Override
                public synchronized Map<ClientKey, ClientComplex> getObject() {
                    Map<ClientKey, ClientComplex> map = new java.util.HashMap<>();
                    for (ClientComplex c : clients) {
                        ClientKey key = c.getKey();
                        if (map.containsKey(key)) {
                            throw new IllegalStateException("Clé complexe non unique détectée");
                        }
                        map.put(key, c);
                    }
                    return map;
                }
            };

        assertThrows(IllegalStateException.class, factory::getObject);
    }

    private ClientKey newKey(String region, String code) {
        ClientKey key = new ClientKey();
        key.setRegion(region);
        key.setCode(code);
        return key;
    }
}
