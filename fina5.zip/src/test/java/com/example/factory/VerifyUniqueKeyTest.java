
package com.example.factory;

import com.example.model.Client;
import org.apache.spark.sql.*;
import org.junit.jupiter.api.Test;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VerifyUniqueKeyTest {

    @Test
    void throwsIfDuplicateKeyDetected() {
        SparkSession spark = mock(SparkSession.class);
        Dataset<Row> df = mock(Dataset.class);
        List<Client> clients = List.of(
            new Client() {{ setCode("DUP"); setNom("A"); }},
            new Client() {{ setCode("DUP"); setNom("B"); }}
        );

        when(spark.read()).thenReturn(mock(DataFrameReader.class));
        LazyDatasetMapFactoryBean<Client, String> factory = new LazyDatasetMapFactoryBean<>(spark, Client.class) {
            @Override
            public synchronized Map<String, Client> getObject() {
                Map<String, Client> map = new java.util.HashMap<>();
                for (Client c : clients) {
                    String key = c.getCode();
                    if (map.containsKey(key)) {
                        throw new IllegalStateException("Clé non unique détectée");
                    }
                    map.put(key, c);
                }
                return map;
            }
        };

        assertThrows(IllegalStateException.class, factory::getObject);
    }
}
