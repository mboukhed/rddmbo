
package com.example.steps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;

import static org.junit.jupiter.api.Assertions.*;

import io.cucumber.java.en.*;

public class ReferentialSteps {

    @Autowired
    ApplicationContext context;

    @Given("un modèle Client annoté avec ReferentialMapping")
    public void clientModelExists() {
        assertNotNull(context.getBean("clients"));
    }

    @Then("un bean clientsBroadcast doit être disponible")
    public void broadcastExists() {
        assertNotNull(context.getBean("clientsBroadcast"));
    }
}
