
package com.sgcib.datalab.core.codecs;

import org.apache.hadoop.io.compress.CompressionCodec;
import org.apache.hadoop.io.compress.Decompressor;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.io.compress.SplitCompressionInputStream;
import org.apache.hadoop.io.compress.SplitCompressionInputStream;
import org.apache.hadoop.io.compress.SplittableCompressionCodec;
import org.apache.hadoop.io.compress.CompressionInputStream;

import java.io.IOException;
import java.io.InputStream;

public class SplittableGzipCodec extends GzipCodec implements SplittableCompressionCodec {

    @Override
    public SplitCompressionInputStream createInputStream(InputStream seekableIn,
                                                          Decompressor decompressor,
                                                          long start,
                                                          long end,
                                                          org.apache.hadoop.io.compress.SplitCompressionInputStream.ReadMode readMode)
            throws IOException {
        return new UnSplittableCompressionInputStream(seekableIn);
    }

    @Override
    public CompressionInputStream createInputStream(InputStream in, Decompressor decompressor) throws IOException {
        return new UnSplittableCompressionInputStream(in);
    }

    private static class UnSplittableCompressionInputStream extends SplitCompressionInputStream {
        public UnSplittableCompressionInputStream(InputStream in) throws IOException {
            super(in, 0, Long.MAX_VALUE);
        }

        @Override
        public int read() throws IOException {
            return in.read();
        }

        @Override
        public int read(byte[] b, int off, int len) throws IOException {
            return in.read(b, off, len);
        }

        @Override
        public void resetState() throws IOException {
            // No-op
        }
    }
}
