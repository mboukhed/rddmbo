
package com.sgcib.datalab.core.codecs;

import java.io.IOException;
import java.io.InputStream;

public class ThrottleableDecompressorStream extends InputStream {

    private final InputStream in;

    public ThrottleableDecompressorStream(InputStream in) {
        this.in = in;
    }

    @Override
    public int read() throws IOException {
        return getCompressedData();
    }

    private int getCompressedData() throws IOException {
        try {
            return in.read();
        } catch (IOException e) {
            throw new IOException("Erreur de lecture dans ThrottleableDecompressorStream", e);
        }
    }

    @Override
    public void close() throws IOException {
        in.close();
    }
}
