import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
public class GenericParameters implements Serializable {

    private Map<String, Object> parameters = new HashMap<>();

    public void put(String key, Object value) {
        parameters.put(key, value);
    }

    public Object get(String key) {
        return parameters.get(key);
    }

    public <T> T getAs(String key, Class<T> clazz) {
        Object value = parameters.get(key);
        if (clazz.isInstance(value)) {
            return clazz.cast(value);
        }
        return null;
    }
}