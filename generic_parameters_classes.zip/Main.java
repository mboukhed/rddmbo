public class Main {
    public static void main(String[] args) {
        GenericParameters params = new GenericParameters();

        params.put("name", "Mko");
        params.put("age", 35);
        params.put("config", Map.of("env", "dev", "debug", true));
        params.put("xmlContent", "<data><val>123</val></data>");

        String name = params.getAs("name", String.class);
        Map config = params.getAs("config", Map.class);

        System.out.println(name); // Mko
        System.out.println(config); // {env=dev, debug=true}
    }
}