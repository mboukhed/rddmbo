
import org.apache.hadoop.conf.Configuration;
import org.apache.spark.SparkContext;
import java.util.function.BiConsumer;

public abstract class AbstractSparkContextBuilder {

    protected static synchronized Object buildSecureHadoopConfBean(String storageAccount, String authType, Object obj) {
        if (obj == null || (!(obj instanceof Configuration) && !(obj instanceof SparkContext))) {
            throw new IllegalArgumentException("Expected Configuration or SparkContext");
        }

        String clientId = EnvUtils.getEnv("AZURE_CLIENT_ID");
        String clientSecret = EnvUtils.getEnv("AZURE_CLIENT_SECRET");
        String tenantId = EnvUtils.getEnv("AZURE_TENANT_ID");

        BiConsumer<String, String> setFunc;

        if (obj instanceof Configuration) {
            Configuration conf = (Configuration) obj;
            setFunc = conf::set;
        } else {
            SparkContext sc = (SparkContext) obj;
            setFunc = (key, value) -> sc.hadoopConfiguration().set(key, value);
        }

        HadoopConfUtils.configureAzureOAuth(storageAccount, setFunc, clientId, clientSecret, tenantId);

        if ("local".equalsIgnoreCase(authType)) {
            setFunc.accept("fs.defaultFS", "file:///");
        }

        return obj;
    }
}
