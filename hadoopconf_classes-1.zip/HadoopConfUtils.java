
import java.util.function.BiConsumer;

public class HadoopConfUtils {

    public static void configureAzureOAuth(String storageAccount, BiConsumer<String, String> setFunc,
                                           String clientId, String clientSecret, String tenantId) {
        String prefix = "spark.hadoop.fs.azure.account.";

        setFunc.accept(prefix + "auth.type." + storageAccount + ".dfs.core.windows.net", "OAuth");
        setFunc.accept(prefix + "oauth.provider.type." + storageAccount + ".dfs.core.windows.net",
                "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
        setFunc.accept(prefix + "oauth2.client.id." + storageAccount + ".dfs.core.windows.net", clientId);
        setFunc.accept(prefix + "oauth2.client.secret." + storageAccount + ".dfs.core.windows.net", clientSecret);
        setFunc.accept(prefix + "oauth2.client.endpoint." + storageAccount + ".dfs.core.windows.net",
                "https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
    }
}
