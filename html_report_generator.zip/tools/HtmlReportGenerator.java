package tools;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class HtmlReportGenerator {

    public static void main(String[] args) {
        File inputDirectory = new File("target/cucumber-reports");
        File outputDirectory = new File("target/merged-html-report");

        if (!inputDirectory.exists() || !inputDirectory.isDirectory()) {
            System.err.println("Le répertoire des rapports JSON est introuvable : " + inputDirectory.getAbsolutePath());
            return;
        }

        File[] jsonFiles = inputDirectory.listFiles((dir, name) -> name.endsWith(".json"));

        if (jsonFiles == null || jsonFiles.length == 0) {
            System.err.println("Aucun fichier JSON trouvé dans : " + inputDirectory.getAbsolutePath());
            return;
        }

        List<String> jsonPaths = new ArrayList<>();
        for (File json : jsonFiles) {
            jsonPaths.add(json.getAbsolutePath());
        }

        Configuration config = new Configuration(outputDirectory, "Rapport Cucumber Global");
        config.setParallelTesting(true);

        ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
        reportBuilder.generateReports();

        System.out.println("✅ Rapport HTML généré ici : " + outputDirectory.getAbsolutePath() + "/index.html");
    }
}