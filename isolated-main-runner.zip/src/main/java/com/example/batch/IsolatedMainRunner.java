package com.example.batch;

import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public class IsolatedMainRunner {

    public void runMain(String className, String[] args) throws Exception {
        URL[] classpath = ((URLClassLoader) ClassLoader.getSystemClassLoader()).getURLs();
        URLClassLoader isolatedLoader = new URLClassLoader(classpath, null); // ClassLoader root

        Class<?> mainClass = Class.forName(className, true, isolatedLoader);
        Method mainMethod = mainClass.getMethod("main", String[].class);
        mainMethod.invoke(null, (Object) args);

        isolatedLoader.close();
    }
}
