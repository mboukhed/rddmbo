package com.example.batch;

import io.cucumber.java.Before;

public class StepDefinitions {

    @Before
    public void runMainBeforeScenario() throws Exception {
        new IsolatedMainRunner().runMain("com.example.batch.MonBatchMain", new String[]{"--profile=dev"});
    }
}
