package com.example.batch;

public class DummySingleton {
    private static boolean initialized = false;

    public static void init() {
        if (!initialized) {
            System.out.println("DummySingleton INIT");
            initialized = true;
        } else {
            System.out.println("DummySingleton déjà initialisé !");
        }
    }
}
