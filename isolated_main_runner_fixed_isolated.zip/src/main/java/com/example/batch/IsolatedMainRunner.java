
package com.example.batch;

import java.lang.reflect.Method;

public class IsolatedMainRunner {

    public void runMain(String className, String args) {
        try {
            Class<?> clazz = Class.forName(className);
            Method main = clazz.getMethod("main", String[].class);
            String[] splitArgs = args.split(" ");
            main.invoke(null, (Object) splitArgs);
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de l'exécution du main", e);
        }
    }
}
