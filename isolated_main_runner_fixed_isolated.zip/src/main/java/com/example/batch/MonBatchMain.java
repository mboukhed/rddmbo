package com.example.batch;

public class MonBatchMain {
    public static void main(String[] args) {
        System.out.println(">> MonBatchMain lancé avec args:");
        for (String arg : args) {
            System.out.println("   - " + arg);
        }

        System.out.println("   SparkSession et Spring simulés ici...");
        DummySingleton.init();  // simule un contexte statique
    }
}
