package com.example.batch;

import io.cucumber.java.en.When;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class StepDefinitions {

    @When("I run the batch with parameters {string}")
    public void runBatch(String paramLine) throws Exception {
        String[] args = paramLine.split(" ");
        int exitCode = MainProcessInvoker.runMainInNewProcess(IsolatedMainRunner.class, args);
        assertEquals(0, exitCode, "Main exited with error code: " + exitCode);
    }
}
