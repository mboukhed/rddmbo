package com.example.core;
public class App { public static void main(String[] args) { System.out.println("core running"); } }