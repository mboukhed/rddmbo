package com.example.main;
public class App { public static void main(String[] args) { System.out.println("main running"); } }