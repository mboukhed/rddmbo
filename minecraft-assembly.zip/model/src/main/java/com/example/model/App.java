package com.example.model;
public class App { public static void main(String[] args) { System.out.println("model running"); } }