package com.example.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class GreetingServiceTest {

    @Test
    void testGreet() {
        NameProvider mockNameProvider = mock(NameProvider.class);
        when(mockNameProvider.getName()).thenReturn("John");

        GreetingService greetingService = new GreetingService(mockNameProvider);
        assertEquals("Hello, John", greetingService.greet());
    }
}
