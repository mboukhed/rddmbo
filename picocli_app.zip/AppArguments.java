import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import java.util.HashMap;
import java.util.Map;

@Command(name = "app", mixinStandardHelpOptions = true, version = "1.0")
public class AppArguments {

    @Option(names = "--pipeline", required = true, description = "Name of the pipeline")
    private String pipeline;

    @Option(names = "--type_pipeline", required = true, description = "Type of the pipeline")
    private String typePipeline;

    private final Map<String, String> dynamic = new HashMap<>();

    public void putDynamic(String key, String value) {
        dynamic.put(key, value);
    }

    public Map<String, String> getDynamic() {
        return dynamic;
    }

    public String getPipeline() {
        return pipeline;
    }

    public String getTypePipeline() {
        return typePipeline;
    }
}