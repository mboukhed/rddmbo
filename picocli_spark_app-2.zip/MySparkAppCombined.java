
import org.apache.spark.sql.SparkSession;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

import java.util.Map;

@Command(name = "MySparkApp", mixinStandardHelpOptions = true, version = "1.0")
public class MySparkApp implements Runnable {

    @Option(names = {"--input"}, required = true, description = "Chemin du fichier à lire")
    private String inputPath;

    @Option(names = {"--output"}, required = true, description = "Répertoire de sortie")
    private String outputPath;

    @Option(names = {"--pipeline"}, required = true, description = "Nom du pipeline à exécuter")
    private String pipeline;

    @Option(names = {"--typepline"}, required = true, description = "Type du pipeline (batch, streaming, etc.)")
    private String typepline;

    @Option(names = {"--param"}, description = "Paramètres dynamiques sous forme clé=valeur, séparés par des virgules", split = ",")
    private Map<String, String> dynamicParams;

    public static void main(String[] args) {
        int exitCode = new CommandLine(new MySparkApp()).execute(args);
        System.exit(exitCode);
    }

    @Override
    public void run() {
        SparkSession spark = SparkSession.builder()
                .appName("MySparkApp with Picocli")
                .getOrCreate();

        System.out.println("📂 Input     : " + inputPath);
        System.out.println("📁 Output    : " + outputPath);
        System.out.println("🔁 Pipeline  : " + pipeline);
        System.out.println("🔧 Typepline : " + typepline);

        if (dynamicParams != null && !dynamicParams.isEmpty()) {
            System.out.println("🧩 Paramètres dynamiques :");
            dynamicParams.forEach((k, v) -> System.out.println("   - " + k + " = " + v));
        }

        // Simulation traitement
        System.out.println("🚀 Lancement du pipeline Spark...");

        spark.read().format("csv").option("header", "true").load(inputPath)
                .write().mode("overwrite").parquet(outputPath);

        spark.stop();
        System.out.println("✅ Traitement Spark terminé !");
    }
}
