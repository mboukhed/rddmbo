public class ExampleMain {

    public static void main(String[] args) {
        PropertiesLoader loader = new PropertiesLoader("application.properties");
        StorageAccountRegistry registry = new StorageAccountRegistry(loader);
        PathResolver pathResolver = new PathResolver(registry);

        String personRawPath = loader.getProperty("referential.Person.path");
        String personFullPath = pathResolver.resolvePath(personRawPath);

        System.out.println("Full Spark Path for Person: " + personFullPath);
    }
}