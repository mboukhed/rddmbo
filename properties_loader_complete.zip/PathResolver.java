public class PathResolver {

    private final StorageAccountRegistry registry;

    public PathResolver(StorageAccountRegistry registry) {
        this.registry = registry;
    }

    public String resolvePath(String rawPath) {
        if (rawPath.startsWith("abfss://") || rawPath.startsWith("file://") || rawPath.startsWith("classpath:")) {
            return rawPath;
        }

        String[] parts = rawPath.split(":", 2);
        if (parts.length != 2) {
            throw new IllegalArgumentException("Invalid path format: " + rawPath + ". Expected format: accountKey:pathInContainer");
        }

        String accountKey = parts[0];
        String pathInContainer = parts[1];

        StorageAccountRegistry.StorageAccount account = registry.getAccount(accountKey);
        if (account == null) {
            throw new IllegalArgumentException("Unknown storage account: " + accountKey);
        }

        return account.buildAbfssPath(pathInContainer);
    }
}