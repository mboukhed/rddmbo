import java.util.HashMap;
import java.util.Map;

public class StorageAccountRegistry {

    private final Map<String, StorageAccount> accounts = new HashMap<>();

    public StorageAccountRegistry(PropertiesLoader loader) {
        String accountsList = loader.getProperty("storage.accounts");
        if (accountsList != null) {
            String[] accountNames = accountsList.split(",");
            for (String account : accountNames) {
                account = account.trim();
                String container = loader.getProperty("storage." + account + ".container");
                String accountName = loader.getProperty("storage." + account + ".accountName");
                accounts.put(account, new StorageAccount(accountName, container));
            }
        }
    }

    public StorageAccount getAccount(String accountKey) {
        return accounts.get(accountKey);
    }

    public static class StorageAccount {
        private final String accountName;
        private final String container;

        public StorageAccount(String accountName, String container) {
            this.accountName = accountName;
            this.container = container;
        }

        public String getAccountName() {
            return accountName;
        }

        public String getContainer() {
            return container;
        }

        public String buildAbfssPath(String pathInContainer) {
            return "abfss://" + container + "@" + accountName + ".dfs.core.windows.net/" + pathInContainer;
        }
    }
}