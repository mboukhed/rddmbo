az storage blob directory create \
  --account-name <storage_account> \
  --container <container_name> \
  --name <path/to/directory> \
  --auth-mode login