package com.example.referential.annotations;

public enum Format {
    PARQUET,
    CSV,
    JSON,
    XML,
    AVRO,
    EXCEL
}