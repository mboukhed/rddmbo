package com.example.referential.lifecycle;

import com.example.referential.annotations.Referential;
import com.example.referential.core.ReferentialLoader;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;
import java.util.*;

@Component
public class ReferentialInitializer implements BeanPostProcessor {

    private final ReferentialLoader loader;
    private final SparkSession spark;

    public ReferentialInitializer(ReferentialLoader loader, SparkSession spark) {
        this.loader = loader;
        this.spark = spark;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        Referential referential = clazz.getAnnotation(Referential.class);
        if (referential == null) return bean;

        for (Field field : clazz.getDeclaredFields()) {
            field.setAccessible(true);

            try {
                if (List.class.isAssignableFrom(field.getType())) {
                    ParameterizedType pt = (ParameterizedType) field.getGenericType();
                    Class<?> mappedClass = (Class<?>) pt.getActualTypeArguments()[0];
                    List<?> list = loader.loadList(mappedClass, referential);
                    field.set(bean, list);
                } else if (Map.class.isAssignableFrom(field.getType())) {
                    ParameterizedType pt = (ParameterizedType) field.getGenericType();
                    Class<?> keyClass = (Class<?>) pt.getActualTypeArguments()[0];
                    Class<?> mappedClass = (Class<?>) pt.getActualTypeArguments()[1];
                    Map<?, ?> map = loader.loadMap(mappedClass, keyClass, referential);
                    field.set(bean, map);
                } else if (Broadcast.class.isAssignableFrom(field.getType())) {
                    ParameterizedType pt = (ParameterizedType) field.getGenericType();
                    Type inner = pt.getActualTypeArguments()[0];
                    if (inner.getTypeName().startsWith("java.util.List")) {
                        Class<?> mappedClass = (Class<?>) ((ParameterizedType) inner).getActualTypeArguments()[0];
                        Broadcast<?> bcast = loader.broadcastList(mappedClass, spark.sparkContext(), referential);
                        field.set(bean, bcast);
                    } else if (inner.getTypeName().startsWith("java.util.Map")) {
                        Type[] mapArgs = ((ParameterizedType) inner).getActualTypeArguments();
                        Class<?> keyClass = (Class<?>) mapArgs[0];
                        Class<?> mappedClass = (Class<?>) mapArgs[1];
                        Broadcast<?> bcast = loader.broadcastMap(mappedClass, keyClass, spark.sparkContext(), referential);
                        field.set(bean, bcast);
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to inject referential: " + field.getName(), e);
            }
        }
        return bean;
    }
}