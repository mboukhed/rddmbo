package com.example.referential.core;

import com.example.referential.annotations.Referential;
import org.apache.spark.SparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class ReferentialLoader {

    private final SparkSession spark;

    public ReferentialLoader(SparkSession spark) {
        this.spark = spark;
    }

    public <T> List<T> loadList(Class<T> clazz, Referential ref) {
        Dataset<Row> df = spark.read().format(ref.format().name().toLowerCase())
            .load(ref.path());
        Dataset<T> ds = df.as(Encoders.bean(clazz));
        return ds.collectAsList();
    }

    public <K, T> Map<K, T> loadMap(Class<T> clazz, Class<K> keyClass, Referential ref) {
        List<T> list = loadList(clazz, ref);
        return list.stream().collect(Collectors.toMap(
            t -> extractFirstMatchingField(t, keyClass),
            t -> t
        ));
    }

    public <T> Broadcast<List<T>> broadcastList(Class<T> clazz, SparkContext jsc, Referential ref) {
        return jsc.broadcast(loadList(clazz, ref));
    }

    public <K, T> Broadcast<Map<K, T>> broadcastMap(Class<T> clazz, Class<K> keyClass, SparkContext jsc, Referential ref) {
        return jsc.broadcast(loadMap(clazz, keyClass, ref));
    }

    private <K, T> K extractFirstMatchingField(T instance, Class<K> keyClass) {
        try {
            for (Method method : instance.getClass().getMethods()) {
                if (method.getName().startsWith("get") &&
                    method.getParameterCount() == 0 &&
                    keyClass.isAssignableFrom(method.getReturnType())) {
                    return keyClass.cast(method.invoke(instance));
                }
            }
            throw new RuntimeException("No matching getter found for key type " + keyClass.getName());
        } catch (Exception e) {
            throw new RuntimeException("Unable to extract key", e);
        }
    }
}