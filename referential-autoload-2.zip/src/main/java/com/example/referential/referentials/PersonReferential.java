package com.example.referential.referentials;

import com.example.referential.annotations.Referential;
import com.example.referential.annotations.Format;
import com.example.referential.model.Person;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.apache.spark.broadcast.Broadcast;
import java.util.List;

@Component
@Qualifier("personReferential")
@Referential(
    broadcast = true,
    key = "id",
    qualifier = "personReferential",
    format = Format.PARQUET,
    path = "hdfs:///datalake/ref/person"
)
public class PersonReferential {
    public Broadcast<List<Person>> broadcastList;
}