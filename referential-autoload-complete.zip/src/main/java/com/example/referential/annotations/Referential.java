package com.example.referential.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Referential {
    String qualifier() default "";
    boolean broadcast() default false;
    boolean verifyUniqueKey() default false;
    boolean lazyLoading() default true;
    String query() default "";
    String filter() default "";
    Format format() default Format.PARQUET;
    String path() default "";
}