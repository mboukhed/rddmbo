package com.example.referential.core;

import com.example.referential.annotations.Referential;
import org.apache.spark.SparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class ReferentialLoader {

    private final SparkSession spark;

    public ReferentialLoader(SparkSession spark) {
        this.spark = spark;
    }

    public <T> List<T> loadList(Class<T> clazz, Referential ref) {
        Dataset<Row> df = spark.read().format(ref.format().name().toLowerCase())
            .load(ref.path());
        return df.as(Encoders.bean(clazz)).collectAsList();
    }

    public <K, T> Map<K, T> loadMap(Class<K> keyClass, Class<T> valueClass, Referential ref) {
        List<T> list = loadList(valueClass, ref);
        return list.stream().collect(Collectors.toMap(
            v -> autoBuildKey(keyClass, v),
            v -> v
        ));
    }

    private <K, T> K autoBuildKey(Class<K> keyClass, T source) {
        try {
            K key = keyClass.getDeclaredConstructor().newInstance();
            for (Method keySetter : keyClass.getMethods()) {
                if (!keySetter.getName().startsWith("set")) continue;
                String field = keySetter.getName().substring(3);
                try {
                    Method getter = source.getClass().getMethod("get" + field);
                    Object value = getter.invoke(source);
                    keySetter.invoke(key, value);
                } catch (NoSuchMethodException ignored) {}
            }
            return key;
        } catch (Exception e) {
            throw new RuntimeException("Failed to build key: " + keyClass.getSimpleName(), e);
        }
    }
}