package com.example.referential.lifecycle;

import com.example.referential.annotations.Referential;
import com.example.referential.core.ReferentialLoader;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;

@Component
public class ReferentialInitializer implements BeanPostProcessor {

    private final ReferentialLoader loader;
    private final SparkSession spark;

    public ReferentialInitializer(ReferentialLoader loader, SparkSession spark) {
        this.loader = loader;
        this.spark = spark;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        Referential ref = bean.getClass().getAnnotation(Referential.class);
        if (ref == null) return bean;

        for (Field field : bean.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            try {
                if (Map.class.isAssignableFrom(field.getType())) {
                    ParameterizedType pt = (ParameterizedType) field.getGenericType();
                    Class<?> keyClass = (Class<?>) pt.getActualTypeArguments()[0];
                    Class<?> valueClass = (Class<?>) pt.getActualTypeArguments()[1];
                    Object map = loader.loadMap(keyClass, valueClass, ref);
                    field.set(bean, map);
                }
            } catch (Exception e) {
                throw new RuntimeException("Failed to inject referential for field " + field.getName(), e);
            }
        }
        return bean;
    }
}