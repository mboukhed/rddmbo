package com.example.referential.model;

public class TotoKey {
    private String region;
    private String code;

    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    @Override
    public int hashCode() {
        return (region + ":" + code).hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof TotoKey)) return false;
        TotoKey other = (TotoKey) obj;
        return this.region.equals(other.region) && this.code.equals(other.code);
    }
}