package com.example.referential.referentials;

import com.example.referential.annotations.Referential;
import com.example.referential.annotations.Format;
import com.example.referential.model.Client;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Qualifier("broadcastClientReferential")
@Referential(
    qualifier = "broadcastClientReferential",
    format = Format.JSON,
    path = "hdfs:///data/client_list",
    broadcast = true
)
public class BroadcastClientReferential {
    public Broadcast<List<Client>> clients;
}