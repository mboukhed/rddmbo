package com.example.referential.referentials;

import com.example.referential.annotations.Referential;
import com.example.referential.annotations.Format;
import com.example.referential.model.Client;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Qualifier("clientListReferential")
@Referential(
    qualifier = "clientListReferential",
    format = Format.JSON,
    path = "hdfs:///data/client_list"
)
public class ClientListReferential {
    public List<Client> clients;
}