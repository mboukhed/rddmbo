package com.example.referential.referentials;

import com.example.referential.annotations.Referential;
import com.example.referential.annotations.Format;
import com.example.referential.model.Client;
import com.example.referential.model.TotoKey;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@Qualifier("clientReferential")
@Referential(
    qualifier = "clientReferential",
    format = Format.JSON,
    path = "hdfs:///data/client"
)
public class ClientReferential {
    public Map<TotoKey, Client> clients;
}