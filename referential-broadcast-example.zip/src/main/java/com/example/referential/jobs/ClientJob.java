package com.example.referential.jobs;

import com.example.referential.model.Client;
import com.example.referential.model.ClientKey;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ClientJob {

    @Autowired
    @Qualifier("clientReferential")
    private Broadcast<Map<ClientKey, Client>> clientMap;

    public void run() {
        ClientKey key = new ClientKey();
        key.setId("123");
        key.setPays("FR");

        Client client = clientMap.value().get(key);
        System.out.println("Client trouvé : " + client);
    }
}