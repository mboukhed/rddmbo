package com.example.referential.model;

public class Client {
    private String id;
    private String pays;
    private String segment;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPays() { return pays; }
    public void setPays(String pays) { this.pays = pays; }

    public String getSegment() { return segment; }
    public void setSegment(String segment) { this.segment = segment; }
}