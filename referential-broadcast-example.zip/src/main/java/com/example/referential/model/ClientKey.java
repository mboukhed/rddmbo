package com.example.referential.model;

import java.util.Objects;

public class ClientKey {
    private String id;
    private String pays;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getPays() { return pays; }
    public void setPays(String pays) { this.pays = pays; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ClientKey)) return false;
        ClientKey that = (ClientKey) o;
        return Objects.equals(id, that.id) && Objects.equals(pays, that.pays);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, pays);
    }
}