package com.example.referential.referentials;

import com.example.referential.annotations.Referential;
import com.example.referential.annotations.Format;
import com.example.referential.model.Client;
import com.example.referential.model.ClientKey;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("clientReferential")
@Referential(
    mapper = Client.class,
    complexKey = ClientKey.class,
    broadcast = true,
    verifyUniqueKey = true,
    qualifier = "clientReferential",
    format = Format.PARQUET,
    path = "hdfs:///datalake/ref/client"
)
public class ClientReferential {}