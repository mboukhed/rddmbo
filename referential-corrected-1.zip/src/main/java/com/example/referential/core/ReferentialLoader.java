package com.example.referential.core;

import com.example.referential.annotations.Referential;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;

import java.util.*;
import java.util.stream.Collectors;

public class ReferentialLoader {

    private final SparkSession spark;

    public ReferentialLoader(SparkSession spark) {
        this.spark = spark;
    }

    public <T> List<T> loadList(Class<T> clazz, Referential referential) {
        Encoder<T> encoder = Encoders.bean(clazz);
        Dataset<T> ds = readAndFilter(clazz, referential, encoder);
        return ds.collectAsList();
    }

    public <T, K> Map<K, T> loadMap(Class<T> clazz, Class<K> keyClass, Referential referential) {
        Encoder<T> encoder = Encoders.bean(clazz);
        Dataset<T> ds = readAndFilter(clazz, referential, encoder);

        Map<K, T> map = new HashMap<>();
        for (T item : ds.collectAsList()) {
            K key = extractKey(item, referential, keyClass);
            if (referential.verifyUniqueKey() && map.containsKey(key)) {
                throw new RuntimeException("Clé dupliquée détectée : " + key);
            }
            map.put(key, item);
        }
        return map;
    }

    public <T> Broadcast<List<T>> broadcastList(Class<T> clazz, JavaSparkContext jsc, Referential referential) {
        List<T> list = loadList(clazz, referential);
        return jsc.broadcast(list);
    }

    public <T, K> Broadcast<Map<K, T>> broadcastMap(Class<T> clazz, Class<K> keyClass, JavaSparkContext jsc, Referential referential) {
        Map<K, T> map = loadMap(clazz, keyClass, referential);
        return jsc.broadcast(map);
    }

    private <T> Dataset<T> readAndFilter(Class<T> clazz, Referential referential, Encoder<T> encoder) {
        String view = clazz.getSimpleName().toLowerCase(); // default source
        Dataset<Row> df = spark.table(view);

        if (!referential.query().isEmpty()) {
            df = spark.sql(referential.query());
        }

        if (!referential.filter().isEmpty()) {
            df = df.filter(referential.filter());
        }

        return df.as(encoder);
    }

    private <T, K> K extractKey(T item, Referential referential, Class<K> keyClass) {
        try {
            String keyField = referential.key();
            Object value;
            if (!keyField.isEmpty()) {
                value = item.getClass().getDeclaredField(keyField);
                ((Field) value).setAccessible(true);
                return keyClass.cast(((Field) value).get(item));
            } else {
                throw new IllegalStateException("Aucune clé définie.");
            }
        } catch (Exception e) {
            throw new RuntimeException("Erreur extraction clé", e);
        }
    }
}