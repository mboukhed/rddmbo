package com.example.referential.lifecycle;

import com.example.referential.annotations.Referential;
import com.example.referential.core.ReferentialLoader;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;
import java.util.List;
import java.util.Map;

@Component
public class ReferentialInitializer implements BeanPostProcessor {

    private final ReferentialLoader loader;
    private final JavaSparkContext jsc;

    public ReferentialInitializer(ReferentialLoader loader, JavaSparkContext jsc) {
        this.loader = loader;
        this.jsc = jsc;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        Referential referential = clazz.getAnnotation(Referential.class);

        if (referential != null) {
            @SuppressWarnings("unchecked")
            Class<?> mappedClass = (referential.mapper() == Void.class) ? clazz : referential.mapper();

            try {
                for (Field field : clazz.getDeclaredFields()) {
                    field.setAccessible(true);

                    if (List.class.isAssignableFrom(field.getType())) {
                        List<?> list = loader.loadList(mappedClass, referential);
                        field.set(bean, list);
                    } else if (Map.class.isAssignableFrom(field.getType())) {
                        ParameterizedType pt = (ParameterizedType) field.getGenericType();
                        Class<?> keyClass = (Class<?>) pt.getActualTypeArguments()[0];
                        Map<?, ?> map = loader.loadMap(mappedClass, keyClass, referential);
                        field.set(bean, map);
                    } else if (Broadcast.class.isAssignableFrom(field.getType())) {
                        ParameterizedType pt = (ParameterizedType) field.getGenericType();
                        Type bt = pt.getActualTypeArguments()[0];

                        if (bt.getTypeName().startsWith("java.util.List")) {
                            Broadcast<?> bcast = loader.broadcastList(mappedClass, jsc, referential);
                            field.set(bean, bcast);
                        } else if (bt.getTypeName().startsWith("java.util.Map")) {
                            Type[] types = ((ParameterizedType) bt).getActualTypeArguments();
                            Class<?> keyClass = (Class<?>) types[0];
                            Broadcast<?> bcast = loader.broadcastMap(mappedClass, keyClass, jsc, referential);
                            field.set(bean, bcast);
                        }
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException("Erreur injection référentiel " + clazz.getSimpleName(), e);
            }
        }

        return bean;
    }
}