mvn versions:set-property \
  -Dproperty=xxx.version \
  -DremoveSnapshot=true \
  -DgenerateBackupPoms=false
