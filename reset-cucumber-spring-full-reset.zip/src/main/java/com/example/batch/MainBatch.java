package com.example.batch;

public class MainBatch {
    public static void main(String[] args) {
        System.out.println("MainBatch executed with args:");
        if (args != null) {
            for (String arg : args) {
                System.out.println(arg);
            }
        }
    }
}
