package com.example.test;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.apache.spark.sql.SparkSession;
import org.springframework.context.ConfigurableApplicationContext;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

public class CucumberHooks {

    private static ConfigurableApplicationContext context;

    @Before
    public void setUp() {
        System.out.println("Before scenario - set up context");
    }

    @After
    public void tearDown() {
        System.out.println("After scenario - clean up context");

        // Stop active SparkSession if any
        try {
            SparkSession.getActiveSession().ifPresent(spark -> {
                System.out.println("Stopping SparkSession...");
                spark.stop();
            });
        } catch (Exception e) {
            System.err.println("Error stopping SparkSession: " + e.getMessage());
        }

        // Close Spring context if available
        try {
            if (context != null) {
                System.out.println("Closing Spring context...");
                context.close();
                context = null;
            }
        } catch (Exception e) {
            System.err.println("Error closing Spring context: " + e.getMessage());
        }

        // Reset all static fields (for demo purpose only)
        try {
            resetStatics("com.example.batch");
        } catch (Exception e) {
            System.err.println("Error resetting statics: " + e.getMessage());
        }
    }

    public static void registerContext(ConfigurableApplicationContext ctx) {
        context = ctx;
    }

    private void resetStatics(String packageName) throws Exception {
        for (Class<?> clazz : ClassFinder.find(packageName)) {
            for (Field field : clazz.getDeclaredFields()) {
                if (Modifier.isStatic(field.getModifiers())) {
                    field.setAccessible(true);
                    Class<?> type = field.getType();
                    Object defaultValue = type.isPrimitive() ? getPrimitiveDefault(type) : null;
                    field.set(null, defaultValue);
                }
            }
        }
    }

    private Object getPrimitiveDefault(Class<?> type) {
        if (type == boolean.class) return false;
        if (type == byte.class || type == short.class || type == int.class || type == long.class) return 0;
        if (type == float.class) return 0f;
        if (type == double.class) return 0d;
        if (type == char.class) return ' ';
        return null;
    }
}
