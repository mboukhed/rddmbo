package com.example.test;

import io.cucumber.java.en.Given;
import com.example.batch.MainBatch;

public class StepDefinitions {

    @Given("I launch the main batch")
    public void i_launch_the_main_batch() {
        MainBatch.main(new String[]{"--spring.profiles.active=test"});
    }
}
