
package com.sgccb;

import com.sgccb.utils.ResourceHelper;
import java.io.InputStream;
import java.util.Properties;

public class Main {
    public static void main(String[] args) {
        try {
            InputStream input = ResourceHelper.loadResource("data/local/application.properties");
            Properties properties = new Properties();
            properties.load(input);
            System.out.println("Propriétés chargées: " + properties);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
