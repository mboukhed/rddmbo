
import java.io.File;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

public class SgedFileFilter {

    public static Map<String, Date> filterFilesByPrefixAndDate(String directoryPath, String prefix, LocalDate inputDate) {
        Map<String, Date> result = new HashMap<>();
        File dir = new File(directoryPath);

        if (!dir.exists() || !dir.isDirectory()) {
            return result;
        }

        File[] files = dir.listFiles((d, name) -> name.startsWith(prefix));
        if (files == null) return result;

        for (File file : files) {
            String filename = file.getName();
            // Extrait "20250407" du nom comme dans sged_margin_spread_report_20250407_193000
            String[] parts = filename.split("_");
            if (parts.length >= 5) {
                String datePart = parts[4];
                try {
                    LocalDate fileDate = LocalDate.parse(datePart, DateTimeFormatter.ofPattern("yyyyMMdd"));
                    if (fileDate.isEqual(inputDate)) {
                        result.put(file.getAbsolutePath(), Date.valueOf(fileDate));
                    }
                } catch (Exception e) {
                    // Format incorrect
                }
            }
        }

        return result;
    }
}
