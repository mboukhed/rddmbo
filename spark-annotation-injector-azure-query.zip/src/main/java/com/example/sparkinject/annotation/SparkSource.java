package com.example.sparkinject.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface SparkSource {
    String query() default "";
    String path();
    String format(); // csv ou parquet
}
