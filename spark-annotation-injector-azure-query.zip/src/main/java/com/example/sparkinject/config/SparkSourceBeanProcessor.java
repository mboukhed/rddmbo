package com.example.sparkinject.config;

import com.example.sparkinject.annotation.SparkSource;
import org.apache.spark.sql.*;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.util.List;

@Component
public class SparkSourceBeanProcessor implements BeanPostProcessor, ApplicationContextAware {

    private ApplicationContext context;

    
    @Value("${azure.storage.account}")
    private String account;

    @Value("${azure.storage.key}")
    private String key;

        SparkSession spark = SparkSession.builder()
                .appName("SparkAutoInjection")
                .master("local[*]")
                .config("spark.hadoop.fs.azure.account.key." + account + ".blob.core.windows.net", key)
                .config("spark.hadoop.fs.azure.account.auth.type." + account + ".dfs.core.windows.net", "SharedKey")
                .config("spark.hadoop.fs.azure.account.key." + account + ".dfs.core.windows.net", key)
                .getOrCreate();

//
            .appName("SparkAutoInjection")
            .master("local[*]")
            .getOrCreate();

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        if (clazz.isAnnotationPresent(SparkSource.class)) {
            SparkSource annotation = clazz.getAnnotation(SparkSource.class);
            Dataset<Row> df;

            try {
                if ("csv".equalsIgnoreCase(annotation.format())) {
                    df = spark.read()
                            .option("header", "true")
                            .option("inferSchema", "true")
                            .csv(annotation.path());
                } else if ("parquet".equalsIgnoreCase(annotation.format())) {
                    df = spark.read().parquet(annotation.path());
                } else {
                    throw new RuntimeException("Unsupported format: " + annotation.format());
                }

                Encoder<?> encoder = Encoders.bean(clazz);
                @SuppressWarnings("unchecked")
                List<?> list = df.as((Encoder<Object>) encoder).collectAsList();

                String listBeanName = Introspector.decapitalize(clazz.getSimpleName()) + "List";
                ((ConfigurableApplicationContext) context)
                        .getBeanFactory()
                        .registerSingleton(listBeanName, list);

            } catch (Exception e) {
                throw new RuntimeException("Spark injection error for class: " + clazz.getName(), e);
            }
        }

        return bean;
    }
}
