package com.example.sparkinject.service;

import com.example.sparkinject.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;

@Component
public class MyComponent {

    @Autowired
    private List<Person> personList;

    @PostConstruct
    public void showPeople() {
        personList.forEach(System.out::println);
    }
}
