package com.example.sparkinject.config;

import com.example.sparkinject.annotation.CsvSource;
import com.example.sparkinject.annotation.ParquetSource;
import com.example.sparkinject.annotation.ExcelSource;
import org.apache.spark.sql.*;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.util.List;

@Component
public class SparkSourceBeanProcessor implements BeanPostProcessor, ApplicationContextAware {

    private ApplicationContext context;

    @Value("${azure.storage.account}")
    private String account;

    @Value("${azure.storage.key}")
    private String key;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        this.context = applicationContext;
    }

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        Dataset<Row> df = null;
        String viewName = clazz.getSimpleName().toLowerCase();

        SparkSession spark = SparkSession.builder()
                .appName("SparkAutoInjection")
                .master("local[*]")
                .config("spark.hadoop.fs.azure.account.key." + account + ".blob.core.windows.net", key)
                .config("spark.hadoop.fs.azure.account.auth.type." + account + ".dfs.core.windows.net", "SharedKey")
                .config("spark.hadoop.fs.azure.account.key." + account + ".dfs.core.windows.net", key)
                .config("spark.sql.parquet.mergeSchema", "true")
                .getOrCreate();

        try {
            if (clazz.isAnnotationPresent(CsvSource.class)) {
                CsvSource annotation = clazz.getAnnotation(CsvSource.class);
                df = spark.read()
                        .option("header", String.valueOf(annotation.header()))
                        .option("delimiter", annotation.delimiter())
                        .csv(annotation.path());
                df.createOrReplaceTempView(viewName);
                if (!annotation.query().isEmpty()) {
                    df = spark.sql(annotation.query());
                }

            
            } else if (clazz.isAnnotationPresent(ExcelSource.class)) {
                ExcelSource annotation = clazz.getAnnotation(ExcelSource.class);
                java.io.FileInputStream fis = new java.io.FileInputStream(annotation.path());
                org.apache.poi.ss.usermodel.Workbook wb = new org.apache.poi.xssf.usermodel.XSSFWorkbook(fis);
                org.apache.poi.ss.usermodel.Sheet sheet = wb.getSheet(annotation.sheet());

                java.util.List<org.apache.spark.sql.Row> rows = new java.util.ArrayList<>();
                java.util.Iterator<org.apache.poi.ss.usermodel.Row> iterator = sheet.iterator();
                org.apache.poi.ss.usermodel.Row headerRow = iterator.hasNext() ? iterator.next() : null;
                java.util.List<String> columns = new java.util.ArrayList<>();

                if (headerRow != null) {
                    for (org.apache.poi.ss.usermodel.Cell cell : headerRow) {
                        columns.add(cell.getStringCellValue());
                    }
                }

                while (iterator.hasNext()) {
                    org.apache.poi.ss.usermodel.Row row = iterator.next();
                    Object[] values = new Object[columns.size()];
                    for (int i = 0; i < columns.size(); i++) {
                        org.apache.poi.ss.usermodel.Cell cell = row.getCell(i);
                        if (cell != null) {
                            switch (cell.getCellType()) {
                                case STRING: values[i] = cell.getStringCellValue(); break;
                                case NUMERIC: values[i] = cell.getNumericCellValue(); break;
                                case BOOLEAN: values[i] = cell.getBooleanCellValue(); break;
                                default: values[i] = null;
                            }
                        } else {
                            values[i] = null;
                        }
                    }
                    rows.add(org.apache.spark.sql.RowFactory.create(values));
                }

                org.apache.spark.sql.types.StructField[] fields = new org.apache.spark.sql.types.StructField[columns.size()];
                for (int i = 0; i < columns.size(); i++) {
                    fields[i] = org.apache.spark.sql.types.DataTypes.createStructField(columns.get(i), org.apache.spark.sql.types.DataTypes.StringType, true);
                }

                org.apache.spark.sql.types.StructType schema = org.apache.spark.sql.types.DataTypes.createStructType(fields);
                df = spark.createDataFrame(rows, schema);

            } else if (clazz.isAnnotationPresent(ParquetSource.class)) {
                ParquetSource annotation = clazz.getAnnotation(ParquetSource.class);
                df = spark.read().parquet(annotation.path());
                df.createOrReplaceTempView(viewName);
                if (!annotation.query().isEmpty()) {
                    df = spark.sql(annotation.query());
                }
            }

            if (df != null) {
                Encoder<?> encoder = Encoders.bean(clazz);
                List<?> list = df.as((Encoder<Object>) encoder).collectAsList();

                String listBeanName = Introspector.decapitalize(clazz.getSimpleName()) + "List";
                ((ConfigurableApplicationContext) context)
                        .getBeanFactory()
                        .registerSingleton(listBeanName, list);
            }

        } catch (Exception e) {
            throw new RuntimeException("Erreur de traitement Spark pour " + clazz.getName(), e);
        }

        return bean;
    }
}
