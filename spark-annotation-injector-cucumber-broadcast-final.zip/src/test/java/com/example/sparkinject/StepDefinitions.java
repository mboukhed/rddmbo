package com.example.sparkinject;

import com.example.sparkinject.model.Person;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertFalse;

@SpringBootTest
public class StepDefinitions {

    @Autowired
    private List<Person> personList;

    @Given("the application context is loaded")
    public void contextIsLoaded() {
    }

    @Then("the bean 'personList' should contain some people")
    public void personListShouldContainData() {
        assertFalse(personList.isEmpty(), "The person list should not be empty");
    }
}
