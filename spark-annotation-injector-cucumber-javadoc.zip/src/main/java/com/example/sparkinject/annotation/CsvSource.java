package com.example.sparkinject.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component
public @interface CsvSource {
    String path();
    boolean header() default true;
    String delimiter() default ",";
    String query() default "";
}