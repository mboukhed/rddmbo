package com.example.sparkinject.config;

import org.apache.spark.broadcast.Broadcast;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
/**
 * Stocke tous les Broadcast<List<T>> injectés dans le contexte Spring,
 * accessibles dynamiquement par leur classe (ex : Person.class).
 */
public class BroadcastRegistry {

    private final Map<Class<?>, Broadcast<?>> registry = new HashMap<>();

    public <T> void register(Class<T> clazz, Broadcast<T> broadcast) {
        registry.put(clazz, broadcast);
    }

    @SuppressWarnings("unchecked")
    public <T> Broadcast<T> get(Class<T> clazz) {
        return (Broadcast<T>) registry.get(clazz);
    }

    public Map<Class<?>, Broadcast<?>> getAll() {
        return registry;
    }
}
