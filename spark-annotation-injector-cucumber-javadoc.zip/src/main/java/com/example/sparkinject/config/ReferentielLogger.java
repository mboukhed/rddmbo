package com.example.sparkinject.config;

import org.apache.spark.broadcast.Broadcast;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
/**
 * À chaque démarrage de l'application Spring,
 * affiche dans les logs tous les List<T> et Broadcast<List<T>> chargés automatiquement.
 */
public class ReferentielLogger implements ApplicationListener<ContextRefreshedEvent> {

    private static final Logger log = LoggerFactory.getLogger(ReferentielLogger.class);

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        ConfigurableListableBeanFactory beanFactory =
                (ConfigurableListableBeanFactory) event.getApplicationContext().getAutowireCapableBeanFactory();

        String[] beanNames = beanFactory.getBeanDefinitionNames();
        log.info("📦 Liste des référentiels chargés au démarrage :");

        for (String beanName : beanNames) {
            Object bean = beanFactory.getBean(beanName);
            if (bean instanceof List<?> list && !list.isEmpty()) {
                Class<?> itemType = list.get(0).getClass();
                log.info("✅ List<{}> injectée sous le nom '{}'", itemType.getSimpleName(), beanName);
            } else if (bean instanceof Broadcast<?> broadcast) {
                Object value = broadcast.value();
                if (value instanceof List<?> list && !list.isEmpty()) {
                    Class<?> itemType = list.get(0).getClass();
                    log.info("📡 Broadcast<List<{}>> injecté sous le nom '{}'", itemType.getSimpleName(), beanName);
                }
            }
        }
    }
}
