package com.example.sparkinject;

import org.apache.spark.sql.SparkSession;
import org.mockito.Mockito;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

@TestConfiguration
public class MockSparkConfig {

    @Bean
    public SparkSession sparkSessionMock() {
        return Mockito.mock(SparkSession.class);
    }
}
