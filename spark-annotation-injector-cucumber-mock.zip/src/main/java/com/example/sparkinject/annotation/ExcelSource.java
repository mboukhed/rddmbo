package com.example.sparkinject.annotation;

import org.springframework.stereotype.Component;

import java.lang.annotation.*;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@Component
public @interface ExcelSource {
    String path();
    String sheet() default "Sheet1";
}