package com.example.sparkinject;

import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@SpringBootTest(classes = {MockSparkConfig.class})
public class SparkSessionMockTest {

    @MockBean
    private SparkSession sparkSession;

    @Test
    void testSparkSessionIsMocked() {
        Mockito.when(sparkSession.version()).thenReturn("MOCK-SPARK");
        assertNotNull(sparkSession);
        System.out.println("Spark version (mock): " + sparkSession.version());
    }
}
