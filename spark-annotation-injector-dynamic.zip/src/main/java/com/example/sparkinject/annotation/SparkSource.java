package com.example.sparkinject.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface SparkSource {
    String path();
    String format(); // csv ou parquet
}
