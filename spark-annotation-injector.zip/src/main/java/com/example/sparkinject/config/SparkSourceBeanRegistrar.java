package com.example.sparkinject.config;

import com.example.sparkinject.annotation.SparkSource;
import org.apache.spark.sql.*;
import org.apache.spark.sql.Encoders;
import org.reflections.Reflections;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.stereotype.Component;

import java.beans.Introspector;
import java.util.List;
import java.util.Set;

@Component
public class SparkSourceBeanRegistrar implements BeanFactoryPostProcessor {

    private final SparkSession spark = SparkSession.builder()
            .appName("SparkSourceLoader")
            .master("local[*]")
            .getOrCreate();

    @Override
    public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
        Reflections reflections = new Reflections("com.example.sparkinject.model");

        Set<Class<?>> pojoClasses = reflections.getTypesAnnotatedWith(SparkSource.class);
        for (Class<?> clazz : pojoClasses) {
            SparkSource meta = clazz.getAnnotation(SparkSource.class);

            Dataset<Row> df;
            if ("csv".equalsIgnoreCase(meta.format())) {
                df = spark.read()
                        .option("header", "true")
                        .option("inferSchema", "true")
                        .csv(meta.path());
            } else if ("parquet".equalsIgnoreCase(meta.format())) {
                df = spark.read().parquet(meta.path());
            } else {
                throw new RuntimeException("Unsupported format: " + meta.format());
            }

            Encoder<?> encoder = Encoders.bean(clazz);
            List<?> list = df.as(encoder).collectAsList();

            String beanName = Introspector.decapitalize(clazz.getSimpleName()) + "List";
            beanFactory.registerSingleton(beanName, list);
        }
    }
}
