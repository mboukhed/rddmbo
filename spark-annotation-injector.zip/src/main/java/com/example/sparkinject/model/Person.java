package com.example.sparkinject.model;

import com.example.sparkinject.annotation.SparkSource;
import java.io.Serializable;

@SparkSource(path = "src/main/resources/people.csv", format = "csv")
public class Person implements Serializable {
    private String name;
    private int age;

    public Person() {}

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}
