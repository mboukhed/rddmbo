package com.example.referential.models;

import com.example.referential.annotations.ReferentialMapping;
import com.example.referential.annotations.Key;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Qualifier;

@Component
@Qualifier("personReferential")
@ReferentialMapping(
    path = "src/main/resources/persons.csv",
    format = "csv",
    broadcast = true
)
@ReferentialKey("id")
public class Person {
    private String id;
    private String name;
    private int age;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}