package com.example.referential;

import com.example.referential.models.QualifiedPersonComplexReferential;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {QualifiedPersonComplexReferential.class})
public class QualifiedComplexReferentialTest {

    @Autowired
    @Qualifier("qualifiedPersonComplexReferential")
    private QualifiedPersonComplexReferential ref;

    @Test
    void testQualifiedComplexBeanInjection() {
        assertNotNull(ref.list);
        assertNotNull(ref.map);
        assertNotNull(ref.broadcastList);
        assertNotNull(ref.broadcastMap);
    }
}