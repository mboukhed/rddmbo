package com.example.referential.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ReferentialMapping {
    String path();
    String format() default "csv"; // csv, parquet, json, xml, avro, excel
    String beanName() default "";
    boolean broadcast() default false;
    boolean verifyUniqueKey() default false;
    boolean lazyLoading() default true;
    String query() default "";  // SQL query to apply
    String filter() default ""; // Row-level filter expression
}