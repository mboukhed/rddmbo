package com.example.referential.core;

import com.example.referential.annotations.*;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;
import java.util.*;

@Component
public class ReferentialLoader {
    private final SparkSession spark;

    public ReferentialLoader(SparkSession spark) {
        this.spark = spark;
    }

    public <T> List<T> loadList(Class<T> clazz) {
        if (!AuthorizationService.isAuthorized(clazz)) {
            throw new RuntimeException("Unauthorized access to referential: " + clazz.getSimpleName());
        }

        ReferentialMapping meta = clazz.getAnnotation(ReferentialMapping.class);
        if (meta == null) throw new RuntimeException("Missing @ReferentialMapping");

        
        Dataset<Row> df;
        switch (meta.format()) {
            case "json":
                df = spark.read().json(meta.path());
                break;
            case "xml":
                df = spark.read().format("xml").option("rowTag", "person").load(meta.path());
                break;
            case "parquet":
                df = spark.read().parquet(meta.path());
                break;
            case "avro":
                df = spark.read().format("avro").load(meta.path());
                break;
            case "excel":
                df = spark.read().format("com.crealytics.spark.excel")
                        .option("useHeader", "true")
                        .option("inferSchema", "true")
                        .load(meta.path());
                break;
            default:
                df = spark.read().format("csv").option("header", "true").load(meta.path());
        }

        if (!meta.query().isEmpty()) {
            df.createOrReplaceTempView("referential_tmp");
            df = spark.sql(meta.query());
        } else if (!meta.filter().isEmpty()) {
            df = df.filter(meta.filter());
        }
Encoder<T> encoder = Encoders.bean(clazz);
        return df.as(encoder).collectAsList();
    }

    public <T, K> Map<K, T> loadMap(Class<T> clazz, Class<K> keyClass) {
        List<T> list = loadList(clazz);
        Map<K, T> map = new HashMap<>();
        for (T item : list) {
            K key = extractKey(item);
            map.put(key, item);
        }
        return map;
    }

    public <T> Broadcast<List<T>> broadcastList(Class<T> clazz, JavaSparkContext jsc) {
        return jsc.broadcast(loadList(clazz));
    }

    private <T, K> K extractKey(T obj) {
        try {
            K key = null;
            Key keyAnn = obj.getClass().getAnnotation(Key.class);
            ComplexKey complexKeyAnn = obj.getClass().getAnnotation(ComplexKey.class);

            if (keyAnn != null) {
                Field keyField = obj.getClass().getDeclaredField(keyAnn.value());
                keyField.setAccessible(true);
                key = (K) keyField.get(obj);
            } else if (complexKeyAnn != null) {
                Class<K> keyClass = (Class<K>) complexKeyAnn.value();
                Constructor<K> ctor = keyClass.getDeclaredConstructor();
                key = ctor.newInstance();
                for (Field field : keyClass.getDeclaredFields()) {
                    Field sourceField = obj.getClass().getDeclaredField(field.getName());
                    sourceField.setAccessible(true);
                    field.setAccessible(true);
                    field.set(key, sourceField.get(obj));
                }
            } else {
                throw new RuntimeException("No key defined for class: " + obj.getClass().getSimpleName());
            }
            return key;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}