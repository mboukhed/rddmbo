package com.example.referential.lifecycle;

import com.example.referential.annotations.ReferentialKey;
import com.example.referential.annotations.ReferentialMapping;
import com.example.referential.core.ReferentialLoader;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;
import java.util.List;
import java.util.Map;

@Component
public class ReferentialInitializer implements BeanPostProcessor {

    private final ReferentialLoader loader;
    private final JavaSparkContext jsc;

    public ReferentialInitializer(ReferentialLoader loader, JavaSparkContext jsc) {
        this.loader = loader;
        this.jsc = jsc;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
        Class<?> clazz = bean.getClass();
        if (clazz.getAnnotation(ReferentialMapping.class) != null) {
            try {
                for (Field field : clazz.getDeclaredFields()) {
                    field.setAccessible(true);
                    if (List.class.isAssignableFrom(field.getType())) {
                        List<?> list = loader.loadList(clazz);
                        field.set(bean, list);
                    } else if (Map.class.isAssignableFrom(field.getType())) {
                        ParameterizedType pt = (ParameterizedType) field.getGenericType();
                        Class<?> keyClass = (Class<?>) pt.getActualTypeArguments()[0];
                        Map<?, ?> map = loader.loadMap(clazz, keyClass);
                        field.set(bean, map);
                    } else if (Broadcast.class.isAssignableFrom(field.getType())) {
                        ParameterizedType pt = (ParameterizedType) field.getGenericType();
                        Type bType = pt.getActualTypeArguments()[0];
                        if (bType.getTypeName().startsWith("java.util.List")) {
                            Broadcast<?> bcast = loader.broadcastList(clazz, jsc);
                            field.set(bean, bcast);
                        } else if (bType.getTypeName().startsWith("java.util.Map")) {
                            Type[] types = ((ParameterizedType) bType).getActualTypeArguments();
                            Class<?> keyClass = (Class<?>) types[0];
                            Map<?, ?> map = loader.loadMap(clazz, keyClass);
                            Broadcast<?> bcast = jsc.broadcast(map);
                            field.set(bean, bcast);
                        }
                    }
                }
            } catch (Exception e) {
                throw new RuntimeException("Injection failed for referential: " + clazz.getSimpleName(), e);
            }
        }
        return bean;
    }
}