package com.example.referential.models;

public class PersonComplexKey {
    private String id;
    private String name;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PersonComplexKey)) return false;
        PersonComplexKey key = (PersonComplexKey) o;
        return id.equals(key.id) && name.equals(key.name);
    }

    @Override
    public int hashCode() {
        return id.hashCode() * 31 + name.hashCode();
    }
}