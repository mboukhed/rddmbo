package com.example.referential;

import com.example.referential.models.QualifiedPersonReferential;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertNotNull;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {QualifiedPersonReferential.class})
public class QualifiedReferentialInjectionTest {

    @Autowired
    @Qualifier("qualifiedPersonReferential")
    private QualifiedPersonReferential referential;

    @Test
    void testQualifiedBeanInjection() {
        assertNotNull(referential);
        assertNotNull(referential.list);
        assertNotNull(referential.map);
        assertNotNull(referential.broadcastList);
        assertNotNull(referential.broadcastMap);
    }
}