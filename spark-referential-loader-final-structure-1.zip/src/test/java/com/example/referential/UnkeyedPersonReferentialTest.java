package com.example.referential;

import com.example.referential.models.UnkeyedPerson;
import org.apache.spark.broadcast.Broadcast;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = {UnkeyedPerson.class})
public class UnkeyedPersonReferentialTest {

    @Autowired
    @Qualifier("unkeyedPersonReferential")
    private List<UnkeyedPerson> unkeyedList;

    @Autowired
    @Qualifier("unkeyedPersonReferential")
    private Map<Integer, UnkeyedPerson> unkeyedMap;

    @Autowired
    @Qualifier("unkeyedPersonReferential")
    private Broadcast<List<UnkeyedPerson>> unkeyedBroadcastList;

    @Autowired
    @Qualifier("unkeyedPersonReferential")
    private Broadcast<Map<Integer, UnkeyedPerson>> unkeyedBroadcastMap;

    @Test
    void testUnkeyedReferential() {
        assertNotNull(unkeyedList);
        assertEquals(2, unkeyedList.size());

        assertNotNull(unkeyedMap);
        assertEquals(2, unkeyedMap.size());

        assertNotNull(unkeyedBroadcastList.getValue());
        assertNotNull(unkeyedBroadcastMap.getValue());
    }
}