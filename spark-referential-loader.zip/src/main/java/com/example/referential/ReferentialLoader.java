package com.example.referential.core;

import com.example.referential.annotations.*;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.springframework.stereotype.Component;

import java.lang.reflect.*;
import java.util.*;

@Component
public class ReferentialLoader {
    private final SparkSession spark;

    public ReferentialLoader(SparkSession spark) {
        this.spark = spark;
    }

    public <T> List<T> loadList(Class<T> clazz) {
        ReferentialMapping meta = clazz.getAnnotation(ReferentialMapping.class);
        if (meta == null) throw new RuntimeException("Missing @ReferentialMapping");

        
        switch (meta.format()) {
            case "json":
                df = spark.read().json(meta.path());
                break;
            case "xml":
                df = spark.read().format("xml").option("rowTag", "person").load(meta.path());
                break;
            default:
                df = spark.read().format(meta.format()).option("header", "true").load(meta.path());
        }

        Encoder<T> encoder = Encoders.bean(clazz);
        return df.as(encoder).collectAsList();
    }

    public <T, K> Map<K, T> loadMap(Class<T> clazz, Class<K> keyClass) {
        List<T> list = loadList(clazz);
        Map<K, T> map = new HashMap<>();
        for (T item : list) {
            K key = extractKey(item, keyClass);
            map.put(key, item);
        }
        return map;
    }

    public <T> Broadcast<List<T>> broadcastList(Class<T> clazz, JavaSparkContext jsc) {
        return jsc.broadcast(loadList(clazz));
    }

    private <T, K> K extractKey(T obj, Class<K> keyClass) {
        try {
            Constructor<K> ctor = keyClass.getDeclaredConstructor();
            K key = ctor.newInstance();
            for (Field field : keyClass.getDeclaredFields()) {
                Field sourceField = obj.getClass().getDeclaredField(field.getName());
                sourceField.setAccessible(true);
                field.setAccessible(true);
                field.set(key, sourceField.get(obj));
            }
            return key;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}