package com.example.referential.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ReferentialKey {
    String value() default "";              // clé simple : nom du champ
    Class<?> complex() default Void.class;  // clé complexe : classe de clé
}