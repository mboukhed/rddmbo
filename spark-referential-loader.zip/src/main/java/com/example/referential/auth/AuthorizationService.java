package com.example.referential.auth;

import java.util.HashMap;
import java.util.Map;

public class AuthorizationService {
    private static final Map<Class<?>, Boolean> accessControl = new HashMap<>();

    public static void authorize(Class<?> clazz) {
        accessControl.put(clazz, true);
    }

    public static void revoke(Class<?> clazz) {
        accessControl.put(clazz, false);
    }

    public static boolean isAuthorized(Class<?> clazz) {
        return accessControl.getOrDefault(clazz, false);
    }
}