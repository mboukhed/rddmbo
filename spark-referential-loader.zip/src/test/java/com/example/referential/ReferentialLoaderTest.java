package com.example.referential;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.Person;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.*;

import java.util.List;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ReferentialLoaderTest {

    private SparkSession spark;
    private ReferentialLoader loader;

    @BeforeAll
    void setup() {
        SparkConf conf = new SparkConf().setAppName("TestApp").setMaster("local[*]");
        spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
    }

    @Test
    void testLoadList() {
        List<Person> persons = loader.loadList(Person.class);
        Assertions.assertEquals(2, persons.size());
        Assertions.assertEquals("Jean", persons.get(0).getName());
    }
}