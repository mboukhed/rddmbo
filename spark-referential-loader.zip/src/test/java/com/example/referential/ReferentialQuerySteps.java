package com.example.referential.cucumber;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.PersonFiltered;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReferentialQuerySteps {
    private ReferentialLoader loader;
    private List<PersonFiltered> filteredList;

    @Given("le référentiel PersonFiltered est chargé avec la requête SQL")
    public void chargerReferentielAvecRequete() {
        SparkConf conf = new SparkConf().setAppName("QueryCucumberApp").setMaster("local[*]");
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
        filteredList = loader.loadList(PersonFiltered.class);
    }

    @Then("le résultat contient uniquement les personnes de plus de {int} ans")
    public void verifierFiltrage(int age) {
        assertEquals(1, filteredList.size());
        assertEquals("Jean", filteredList.get(0).getName());
    }
}