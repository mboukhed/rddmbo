package com.example.services;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
public class ClickHouseService {

    private final SparkSession spark;

    public ClickHouseService(SparkSession spark) {
        this.spark = spark;
    }

    public Dataset<Row> readFromClickHouse(String url, String table, Properties props) {
        return spark.read()
                .jdbc(url, table, props);
    }

    public void writeToClickHouse(Dataset<Row> df, String url, String table, Properties props) {
        df.write()
          .mode("append")
          .jdbc(url, table, props);
    }
}