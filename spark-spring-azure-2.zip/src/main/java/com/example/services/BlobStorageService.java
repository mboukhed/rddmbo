package com.example.services;

import com.azure.core.credential.TokenCredential;
import com.azure.storage.blob.*;
import com.azure.storage.blob.models.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.example.azureauth.AzureCredentialProvider;

@Service
public class BlobStorageService {

    private final BlobServiceClient blobServiceClient;

    public BlobStorageService(AzureCredentialProvider provider,
                              @Value("${azure.storage.account-name}") String accountName) {
        TokenCredential credential = provider.getCredential();
        String endpoint = String.format("https://%s.blob.core.windows.net", accountName);
        this.blobServiceClient = new BlobServiceClientBuilder()
                .endpoint(endpoint)
                .credential(credential)
                .buildClient();
    }

    public void listContainers() {
        blobServiceClient.listBlobContainers().forEach(container ->
                System.out.println("Container: " + container.getName()));
    }

    public void uploadBlob(String containerName, String blobName, String content) {
        BlobClient blobClient = blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobName);
        blobClient.uploadFromByteArray(content.getBytes(), 0, content.length(), true);
    }

    public String downloadBlob(String containerName, String blobName) {
        BlobClient blobClient = blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobName);
        return new String(blobClient.downloadContent().toBytes());
    }

    public void deleteBlob(String containerName, String blobName) {
        blobServiceClient.getBlobContainerClient(containerName).getBlobClient(blobName).delete();
    }
}