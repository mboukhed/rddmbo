# Spark Spring Azure Integration

## 📦 Projet Java 17 + Spring Core + Apache Spark + Azure

Ce projet est une base complète pour exécuter une application Spark avec Spring Core dans Azure, incluant :

- 🔐 **Key Vault** : lecture/écriture/suppression de secrets
- 📦 **Blob Storage** : gestion de blobs
- 📂 **Data Lake** : lecture des file systems et répertoires
- 💾 **ClickHouse** : lecture/écriture Spark via JDBC
- 🔥 **SparkSession** injecté dans Spring
- 🧠 **Gestion dynamique des identités Azure** via profils Spring (`managed`, `client-secret`, `vault-client-secret`, `chained-auth`)

---

## ⚙️ Configuration

Fichier `src/main/resources/application.properties` :

```properties
spring.profiles.active=chained-auth

# Key Vault
azure.keyvault.name=your-vault-name

# Azure Identity
azure.client-id=xxxx
azure.client-secret=yyyy
azure.tenant-id=zzzz

# Storage
azure.storage.account-name=your-storage-account
```

---

## 🧩 Services disponibles

### 🔐 VaultService
- `getSecret(name)`
- `setSecret(name, value)`
- `deleteSecret(name)`

### 📦 BlobStorageService
- `listContainers()`
- `uploadBlob(container, name, content)`
- `downloadBlob(container, name)`
- `deleteBlob(container, name)`

### 📂 DataLakeService
- `listFileSystems()`
- `listFiles(fsName, dirPath)`

### 💾 ClickHouseService
- `readFromClickHouse(url, table, props)`
- `writeToClickHouse(df, url, table, props)`

### 🔥 SparkSessionProvider
- Crée automatiquement un SparkSession injecté

---

## 🧠 Choix du mode d'identification

Selon le profil Spring (`spring.profiles.active`) :

- `managed` : Managed Identity (AKS, App Service)
- `client-secret` : App Registration + Secret
- `vault-client-secret` : Secret récupéré depuis Key Vault
- `chained-auth` : Cascade (Managed > Secret > CLI > VSCode)

---

## 🚀 Lancer l'application

```bash
mvn clean compile
```

Pour exécuter en local avec Spark :

```bash
-Dspring.profiles.active=chained-auth mvn exec:java
```

---

## 📌 Remarques

- Pour l’environnement AKS, pense à attribuer le rôle "Key Vault Secrets User" à ton identité managée.
- Les dépendances Spark sont en `scope=provided` pour ne pas être embarquées dans le JAR final.