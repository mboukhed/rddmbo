package com.example.services;

import com.azure.core.credential.TokenCredential;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.example.azureauth.AzureCredentialProvider;

@Service
public class VaultService {

    private final SecretClient secretClient;

    public VaultService(AzureCredentialProvider provider,
                        @Value("${azure.keyvault.name}") String vaultName) {
        TokenCredential credential = provider.getCredential();
        this.secretClient = new SecretClientBuilder()
                .vaultUrl("https://" + vaultName + ".vault.azure.net")
                .credential(credential)
                .buildClient();
    }

    public String getSecret(String name) {
        return secretClient.getSecret(name).getValue();
    }

    public void setSecret(String name, String value) {
        secretClient.setSecret(name, value);
    }

    public void deleteSecret(String name) {
        secretClient.beginDeleteSecret(name).waitForCompletion();
    }
}