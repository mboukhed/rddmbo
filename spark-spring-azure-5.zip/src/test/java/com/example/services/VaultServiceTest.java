package com.example.services;

import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class VaultServiceTest {

    private VaultService vaultService;
    private SecretClient mockClient;

    @BeforeEach
    void setup() {
        mockClient = mock(SecretClient.class);
        vaultService = new VaultService(null, null) {
            {
                this.secretClient = mockClient;
            }
        };
    }

    @Test
    void testGetSecret() {
        when(mockClient.getSecret("my-secret")).thenReturn(new KeyVaultSecret("my-secret", "secret-value"));
        String value = vaultService.getSecret("my-secret");
        assertEquals("secret-value", value);
    }

    @Test
    void testSetSecret() {
        vaultService.setSecret("my-secret", "new-value");
        verify(mockClient, times(1)).setSecret("my-secret", "new-value");
    }

    @Test
    void testDeleteSecret() {
        when(mockClient.beginDeleteSecret("my-secret")).thenReturn(Mockito.mock(com.azure.core.util.polling.SyncPoller.class));
        vaultService.deleteSecret("my-secret");
        verify(mockClient, times(1)).beginDeleteSecret("my-secret");
    }
}