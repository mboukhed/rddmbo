package com.example;

import com.example.services.ClickHouseService;
import com.example.services.CosmosDBService;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Properties;

public class JobRunner {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.example");

        ClickHouseService clickHouseService = context.getBean(ClickHouseService.class);
        CosmosDBService cosmosDBService = context.getBean(CosmosDBService.class);

        String cosmosEndpoint = System.getenv("COSMOS_ENDPOINT");
        String cosmosKey = System.getenv("COSMOS_KEY");

        String db = "your-database";
        String container = "your-container";

        Dataset<Row> cosmosDF = cosmosDBService.readFromCosmosDB(cosmosEndpoint, cosmosKey, db, container);
        cosmosDF.show();

        String clickHouseUrl = "jdbc:clickhouse://host:port/db";
        Properties props = new Properties();
        props.setProperty("user", "default");
        props.setProperty("password", "");

        clickHouseService.writeToClickHouse(cosmosDF, clickHouseUrl, "target_table", props);

        context.close();
    }
}