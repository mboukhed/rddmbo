package com.example.services;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CosmosDBService {

    private final SparkSession spark;

    public CosmosDBService(SparkSession spark) {
        this.spark = spark;
    }

    public Dataset<Row> readFromCosmosDB(String endpoint, String key, String database, String container) {
        Map<String, String> readConfig = new HashMap<>();
        readConfig.put("spark.cosmos.accountEndpoint", endpoint);
        readConfig.put("spark.cosmos.accountKey", key);
        readConfig.put("spark.cosmos.database", database);
        readConfig.put("spark.cosmos.container", container);
        readConfig.put("spark.cosmos.read.inferSchema.enabled", "true");

        return spark.read().format("cosmos.oltp").options(readConfig).load();
    }

    public void writeToCosmosDB(Dataset<Row> df, String endpoint, String key, String database, String container) {
        Map<String, String> writeConfig = new HashMap<>();
        writeConfig.put("spark.cosmos.accountEndpoint", endpoint);
        writeConfig.put("spark.cosmos.accountKey", key);
        writeConfig.put("spark.cosmos.database", database);
        writeConfig.put("spark.cosmos.container", container);

        df.write()
          .format("cosmos.oltp")
          .mode("append")
          .options(writeConfig)
          .save();
    }
}