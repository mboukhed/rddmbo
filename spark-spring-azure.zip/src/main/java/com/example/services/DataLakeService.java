package com.example.services;

import com.azure.core.credential.TokenCredential;
import com.azure.storage.file.datalake.*;
import com.azure.storage.file.datalake.models.PathItem;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.example.azureauth.AzureCredentialProvider;

@Service
public class DataLakeService {

    private final DataLakeServiceClient dataLakeServiceClient;

    public DataLakeService(AzureCredentialProvider provider,
                           @Value("${azure.storage.account-name}") String accountName) {
        TokenCredential credential = provider.getCredential();
        String endpoint = String.format("https://%s.dfs.core.windows.net", accountName);
        this.dataLakeServiceClient = new DataLakeServiceClientBuilder()
                .endpoint(endpoint)
                .credential(credential)
                .buildClient();
    }

    public void listFileSystems() {
        dataLakeServiceClient.listFileSystems().forEach(fs ->
                System.out.println("FileSystem: " + fs.getName()));
    }

    public void listFiles(String fileSystemName, String directoryPath) {
        DataLakeFileSystemClient fsClient = dataLakeServiceClient.getFileSystemClient(fileSystemName);
        fsClient.getDirectoryClient(directoryPath).listPaths().forEach(path ->
                System.out.println("File: " + path.getName()));
    }
}