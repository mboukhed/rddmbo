
package com.project.sparkadls.config;

import org.apache.hadoop.conf.Configuration;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration;

@SpringConfiguration
public class SparkConfiguration {

    @Value("${spark.app.name:SparkSecure}")
    private String appName;

    @Value("${spark.master.url:local[*]}")
    private String masterUrl;

    @Bean
    public SparkSession sparkSession() {
        SparkConf sparkConf = new SparkConf().setAppName(appName).setMaster(masterUrl);
        return SparkSession.builder().config(sparkConf).getOrCreate();
    }

    @Bean
    public JavaSparkContext javaSparkContext(SparkSession sparkSession) {
        return new JavaSparkContext(sparkSession.sparkContext());
    }
}
