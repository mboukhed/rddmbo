
package com.project.sparkadls.config;

import com.project.sparkadls.secrets.SecretProviderService;
import org.apache.hadoop.conf.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AdlsConfiguration {

    @Value("${adls.account.name}")
    private String accountName;

    @Value("${adls.auth.type}")
    private String authType;

    private final SecretProviderService secretProviderService;

    public AdlsConfiguration(SecretProviderService secretProviderService) {
        this.secretProviderService = secretProviderService;
    }

    public void configure(Configuration conf) {
        String fsKey = String.format("fs.azure.account.auth.type.%s.dfs.core.windows.net", accountName);
        conf.set(fsKey, authType);

        if ("OAuth".equalsIgnoreCase(authType)) {
            conf.set(String.format("fs.azure.account.oauth.provider.type.%s.dfs.core.windows.net", accountName),
                    "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider");
            conf.set(String.format("fs.azure.account.oauth2.client.id.%s.dfs.core.windows.net", accountName),
                    secretProviderService.getClientId());
            conf.set(String.format("fs.azure.account.oauth2.client.secret.%s.dfs.core.windows.net", accountName),
                    secretProviderService.getClientSecret());
            conf.set(String.format("fs.azure.account.oauth2.client.endpoint.%s.dfs.core.windows.net", accountName),
                    String.format("https://login.microsoftonline.com/%s/oauth2/token", secretProviderService.getTenantId()));
        } else if ("ManagedIdentity".equalsIgnoreCase(authType)) {
            conf.set(String.format("fs.azure.account.oauth.provider.type.%s.dfs.core.windows.net", accountName),
                    "org.apache.hadoop.fs.azurebfs.oauth2.MsiTokenProvider");
        }
    }
}
