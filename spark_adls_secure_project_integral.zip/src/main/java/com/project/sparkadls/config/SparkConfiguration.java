
package com.project.sparkadls.config;

import com.project.sparkadls.secrets.SecretProviderService;
import org.apache.hadoop.conf.Configuration;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration as SpringConfiguration;

@SpringConfiguration
public class SparkConfiguration {

    @Value("${spark.app.name:SparkSecure}")
    private String appName;

    @Value("${spark.master.url:local[*]}")
    private String masterUrl;

    private final AdlsConfiguration adlsConfiguration;

    public SparkConfiguration(AdlsConfiguration adlsConfiguration) {
        this.adlsConfiguration = adlsConfiguration;
    }

    @Bean
    public SparkSession sparkSession() {
        SparkConf sparkConf = new SparkConf().setAppName(appName).setMaster(masterUrl);
        return SparkSession.builder().config(sparkConf).getOrCreate();
    }

    @Bean
    public JavaSparkContext javaSparkContext(SparkSession sparkSession) {
        return new JavaSparkContext(sparkSession.sparkContext());
    }

    @Bean
    public Configuration hadoopConfiguration(SparkSession sparkSession) {
        Configuration conf = sparkSession.sparkContext().hadoopConfiguration();
        adlsConfiguration.configure(conf);
        return conf;
    }
}
