
package com.project.sparkadls.secrets;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("local")
public class MockSecretProvider implements SecretProviderService {

    @Override
    public String getClientId() {
        return System.getenv().getOrDefault("ADLS_CLIENT_ID", "mock-client-id");
    }

    @Override
    public String getClientSecret() {
        return System.getenv().getOrDefault("ADLS_CLIENT_SECRET", "mock-client-secret");
    }

    @Override
    public String getTenantId() {
        return System.getenv().getOrDefault("ADLS_TENANT_ID", "mock-tenant-id");
    }
}
