
package com.project.sparkadls.secrets;

public interface SecretProviderService {
    String getClientId();
    String getClientSecret();
    String getTenantId();
}
