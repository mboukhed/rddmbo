
package com.project.sparkadls.service;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

@Service
public class AdlsFileListerService {

    private final Configuration hadoopConf;

    @Value("${adls.account.name}")
    private String accountName;

    @Value("${adls.container.name:container}")
    private String containerName;

    public AdlsFileListerService(Configuration hadoopConf) {
        this.hadoopConf = hadoopConf;
    }

    public List<String> listFiles(String directoryPath) throws IOException {
        String pathStr = String.format("abfss://%s@%s.dfs.core.windows.net/%s", containerName, accountName, directoryPath);
        Path path = new Path(pathStr);
        FileSystem fs = FileSystem.get(URI.create(pathStr), hadoopConf);
        RemoteIterator<LocatedFileStatus> files = fs.listFiles(path, true);

        List<String> result = new ArrayList<>();
        while (files.hasNext()) {
            LocatedFileStatus file = files.next();
            result.add(file.getPath().toString());
        }
        return result;
    }
}
