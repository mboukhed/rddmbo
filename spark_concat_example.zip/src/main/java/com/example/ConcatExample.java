
package com.example;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;

import static org.apache.spark.sql.functions.*;

import java.util.Arrays;
import java.util.List;

public class ConcatExample {
    public static void main(String[] args) {
        SparkSession spark = SparkSession.builder()
                .appName("ConcatExample")
                .master("local[*]")
                .getOrCreate();

        // Dataset with parameter and value columns (simulate 30 lines)
        List<Row> data = Arrays.asList(
            org.apache.spark.sql.RowFactory.create("A", "1"),
            org.apache.spark.sql.RowFactory.create("B", "2"),
            org.apache.spark.sql.RowFactory.create("C", "3"),
            org.apache.spark.sql.RowFactory.create("D", "4"),
            org.apache.spark.sql.RowFactory.create("E", "5")
        );

        Dataset<Row> dataset30 = spark.createDataFrame(data,
                org.apache.spark.sql.types.DataTypes.createStructType(Arrays.asList(
                        org.apache.spark.sql.types.DataTypes.createStructField("parameter", org.apache.spark.sql.types.DataTypes.StringType, false),
                        org.apache.spark.sql.types.DataTypes.createStructField("value", org.apache.spark.sql.types.DataTypes.StringType, false)
                )));

        // Combine to a single row
        Dataset<Row> combined = dataset30.agg(
                concat_ws(";", collect_list(col("parameter"))).alias("parameter"),
                concat_ws(";", collect_list(col("value"))).alias("value")
        );

        combined.show(false);

        // Base dataset to merge with
        List<Row> baseData = Arrays.asList(
            org.apache.spark.sql.RowFactory.create("X", "100"),
            org.apache.spark.sql.RowFactory.create("Y", "200")
        );

        Dataset<Row> baseDataset = spark.createDataFrame(baseData,
                org.apache.spark.sql.types.DataTypes.createStructType(Arrays.asList(
                        org.apache.spark.sql.types.DataTypes.createStructField("parameter", org.apache.spark.sql.types.DataTypes.StringType, false),
                        org.apache.spark.sql.types.DataTypes.createStructField("value", org.apache.spark.sql.types.DataTypes.StringType, false)
                )));

        // Union with the combined row
        Dataset<Row> result = baseDataset.unionByName(combined);
        result.show(false);

        spark.stop();
    }
}
