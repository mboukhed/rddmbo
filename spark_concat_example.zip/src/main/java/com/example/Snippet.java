package com.example;

// Snippet de transformation Spark
public class Snippet {
    // Code d'exemple
    /*

import static org.apache.spark.sql.functions.*;

Dataset<Row> dataset30 = ...; // Ton dataset original avec les colonnes "parameter" et "value"

// Créer une seule ligne concaténée
Dataset<Row> combined = dataset30.agg(
    concat_ws(";", collect_list(col("parameter"))).alias("parameter"),
    concat_ws(";", collect_list(col("value"))).alias("value")
);
    */
}