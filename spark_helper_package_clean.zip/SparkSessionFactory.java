
package com.spark.helper;

import org.apache.spark.sql.SparkSession;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SparkSessionFactory {

    private static final Pattern ABFS_PATTERN = Pattern.compile("abfss?://[^@]+@([^\\.]+)\\.dfs\\.core\\.windows\\.net/.*");

    public static SparkSession createSparkSession(String appName, String propertiesFile) throws IOException {
        SparkSession.Builder builder = SparkSession.builder().appName(appName);

        String clientId = getEnv("AZURE_CLIENT_ID");
        String clientSecret = getEnv("AZURE_CLIENT_SECRET");
        String tenantId = getEnv("AZURE_TENANT_ID");

        Properties props = new Properties();
        try (InputStream input = SparkSessionFactory.class.getClassLoader().getResourceAsStream(propertiesFile)) {
            if (input == null) {
                throw new IllegalArgumentException("Cannot find properties file: " + propertiesFile);
            }
            props.load(input);
        }

        Set<String> storageAccounts = extractStorageAccounts(props);

        for (String storageAccount : storageAccounts) {
            String prefix = "spark.hadoop.fs.azure.account.";
            builder.config(prefix + "auth.type." + storageAccount + ".dfs.core.windows.net", "OAuth")
                   .config(prefix + "oauth.provider.type." + storageAccount + ".dfs.core.windows.net", 
                           "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
                   .config(prefix + "oauth2.client.id." + storageAccount + ".dfs.core.windows.net", clientId)
                   .config(prefix + "oauth2.client.secret." + storageAccount + ".dfs.core.windows.net", clientSecret)
                   .config(prefix + "oauth2.client.endpoint." + storageAccount + ".dfs.core.windows.net", 
                           "https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
        }

        String sparkMode = Optional.ofNullable(System.getenv("SPARK_MODE")).orElse("cluster");
        if ("local".equalsIgnoreCase(sparkMode)) {
            builder.master("local[*]");
        }

        return builder.getOrCreate();
    }

    private static Set<String> extractStorageAccounts(Properties props) {
        Set<String> storageAccounts = new HashSet<>();
        for (Object valueObj : props.values()) {
            String value = valueObj.toString();
            Matcher matcher = ABFS_PATTERN.matcher(value);
            if (matcher.matches()) {
                storageAccounts.add(matcher.group(1));
            }
        }
        return storageAccounts;
    }

    private static String getEnv(String key) {
        String value = System.getenv(key);
        if (value == null || value.isEmpty()) {
            throw new IllegalArgumentException("Missing environment variable: " + key);
        }
        return value;
    }
}
