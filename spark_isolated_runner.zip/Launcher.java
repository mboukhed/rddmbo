import org.apache.spark.sql.*;

import java.util.Arrays;
import java.util.List;

public class Launcher {
    public static void main(String[] args) throws Exception {
        SparkSession spark = SparkSession.builder()
                .appName("LauncherJob")
                .master("local[*]")
                .getOrCreate();

        List<Row> data = Arrays.asList(
                RowFactory.create("Alice", 30),
                RowFactory.create("Bob", 40)
        );

        StructType schema = new StructType()
                .add("name", "string")
                .add("age", "integer");

        Dataset<Row> df = spark.createDataFrame(data, schema);
        df.write().mode("overwrite").parquet("target/output/mydata.parquet");

        spark.stop();
    }
}