
package com.example.utils;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

public class SparkPathHelper {

    public static boolean isCloudPath(String path) {
        String lowerPath = path.toLowerCase();
        return lowerPath.startsWith("abfs://") ||
               lowerPath.startsWith("wasbs://") ||
               lowerPath.startsWith("adl://") ||
               lowerPath.startsWith("s3://") ||
               lowerPath.startsWith("s3a://") ||
               lowerPath.startsWith("https://");
    }

    public static String toSparkLocalFilePath(String absolutePath) {
        String correctedPath = absolutePath.replace("\\", "/");
        if (correctedPath.startsWith("/")) {
            return "file://" + correctedPath;
        } else if (correctedPath.matches("^[A-Za-z]:/.*")) {
            return "file:///" + correctedPath;
        } else {
            return "file://" + correctedPath;
        }
    }

    public static String normalizePath(String path) {
        if (isCloudPath(path)) {
            return path;
        } else if (path.startsWith("file:/")) {
            return fixFileProtocol(path);
        } else {
            return toSparkLocalFilePath(path);
        }
    }

    private static String fixFileProtocol(String path) {
        if (path.startsWith("file:/") && !path.startsWith("file:///")) {
            return path.replaceFirst("file:/", "file:///");
        }
        return path;
    }

    public static String getTestResourcePath(String resourceRelativePath) throws URISyntaxException {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        URL resourceUrl = classLoader.getResource(resourceRelativePath);
        if (resourceUrl == null) {
            throw new IllegalArgumentException("Ressource introuvable : " + resourceRelativePath);
        }
        File file = Paths.get(resourceUrl.toURI()).toFile();
        return normalizePath(file.getAbsolutePath());
    }
}
