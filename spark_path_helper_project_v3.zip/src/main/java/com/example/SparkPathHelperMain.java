
package com.example;

import com.example.utils.SparkPathHelper;

public class SparkPathHelperMain {
    public static void main(String[] args) {
        try {
            // Exemple ressource de test
            String testPath = SparkPathHelper.resolvePath("data/input");
            System.out.println("Ressource test: " + testPath);
        } catch (Exception e) {
            System.out.println("Ressource test non trouvée (normal si absente): " + e.getMessage());
        }

        // Chemin cloud ABFS
        String abfsPath = SparkPathHelper.resolvePath("abfs://container@account.dfs.core.windows.net/dir/file.csv");
        System.out.println("ABFS: " + abfsPath);

        // Chemin cloud WASBS
        String wasbsPath = SparkPathHelper.resolvePath("wasbs://container@account.blob.core.windows.net/dir/file.csv");
        System.out.println("WASBS: " + wasbsPath);

        // Chemin cloud S3
        String s3Path = SparkPathHelper.resolvePath("s3a://bucket/dir/file.csv");
        System.out.println("S3: " + s3Path);

        // Chemin local absolu Windows
        String winPath = SparkPathHelper.resolvePath("C:/data/project/input/file.csv");
        System.out.println("Windows: " + winPath);

        // Chemin local absolu Linux
        String linuxPath = SparkPathHelper.resolvePath("/data/project/input/file.csv");
        System.out.println("Linux: " + linuxPath);

        // Chemin déjà file:/ mal formé
        String fileWinPath = SparkPathHelper.resolvePath("file:/C:/data/project/input/file.csv");
        System.out.println("file:/ Windows: " + fileWinPath);
    }
}
