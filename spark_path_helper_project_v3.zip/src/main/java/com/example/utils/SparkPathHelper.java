
package com.example.utils;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

public class SparkPathHelper {

    public static String resolvePath(String pathOrResource) {
        try {
            if (isCloudPath(pathOrResource)) {
                return pathOrResource;
            } else if (isAbsoluteLocalPath(pathOrResource)) {
                return toSparkLocalFilePath(pathOrResource);
            } else if (pathOrResource.startsWith("file:/")) {
                return fixFileProtocol(pathOrResource);
            } else {
                // Sinon on considère que c'est une ressource de test (src/test/resources)
                return getTestResourcePath(pathOrResource);
            }
        } catch (Exception e) {
            throw new RuntimeException("Erreur lors de la résolution du chemin: " + pathOrResource, e);
        }
    }

    private static boolean isCloudPath(String path) {
        String lowerPath = path.toLowerCase();
        return lowerPath.startsWith("abfs://") ||
               lowerPath.startsWith("wasbs://") ||
               lowerPath.startsWith("adl://") ||
               lowerPath.startsWith("s3://") ||
               lowerPath.startsWith("s3a://") ||
               lowerPath.startsWith("https://");
    }

    private static boolean isAbsoluteLocalPath(String path) {
        return path.startsWith("/") || path.matches("^[A-Za-z]:[/\\].*");
    }

    private static String toSparkLocalFilePath(String absolutePath) {
        String correctedPath = absolutePath.replace("\\", "/").replace("\", "/");
        if (correctedPath.startsWith("/")) {
            return "file://" + correctedPath;
        } else if (correctedPath.matches("^[A-Za-z]:/.*")) {
            return "file:///" + correctedPath;
        } else {
            return "file://" + correctedPath;
        }
    }

    private static String fixFileProtocol(String path) {
        if (path.startsWith("file:/") && !path.startsWith("file:///")) {
            return path.replaceFirst("file:/", "file:///");
        }
        return path;
    }

    private static String getTestResourcePath(String resourceRelativePath) throws URISyntaxException {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        URL resourceUrl = classLoader.getResource(resourceRelativePath);
        if (resourceUrl == null) {
            throw new IllegalArgumentException("Ressource introuvable : " + resourceRelativePath);
        }
        File file = Paths.get(resourceUrl.toURI()).toFile();
        return toSparkLocalFilePath(file.getAbsolutePath());
    }
}
