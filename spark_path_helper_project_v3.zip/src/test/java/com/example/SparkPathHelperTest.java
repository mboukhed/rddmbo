
package com.example;

import com.example.utils.SparkPathHelper;

public class SparkPathHelperTest {
    public static void main(String[] args) {
        System.out.println("=== Test isCloudPath ===");
        assert SparkPathHelper.isCloudPath("abfs://mycontainer/mydir");
        assert SparkPathHelper.isCloudPath("wasbs://mycontainer/mydir");
        assert SparkPathHelper.isCloudPath("adl://myaccount/mydir");
        assert SparkPathHelper.isCloudPath("s3://bucket/key");
        assert SparkPathHelper.isCloudPath("s3a://bucket/key");
        assert SparkPathHelper.isCloudPath("https://mystorage.blob.core.windows.net/container/dir");

        System.out.println("Tous les tests isCloudPath sont passés.");
    }
}
