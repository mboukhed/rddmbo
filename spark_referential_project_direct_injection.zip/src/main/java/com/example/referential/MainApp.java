package com.example.referential;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.Person;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public class MainApp {
    public static void main(String[] args) {
        SparkConf conf = new SparkConf().setAppName("ReferentialApp").setMaster("local[*]");
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();
        JavaSparkContext jsc = new JavaSparkContext(spark.sparkContext());

        
        System.out.println("*************************************");
        System.out.println("*   SPRING + SPARK REF INJECTOR    *");
        System.out.println("*        Initialisation OK         *");
        System.out.println("*************************************");

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.registerBean(SparkSession.class, () -> spark);
        context.scan("com.example.referential");
        context.refresh();

        ReferentialLoader loader = context.getBean(ReferentialLoader.class);
        List<Person> persons = loader.loadList(Person.class);

        persons.forEach(p -> System.out.println(p.getName() + ", " + p.getAge()));
    }
}