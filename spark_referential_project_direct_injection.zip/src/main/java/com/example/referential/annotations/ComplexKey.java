package com.example.referential.annotations;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface ComplexKey {
    Class<?> value(); // Classe représentant la clé complexe
}