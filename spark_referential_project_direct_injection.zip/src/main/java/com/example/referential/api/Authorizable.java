package com.example.referential.api;

public interface Authorizable {
    boolean authorize();
}