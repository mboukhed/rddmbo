package com.example.referential.models;

import com.example.referential.annotations.ComplexKey;
import com.example.referential.annotations.ReferentialMapping;
import org.springframework.stereotype.Component;
import org.springframework.beans.factory.annotation.Qualifier;

@Component
@Qualifier("personComplexReferential")
@ReferentialMapping(
    path = "src/main/resources/persons.csv",
    format = "csv",
    broadcast = true
)
@ComplexKey(PersonComplexKey.class)
public class PersonComplex {
    private String id;
    private String name;
    private int age;

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
}