package com.example.referential.models;

import com.example.referential.annotations.ReferentialMapping;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import org.apache.spark.broadcast.Broadcast;

@Component
@Qualifier("qualifiedPersonComplexReferential")
@ReferentialMapping(
    path = "src/main/resources/persons.csv",
    format = "csv",
    beanName = "qualifiedPersonComplexReferential",
    broadcast = true
)
public class QualifiedPersonComplexReferential {
    public List<PersonComplex> list;
    public Map<PersonComplexKey, PersonComplex> map;
    public Broadcast<List<PersonComplex>> broadcastList;
    public Broadcast<Map<PersonComplexKey, PersonComplex>> broadcastMap;
}