package com.example.referential.models;

import com.example.referential.annotations.ReferentialMapping;
import com.example.referential.annotations.Key;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("qualifiedPersonReferential")
@ReferentialMapping(
    path = "src/main/resources/persons.csv",
    format = "csv",
    beanName = "qualifiedPersonReferential",
    broadcast = true
)
@Key("id")
public class QualifiedPersonReferential {
    public java.util.List<com.example.referential.models.Person> list;
    public java.util.Map<String, com.example.referential.models.Person> map;
    public org.apache.spark.broadcast.Broadcast<java.util.List<com.example.referential.models.Person>> broadcastList;
    public org.apache.spark.broadcast.Broadcast<java.util.Map<String, com.example.referential.models.Person>> broadcastMap;
}