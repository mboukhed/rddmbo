package com.example.referential;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.Person;
import com.example.referential.models.PersonKey;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.*;

import java.util.Map;
import java.util.stream.Collectors;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class LazyReferentialComplexKeyTest {

    private SparkSession spark;
    private ReferentialLoader loader;
    private boolean authorized = false;

    @BeforeAll
    void setup() {
        SparkConf conf = new SparkConf().setAppName("LazyMapTest").setMaster("local[*]");
        spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
    }

    private boolean authorize() {
        // Logique d'autorisation simulée
        return authorized;
    }

    @Test
    void testLazyInjectionMapIfAuthorized() {
        authorized = true;

        if (authorize()) {
            Map<PersonKey, Person> map = loader.loadMap(Person.class, PersonKey.class);

            // Filtrage sur les personnes de plus de 30 ans
            Map<PersonKey, Person> filtered = map.entrySet().stream()
                .filter(e -> e.getValue().getAge() > 30)
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

            Assertions.assertEquals(1, filtered.size());
        }
    }
}