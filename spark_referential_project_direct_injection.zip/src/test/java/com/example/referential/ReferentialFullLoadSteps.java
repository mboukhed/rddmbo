package com.example.referential.cucumber;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.PersonFull;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReferentialFullLoadSteps {
    private ReferentialLoader loader;
    private List<PersonFull> fullList;

    @Given("le référentiel PersonFull est chargé sans filtre ni requête")
    public void chargerTout() {
        SparkConf conf = new SparkConf().setAppName("FullLoadCucumber").setMaster("local[*]");
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
        fullList = loader.loadList(PersonFull.class);
    }

    @Then("le référentiel contient toutes les personnes")
    public void verifierChargementTotal() {
        assertEquals(2, fullList.size());
    }
}