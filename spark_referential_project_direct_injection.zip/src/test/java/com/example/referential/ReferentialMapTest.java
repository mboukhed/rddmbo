package com.example.referential;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.Person;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.junit.jupiter.api.*;

import java.util.Map;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ReferentialMapTest {

    private SparkSession spark;
    private ReferentialLoader loader;

    @BeforeAll
    void setup() {
        SparkConf conf = new SparkConf().setAppName("MapTestApp").setMaster("local[*]");
        spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
    }

    @Test
    void testLoadMap() {
        Map<String, Person> map = loader.loadMap(Person.class, String.class);
        Assertions.assertEquals(2, map.size());
        Assertions.assertTrue(map.containsKey("1"));
        Assertions.assertEquals("Jean", map.get("1").getName());
    }
}