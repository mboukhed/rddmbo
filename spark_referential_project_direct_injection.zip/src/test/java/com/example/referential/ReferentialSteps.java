package com.example.referential.cucumber;

import com.example.referential.core.ReferentialLoader;
import com.example.referential.models.Person;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ReferentialSteps {
    private ReferentialLoader loader;
    private List<Person> result;

    @Given("le référentiel Person est chargé")
    public void leReferentielPersonEstCharge() {
        SparkConf conf = new SparkConf().setAppName("CucumberApp").setMaster("local[*]");
        SparkSession spark = SparkSession.builder().config(conf).getOrCreate();
        loader = new ReferentialLoader(spark);
    }

    @Then("il contient {int} personnes")
    public void ilContientPersonnes(int count) {
        result = loader.loadList(Person.class);
        assertEquals(count, result.size());
    }
}