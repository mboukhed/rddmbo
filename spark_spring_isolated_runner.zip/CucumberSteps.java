import io.cucumber.java.en.*;
import org.apache.spark.sql.*;

import static org.junit.jupiter.api.Assertions.*;

public class CucumberSteps {

    @Given("I run the spring pipeline")
    public void iRunThePipeline() throws Exception {
        IsolatedMainRunner.runMain("Launcher", new String[]{});
    }

    @Then("The output parquet should have {int} rows")
    public void theOutputParquetShouldHaveNRows(int expectedCount) {
        SparkSession spark = SparkSession.builder()
                .appName("TestVerifier")
                .master("local[*]")
                .config("spark.ui.enabled", "false")
                .getOrCreate();

        Dataset<Row> df = spark.read().parquet("target/output/mydata.parquet");
        long count = df.count();
        spark.stop();
        assertEquals(expectedCount, count);
    }
}