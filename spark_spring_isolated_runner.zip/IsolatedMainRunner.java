import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

public class IsolatedMainRunner {
    public static void runMain(String className, String[] args) throws Exception {
        File classesDir = new File("target/classes");
        URLClassLoader loader = new URLClassLoader(new URL[]{classesDir.toURI().toURL()}, null);

        Class<?> mainClass = loader.loadClass(className);
        Method mainMethod = mainClass.getMethod("main", String[].class);
        mainMethod.invoke(null, (Object) args);

        loader.close();
        System.gc();
        Thread.sleep(300);
    }
}