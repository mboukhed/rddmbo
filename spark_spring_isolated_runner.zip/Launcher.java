import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.apache.spark.sql.*;

public class Launcher {
    public static void main(String[] args) throws Exception {
        ConfigurableApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        SparkSession spark = context.getBean(SparkSession.class);

        Dataset<Row> df = spark.createDataFrame(
            java.util.Arrays.asList(
                RowFactory.create("Alice", 30),
                RowFactory.create("Bob", 40)
            ),
            new StructType()
                .add("name", "string")
                .add("age", "integer")
        );

        df.write().mode("overwrite").parquet("target/output/mydata.parquet");

        spark.stop();
        context.close();
    }
}