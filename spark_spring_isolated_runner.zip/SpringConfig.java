import org.apache.spark.sql.SparkSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {

    @Bean
    public SparkSession sparkSession() {
        return SparkSession.builder()
                .appName("SpringSparkJob")
                .master("local[*]")
                .config("spark.ui.enabled", "false")
                .getOrCreate();
    }
}