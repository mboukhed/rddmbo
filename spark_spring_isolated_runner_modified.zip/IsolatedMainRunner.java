import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IsolatedMainRunner {
    public static void main(String[] args) throws Exception {
        String classpath = System.getProperty("java.class.path");

        List<String> command = new ArrayList<>();
        command.add(System.getProperty("java.home") + File.separator + "bin" + File.separator + "java");
        command.add("-cp");
        command.add(classpath);
        command.add("com.sgci.datalab.fixedincome.runner.Launcher"); // ← ton vrai main
        command.addAll(Arrays.asList(args));

        ProcessBuilder pb = new ProcessBuilder(command);
        pb.inheritIO();
        Process process = pb.start();
        int exitCode = process.waitFor();
        System.exit(exitCode);
    }
}