
package com.example;

import com.example.config.AppArguments;
import com.example.config.MainContext;
import com.example.util.ContextProvider;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
        ctx.registerBean(AppArguments.class, () -> new AppArguments(args));
        ctx.register(MainContext.class);
        ctx.refresh();
        ContextProvider.setContext(ctx);
    }
}
