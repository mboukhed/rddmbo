
package com.example.config;

import java.util.*;

public class AppArguments {
    private final Map<String, String> params;

    public AppArguments(String[] args) {
        this.params = new HashMap<>();
        for (String arg : args) {
            if (arg.startsWith("--")) {
                String[] split = arg.substring(2).split("=", 2);
                if (split.length == 2) {
                    params.put(split[0], split[1]);
                }
            }
        }
    }

    public String get(String key) {
        return params.get(key);
    }

    public String getOrDefault(String key, String defaultVal) {
        return params.getOrDefault(key, defaultVal);
    }
}
