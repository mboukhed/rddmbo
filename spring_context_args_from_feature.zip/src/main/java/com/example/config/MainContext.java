
package com.example.config;

import org.apache.spark.sql.SparkSession;
import org.springframework.context.annotation.*;

@Configuration
public class MainContext {

    private final AppArguments args;

    public MainContext(AppArguments args) {
        this.args = args;
    }

    @Bean
    public SparkSession sparkSession() {
        return SparkSession.builder()
                .appName("InjectedSparkApp")
                .master(args.getOrDefault("master", "local[*]"))
                .getOrCreate();
    }

    @Bean
    public String inputPath() {
        return args.get("input");
    }
}
