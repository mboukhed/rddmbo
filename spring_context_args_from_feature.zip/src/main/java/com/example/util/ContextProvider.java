
package com.example.util;

import org.springframework.context.ConfigurableApplicationContext;

public class ContextProvider {
    private static ConfigurableApplicationContext context;

    public static void setContext(ConfigurableApplicationContext ctx) {
        context = ctx;
    }

    public static ContextProvider authoride() {
        return new ContextProvider();
    }

    public <T> T get(Class<T> clazz) {
        return context.getBean(clazz);
    }

    public <T> T getBean(String name, Class<T> clazz) {
        return context.getBean(name, clazz);
    }

    public ConfigurableApplicationContext raw() {
        return context;
    }
}
