
package com.example.steps;

import com.example.MainApp;
import com.example.util.ContextProvider;
import io.cucumber.java.en.*;

import static org.junit.jupiter.api.Assertions.*;

public class ParamSteps {

    private String[] args;

    @Given("I run the application with parameters {string}")
    public void i_run_with_args(String argString) {
        args = argString.split(" ");
        MainApp.main(args);
    }

    @Then("the inputPath bean should be {string}")
    public void verify_input_path(String expected) {
        String input = ContextProvider.authoride().getBean("inputPath", String.class);
        assertEquals(expected, input);
    }
}
