package com.example.bean;

import com.example.condition.ProfilesAndCondition;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

@Conditional(ProfilesAndCondition.class)
@Component
public class MonBeanConditionnel {
    public MonBeanConditionnel() {
        System.out.println("Bean conditionnel activé !");
    }
}
