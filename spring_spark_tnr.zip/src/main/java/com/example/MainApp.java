
package com.example;

import com.example.config.AppConfig;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {

    private static ConfigurableApplicationContext context;

    public static void main(String[] args) {
        context = new AnnotationConfigApplicationContext(AppConfig.class);
        SparkSession spark = context.getBean(SparkSession.class);

        Dataset<Row> df = spark.read().option("header", "true")
                .csv("src/test/resources/data/input.csv");
        df.groupBy("category").sum("amount").show();
    }

    public static ConfigurableApplicationContext getContext() {
        return context;
    }
}
