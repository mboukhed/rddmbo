
package com.example.steps;

import com.example.MainApp;
import io.cucumber.java.en.*;
import org.apache.spark.sql.*;
import static org.junit.jupiter.api.Assertions.*;

public class SparkSteps {

    private Dataset<Row> output;

    @Given("I run the application main")
    public void run_main() {
        MainApp.main(new String[]{});
    }

    @Then("I reuse the SparkSession and check row count is {int}")
    public void reuse_spark_and_check(int expectedCount) {
        SparkSession spark = MainApp.getContext().getBean(SparkSession.class);
        Dataset<Row> df = spark.read().option("header", "true")
                .csv("src/test/resources/data/input.csv");
        long count = df.count();
        assertEquals(expectedCount, count);
    }
}
