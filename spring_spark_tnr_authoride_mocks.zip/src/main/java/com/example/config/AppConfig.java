 // Écrasé avec config + JobLogger
package com.example.config;

import com.example.service.JobLogger;
import com.example.service.impl.DefaultJobLogger;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;

@Configuration
@PropertySource("classpath:application-${spring.profiles.active}.properties")
public class AppConfig {

    @Bean
    public SparkSession sparkSession(
            @Value("${spark.app.name}") String appName,
            @Value("${spark.master}") String master
    ) {
        SparkConf conf = new SparkConf().setAppName(appName).setMaster(master);
        return SparkSession.builder().config(conf).getOrCreate();
    }

    @Bean
    public JobLogger jobLogger() {
        return new DefaultJobLogger();
    }
}
