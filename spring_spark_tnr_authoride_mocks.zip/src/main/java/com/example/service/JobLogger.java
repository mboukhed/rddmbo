
package com.example.service;

public interface JobLogger {
    void log(String message);
}
