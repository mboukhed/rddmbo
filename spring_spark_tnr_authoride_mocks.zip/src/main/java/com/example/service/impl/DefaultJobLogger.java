
package com.example.service.impl;

import com.example.service.JobLogger;

public class DefaultJobLogger implements JobLogger {
    @Override
    public void log(String message) {
        System.out.println("LOG: " + message);
    }
}
