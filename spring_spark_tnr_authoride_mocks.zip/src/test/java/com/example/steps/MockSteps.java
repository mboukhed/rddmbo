
package com.example.steps;

import com.example.MainApp;
import com.example.service.JobLogger;
import com.example.util.ContextProvider;
import io.cucumber.java.en.*;

import static org.mockito.Mockito.*;

public class MockSteps {

    private JobLogger mockLogger;

    @Given("I inject a mocked JobLogger")
    public void inject_mocked_logger() {
        mockLogger = mock(JobLogger.class);
        // Replace the real JobLogger bean in the context
        ContextProvider.authoride().get(org.springframework.context.ConfigurableApplicationContext.class)
                .getBeanFactory().registerSingleton("jobLogger", mockLogger);
    }

    @Then("I verify that log was called with {string}")
    public void verify_log_called(String msg) {
        verify(mockLogger).log(msg);
    }
}
