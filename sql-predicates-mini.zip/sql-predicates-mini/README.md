# sql-predicates (mini-module)

Mini module Maven prêt à compiler (Java 17) avec :
- `SqlPredicates` utilitaire (fusion, déduplication, append WHERE, raccourcis AND/OR)
- Tests JUnit 5 : unitaires, paramétrés, dynamiques

## Build
```bash
mvn -q -DskipTests=false test
```

## Arborescence
```
src/main/java/util/sql/SqlPredicates.java
src/test/java/util/sql/SqlPredicatesTest.java
src/test/java/util/sql/SqlPredicatesParameterizedTest.java
src/test/java/util/sql/SqlPredicatesDynamicTest.java
```
