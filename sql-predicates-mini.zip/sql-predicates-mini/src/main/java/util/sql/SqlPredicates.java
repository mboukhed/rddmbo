package util.sql;

import java.util.*;

/**
 * Utility class for building and merging SQL predicates safely.
 * - Keeps parentheses even for single predicates.
 * - Handles null, blank, and "1=1" cases.
 * - Can append predicates to full SQL queries.
 * - Supports AND/OR variants, distinct merging, and deduplication.
 */
public final class SqlPredicates {

    private SqlPredicates() {}

    // ==================== CORE MERGE METHODS ====================

    /**
     * Merge two predicates using a logical operator.
     * - Keeps parentheses even for single ones.
     * - If both are empty -> returns "1=1".
     * - Ignores "1=1" inputs.
     */
    public static String mergePredicates(String left, String right, String op) {
        String operator = normalizeOperator(op);
        String a = normalizePredicate(left);
        String b = normalizePredicate(right);
        if (isBlank(a) && isBlank(b)) return "1=1";
        if (isBlank(a)) return wrap(b);
        if (isBlank(b)) return wrap(a);
        return wrap(a) + " " + operator + " " + wrap(b);
    }

    /**
     * Merge N predicates with a given operator (AND/OR).
     * - Skips null/blank/"1=1".
     * - Keeps parentheses around each part.
     */
    public static String mergePredicates(String op, String... predicates) {
        String operator = normalizeOperator(op);
        List<String> parts = new ArrayList<>();
        if (predicates != null) {
            for (String p : predicates) {
                String np = normalizePredicate(p);
                if (!isBlank(np)) parts.add(wrap(np));
            }
        }
        if (parts.isEmpty()) return "1=1";
        return String.join(" " + operator + " ", parts);
    }

    /** Merge all with AND. */
    public static String andAll(String... predicates) {
        return mergePredicates("AND", predicates);
    }

    /** Merge all with OR. */
    public static String orAll(String... predicates) {
        return mergePredicates("OR", predicates);
    }

    // ==================== DISTINCT MERGE ====================

    /**
     * Merge predicates while removing duplicates.
     * - Duplicates detected via canonical lowercase version without outer parentheses.
     * - Keeps first original occurrence.
     * - Returns "1=1" if all are blank.
     */
    public static String mergeDistinct(String op, String... predicates) {
        String operator = normalizeOperator(op);
        if (predicates == null || predicates.length == 0) return "1=1";

        LinkedHashMap<String, String> kept = new LinkedHashMap<>();
        for (String p : predicates) {
            String np = normalizePredicate(p);
            if (isBlank(np)) continue;
            String key = canonicalForDedup(np);
            kept.putIfAbsent(key, wrap(np));
        }
        if (kept.isEmpty()) return "1=1";
        return String.join(" " + operator + " ", kept.values());
    }

    // ==================== APPEND TO FULL SQL ====================

    /**
     * Append a predicate into a full SQL statement, adding "WHERE" or "AND/OR" as needed.
     * - Preserves semicolon if present.
     * - Ignores null/blank/"1=1" predicate.
     */
    public static String appendWhere(String existingSql, String newPredicate, String op) {
        String np = normalizePredicate(newPredicate);
        if (isBlank(np)) return existingSql;

        String sql = existingSql == null ? "" : existingSql;
        String trimmed = sql.trim();
        boolean hadSemicolon = trimmed.endsWith(";");
        String base = hadSemicolon ? trimmed.substring(0, trimmed.length() - 1).trim() : trimmed;

        String operator = normalizeOperator(op);
        boolean hasWhere = base.toLowerCase(Locale.ROOT).matches(".*\\bwhere\\b.*");

        StringBuilder sb = new StringBuilder(base);
        if (isBlank(base)) {
            sb.append("WHERE ").append(wrap(np));
        } else if (hasWhere) {
            sb.append(" ").append(operator).append(" ").append(wrap(np));
        } else {
            sb.append(" WHERE ").append(wrap(np));
        }

        if (hadSemicolon) sb.append(";");
        return sb.toString();
    }

    // ==================== CONVENIENCE METHODS ====================

    /** Append with AND. */
    public static String appendWhereAnd(String existingSql, String predicate) {
        return appendWhere(existingSql, predicate, "AND");
    }

    /** Append with OR. */
    public static String appendWhereOr(String existingSql, String predicate) {
        return appendWhere(existingSql, predicate, "OR");
    }

    /** Append multiple predicates with AND. */
    public static String appendWhereAnd(String existingSql, String... predicates) {
        String merged = mergePredicates("AND", predicates);
        return appendWhere(existingSql, merged, "AND");
    }

    /** Append multiple predicates with OR. */
    public static String appendWhereOr(String existingSql, String... predicates) {
        String merged = mergePredicates("OR", predicates);
        return appendWhere(existingSql, merged, "OR");
    }

    /** Append distinct predicates with AND. */
    public static String appendWhereAndDistinct(String existingSql, String... predicates) {
        String merged = mergeDistinct("AND", predicates);
        return appendWhere(existingSql, merged, "AND");
    }

    /** Append distinct predicates with OR. */
    public static String appendWhereOrDistinct(String existingSql, String... predicates) {
        String merged = mergeDistinct("OR", predicates);
        return appendWhere(existingSql, merged, "OR");
    }

    // ==================== INTERNAL HELPERS ====================

    private static String normalizeOperator(String op) {
        String o = (op == null ? "" : op.trim().toUpperCase(Locale.ROOT));
        if ("OR".equals(o)) return "OR";
        return "AND";
    }

    private static String normalizePredicate(String p) {
        if (p == null) return null;
        String t = p.trim();
        if (t.isEmpty()) return null;
        String flat = t.replaceAll("\\s+", "").toUpperCase(Locale.ROOT);
        if ("1=1".equals(flat)) return null;
        return t;
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static String wrap(String s) {
        String t = s.trim();
        if (isAlreadyWrapped(t)) return t;
        return "(" + t + ")";
    }

    private static boolean isAlreadyWrapped(String s) {
        if (!s.startsWith("(") || !s.endsWith(")")) return false;
        int depth = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '(') depth++;
            else if (c == ')') {
                depth--;
                if (depth == 0 && i != s.length() - 1) return false;
            }
            if (depth < 0) return false;
        }
        return depth == 0;
    }

    private static String canonicalForDedup(String s) {
        String t = stripOuterParens(s.trim());
        t = t.replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
        return t;
    }

    private static String stripOuterParens(String s) {
        String t = s;
        while (isAlreadyWrapped(t)) {
            t = t.substring(1, t.length() - 1).trim();
        }
        return t;
    }

    // --- Optional main for local smoke testing ---
    public static void main(String[] args) {
        System.out.println(mergePredicates("a=1", "b=2", "AND"));
    }
}
