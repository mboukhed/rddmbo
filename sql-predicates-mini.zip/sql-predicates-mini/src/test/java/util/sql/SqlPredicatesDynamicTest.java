package util.sql;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

import java.util.*;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class SqlPredicatesDynamicTest {

    private record Case(String name, String actual, String expected) { }

    @TestFactory
    Stream<DynamicTest> dynamic_mergePredicates_binary() {
        List<Object[]> cases = List.of(
            new Object[]{"AND basic", "a=1", "b=2", "AND", "(a=1) AND (b=2)"},
            new Object[]{"OR basic", "a=1", "b=2", "OR", "(a=1) OR (b=2)"},
            new Object[]{"Left only", "a=1", null, "AND", "(a=1)"},
            new Object[]{"Right only", null, "b=2", "AND", "(b=2)"},
            new Object[]{"Both blank -> true", " ", " ", "AND", "1=1"},
            new Object[]{"Ignore 1=1 (right)", "(x IS NOT NULL)", " 1 = 1 ", "AND", "(x IS NOT NULL)"},
            new Object[]{"Ignore 1=1 (left)", " 1 = 1 ", "(x IS NOT NULL)", "AND", "(x IS NOT NULL)"},
            new Object[]{"Invalid op -> AND", "(a=1)", "(b=2)", "X", "(a=1) AND (b=2)"},
            new Object[]{"Keep nested parens", "a=1", "( (b=2) OR (c=3) )", "AND", "(a=1) AND (( (b=2) OR (c=3) ))"}
        );

        return cases.stream().map(arr -> DynamicTest.dynamicTest(arr[0].toString(), () -> {
            String actual = SqlPredicates.mergePredicates((String) arr[1], (String) arr[2], (String) arr[3]);
            assertEquals(arr[4], actual);
        }));
    }

    @TestFactory
    Stream<DynamicTest> dynamic_mergePredicates_varargs_permutations() {
        String[] base = {"a=1", "b>2", "c like 'X%'"};
        String[] noise = {null, " ", "1=1"};
        String[] ops = {"AND", "OR"};

        List<Case> tests = new ArrayList<>();
        for (String op : ops) {
            for (String p1 : base) {
                for (String p2 : base) {
                    if (Objects.equals(p1, p2)) continue;
                    String expected = "(" + p1 + ") " + op + " (" + p2 + ")";
                    String[] input = new String[]{p1, random(noise), p2, random(noise)};
                    String actual = SqlPredicates.mergePredicates(op, input);
                    tests.add(new Case("varargs " + op + " :: " + Arrays.toString(input), actual, expected));
                }
            }
        }
        return tests.stream().map(c ->
            DynamicTest.dynamicTest(c.name(), () -> assertEquals(c.expected(), c.actual()))
        );
    }

    @TestFactory
    Stream<DynamicTest> dynamic_mergeDistinct_noiseAndDupes() {
        List<String[]> inputs = List.of(
            new String[]{"a=1", "(a=1)", "A = 1", "b=2", " ( b = 2 ) "},
            new String[]{"x is not null", "(x IS NOT NULL)", "y > 10"},
            new String[]{null, " ", "1=1"}
        );
        String[] ops = {"AND", "OR"};

        return inputs.stream().flatMap(arr ->
            Arrays.stream(ops).map(op -> DynamicTest.dynamicTest(
                "distinct " + op + " :: " + Arrays.toString(arr),
                () -> {
                    String out = SqlPredicates.mergeDistinct(op, arr);
                    if (Arrays.equals(arr, inputs.get(2))) {
                        assertEquals("1=1", out);
                    } else if ("AND".equals(op)) {
                        if (Arrays.equals(arr, inputs.get(0))) {
                            assertEquals("(a=1) AND (b=2)", out);
                        } else {
                            fail("Unexpected AND dataset");
                        }
                    } else {
                        if (Arrays.equals(arr, inputs.get(1))) {
                            assertEquals("(x is not null) OR (y > 10)", out);
                        } else {
                            fail("Unexpected OR dataset");
                        }
                    }
                }
            ))
        );
    }

    @TestFactory
    Stream<DynamicTest> dynamic_appendWhere_edgeCases() {
        List<Object[]> data = List.of(
            new Object[]{"No WHERE -> insert", "SELECT * FROM T", "a=1", "AND", "SELECT * FROM T WHERE (a=1)"},
            new Object[]{"Existing WHERE -> AND", "SELECT * FROM T WHERE (a=1)", "b=2", "AND", "SELECT * FROM T WHERE (a=1) AND (b=2)"},
            new Object[]{"Existing WHERE -> OR", "SELECT * FROM T WHERE (a=1)", "b=2", "OR", "SELECT * FROM T WHERE (a=1) OR (b=2)"},
            new Object[]{"Semicolon preserved", "SELECT * FROM T WHERE (a=1);", "b=2", "AND", "SELECT * FROM T WHERE (a=1) AND (b=2);"},
            new Object[]{"Ignore 1=1", "SELECT * FROM T WHERE (a=1);", " 1 = 1 ", "AND", "SELECT * FROM T WHERE (a=1);"},
            new Object[]{"Empty SQL -> start WHERE", "", "x > 0", "AND", "WHERE (x > 0)"}
        );

        return data.stream().map(arr -> DynamicTest.dynamicTest(arr[0].toString(), () -> {
            String out = SqlPredicates.appendWhere((String) arr[1], (String) arr[2], (String) arr[3]);
            assertEquals(arr[4], out);
        }));
    }

    @TestFactory
    Stream<DynamicTest> dynamic_convenience_appenders() {
        List<Case> cases = new ArrayList<>();

        String out1 = SqlPredicates.appendWhereAnd("SELECT * FROM T;", "a=1", "b>2", null, "1=1");
        cases.add(new Case("appendWhereAnd multi", out1, "SELECT * FROM T WHERE (a=1) AND (b>2);"));

        String out2 = SqlPredicates.appendWhereOr("SELECT * FROM T WHERE (a=1)", "b=2");
        cases.add(new Case("appendWhereOr single", out2, "SELECT * FROM T WHERE (a=1) OR (b=2)"));

        String out3 = SqlPredicates.appendWhereAndDistinct("SELECT * FROM T", "a=1", "A=1", "b>2");
        cases.add(new Case("appendWhereAndDistinct", out3, "SELECT * FROM T WHERE (a=1) AND (b>2)"));

        String out4 = SqlPredicates.appendWhereOrDistinct("SELECT * FROM T WHERE (c=3)",
                "x is not null", "(x IS NOT NULL)", "y>0");
        cases.add(new Case("appendWhereOrDistinct", out4, "SELECT * FROM T WHERE (c=3) OR (x is not null) OR (y>0)"));

        return cases.stream().map(c ->
            DynamicTest.dynamicTest(c.name(), () -> assertEquals(c.expected(), c.actual()))
        );
    }

    private static <T> T random(T[] arr) {
        return arr[new Random(42).nextInt(arr.length)];
    }
}
