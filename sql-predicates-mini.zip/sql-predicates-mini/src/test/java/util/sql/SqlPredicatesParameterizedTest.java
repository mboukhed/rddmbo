package util.sql;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.*;
import org.junit.jupiter.api.DisplayName;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("SqlPredicates – Parameterized Tests")
class SqlPredicatesParameterizedTest {

    @ParameterizedTest(name = "[{index}] left=\"{0}\" right=\"{1}\" op={2} -> {3}")
    @CsvSource(value = {
            "a=1, b=2, AND, (a=1) AND (b=2)",
            "a=1, b=2, OR, (a=1) OR (b=2)",
            "a=1, , AND, (a=1)",
            " , b=2, AND, (b=2)",
            "  ,  , AND, 1=1",
            "(x IS NOT NULL), 1 = 1 , AND, (x IS NOT NULL)",
            "1=1, (x IS NOT NULL), AND, (x IS NOT NULL)",
            "(a=1), (b=2), X, (a=1) AND (b=2)"
    }, nullValues = {"null"})
    @DisplayName("mergePredicates(left,right,op)")
    void testMergePredicatesBinary(String left, String right, String op, String expected) {
        assertEquals(expected, SqlPredicates.mergePredicates(left, right, op));
    }

    @ParameterizedTest(name = "[{index}] op={0} -> {1}")
    @MethodSource("mergeVarArgsCases")
    @DisplayName("mergePredicates(op, varargs)")
    void testMergePredicatesVarargs(String op, String[] parts, String expected) {
        assertEquals(expected, SqlPredicates.mergePredicates(op, parts));
    }

    static Stream<Arguments> mergeVarArgsCases() {
        return Stream.of(
                Arguments.of("AND", new String[]{"a=1", "b=2"}, "(a=1) AND (b=2)"),
                Arguments.of("AND", new String[]{"a=1", null, " ", "1=1", "b>2"}, "(a=1) AND (b>2)"),
                Arguments.of("AND", new String[]{}, "1=1"),
                Arguments.of("AND", new String[]{null, " ", "1=1"}, "1=1"),
                Arguments.of("OR", new String[]{"a=1", "b=2"}, "(a=1) OR (b=2)"),
                Arguments.of("OR", new String[]{"1=1", "(c like 'X%')"}, "(c like 'X%')")
        );
    }

    @ParameterizedTest(name = "[{index}] distinct {0} -> {2}")
    @MethodSource("mergeDistinctCases")
    @DisplayName("mergeDistinct(op, varargs)")
    void testMergeDistinct(String op, String[] parts, String expected) {
        assertEquals(expected, SqlPredicates.mergeDistinct(op, parts));
    }

    static Stream<Arguments> mergeDistinctCases() {
        return Stream.of(
                Arguments.of("AND", new String[]{"a=1", "(a=1)", "A = 1", "b=2", " ( b = 2 ) "}, "(a=1) AND (b=2)"),
                Arguments.of("OR",  new String[]{"x is not null", "(x IS NOT NULL)", "y > 10"}, "(x is not null) OR (y > 10)"),
                Arguments.of("AND", new String[]{null, " ", "1=1"}, "1=1")
        );
    }

    @ParameterizedTest(name = "[{index}] sql=\"{0}\" + [{1}] op={2} -> {3}")
    @MethodSource("appendWhereCases")
    @DisplayName("appendWhere(sql, predicate, op)")
    void testAppendWhere(String sql, String predicate, String op, String expected) {
        assertEquals(expected, SqlPredicates.appendWhere(sql, predicate, op));
    }

    static Stream<Arguments> appendWhereCases() {
        return Stream.of(
                Arguments.of("SELECT * FROM T", "a=1", "AND", "SELECT * FROM T WHERE (a=1)"),
                Arguments.of("SELECT * FROM T WHERE (a=1)", "b=2", "AND", "SELECT * FROM T WHERE (a=1) AND (b=2)"),
                Arguments.of("SELECT * FROM T WHERE (a=1);", " 1 = 1 ", "AND", "SELECT * FROM T WHERE (a=1);"),
                Arguments.of("", "x > 0", "AND", "WHERE (x > 0)"),
                Arguments.of("SELECT 1", null, "AND", "SELECT 1"),
                Arguments.of("SELECT * FROM T", "b=2", "OR", "SELECT * FROM T WHERE (b=2)"),
                Arguments.of("SELECT * FROM T WHERE (a=1)", "b=2", "OR", "SELECT * FROM T WHERE (a=1) OR (b=2)")
        );
    }

    @ParameterizedTest(name = "[{index}] appendWhereAnd -> {2}")
    @MethodSource("appendWhereAndCases")
    @DisplayName("appendWhereAnd(sql, ...)")
    void testAppendWhereAnd(String sql, String[] predicates, String expected) {
        assertEquals(expected, SqlPredicates.appendWhereAnd(sql, predicates));
    }

    static Stream<Arguments> appendWhereAndCases() {
        return Stream.of(
                Arguments.of("SELECT * FROM T", new String[]{"a=1"}, "SELECT * FROM T WHERE (a=1)"),
                Arguments.of("SELECT * FROM T;", new String[]{"a=1", "b>2", null, "1=1"}, "SELECT * FROM T WHERE (a=1) AND (b>2);")
        );
    }

    @ParameterizedTest(name = "[{index}] appendWhereOr -> {2}")
    @MethodSource("appendWhereOrCases")
    @DisplayName("appendWhereOr(sql, ...)")
    void testAppendWhereOr(String sql, String[] predicates, String expected) {
        assertEquals(expected, SqlPredicates.appendWhereOr(sql, predicates));
    }

    static Stream<Arguments> appendWhereOrCases() {
        return Stream.of(
                Arguments.of("SELECT * FROM T WHERE (a=1)", new String[]{"b=2"}, "SELECT * FROM T WHERE (a=1) OR (b=2)"),
                Arguments.of("SELECT * FROM T", new String[]{"a=1", "b>2"}, "SELECT * FROM T WHERE (a=1) OR (b>2)")
        );
    }

    @ParameterizedTest(name = "[{index}] appendWhereAndDistinct -> {2}")
    @MethodSource("appendWhereAndDistinctCases")
    @DisplayName("appendWhereAndDistinct(sql, ...)")
    void testAppendWhereAndDistinct(String sql, String[] predicates, String expected) {
        assertEquals(expected, SqlPredicates.appendWhereAndDistinct(sql, predicates));
    }

    static Stream<Arguments> appendWhereAndDistinctCases() {
        return Stream.of(
                Arguments.of("SELECT * FROM T", new String[]{"a=1", "A=1", "b>2"}, "SELECT * FROM T WHERE (a=1) AND (b>2)")
        );
    }

    @ParameterizedTest(name = "[{index}] appendWhereOrDistinct -> {2}")
    @MethodSource("appendWhereOrDistinctCases")
    @DisplayName("appendWhereOrDistinct(sql, ...)")
    void testAppendWhereOrDistinct(String sql, String[] predicates, String expected) {
        assertEquals(expected, SqlPredicates.appendWhereOrDistinct(sql, predicates));
    }

    static Stream<Arguments> appendWhereOrDistinctCases() {
        return Stream.of(
                Arguments.of("SELECT * FROM T WHERE (c=3)",
                        new String[]{"x is not null", "(x IS NOT NULL)", "y>0"},
                        "SELECT * FROM T WHERE (c=3) OR (x is not null) OR (y>0)")
        );
    }
}
