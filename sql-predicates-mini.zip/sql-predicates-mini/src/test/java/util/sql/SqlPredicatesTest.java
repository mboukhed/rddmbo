package util.sql;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SqlPredicatesTest {

    @Test
    void merge_twoNulls_returnsTruePredicate() {
        assertEquals("1=1", SqlPredicates.mergePredicates(null, null, "AND"));
    }

    @Test
    void merge_leftNull_rightNonEmpty_wrapsRightOnly() {
        assertEquals("(b=2)", SqlPredicates.mergePredicates(null, "b=2", "AND"));
    }

    @Test
    void merge_leftNonEmpty_rightNull_wrapsLeftOnly() {
        assertEquals("(a=1)", SqlPredicates.mergePredicates("a=1", null, "AND"));
    }

    @Test
    void merge_bothNonEmpty_andOperator_keepsParens() {
        assertEquals("(a=1) AND (b=2)", SqlPredicates.mergePredicates("a=1", "b=2", "AND"));
    }

    @Test
    void merge_ignoresOneEqualsOne_whenOtherExists() {
        assertEquals("(x IS NOT NULL)", SqlPredicates.mergePredicates("(x IS NOT NULL)", " 1 = 1 ", "AND"));
        assertEquals("(x IS NOT NULL)", SqlPredicates.mergePredicates(" 1 = 1 ", "(x IS NOT NULL)", "AND"));
    }

    @Test
    void merge_bothBlank_likeSpaces_returnsTruePredicate() {
        assertEquals("1=1", SqlPredicates.mergePredicates("   ", "   ", "AND"));
    }

    @Test
    void merge_varargs_and_skipsNullBlankTrue() {
        String s = SqlPredicates.mergePredicates("AND", "a=1", null, " ", "1=1", "b>2");
        assertEquals("(a=1) AND (b>2)", s);
    }

    @Test
    void merge_varargs_or_operator() {
        String s = SqlPredicates.mergePredicates("OR", "a=1", "b>2");
        assertEquals("(a=1) OR (b>2)", s);
    }

    @Test
    void merge_varargs_allBlank_returnsTruePredicate() {
        assertEquals("1=1", SqlPredicates.mergePredicates("AND", null, "  ", "1=1"));
    }

    @Test
    void andAll_basic() {
        assertEquals("(a=1) AND (b=2)", SqlPredicates.andAll("a=1", "b=2"));
    }

    @Test
    void orAll_basic() {
        assertEquals("(a=1) OR (b=2)", SqlPredicates.orAll("a=1", "b=2"));
    }

    @Test
    void mergeDistinct_removesDuplicates_caseAndParensInsensitive() {
        String s = SqlPredicates.mergeDistinct("AND", "a=1", "(a=1)", "A = 1", "b=2", " ( b = 2 ) ");
        assertEquals("(a=1) AND (b=2)", s);
    }

    @Test
    void mergeDistinct_allBlank_returnsTruePredicate() {
        assertEquals("1=1", SqlPredicates.mergeDistinct("AND", null, " ", "1=1"));
    }

    @Test
    void mergeDistinct_or_operator() {
        String s = SqlPredicates.mergeDistinct("OR", "x is not null", "(x IS NOT NULL)", "y > 10");
        assertEquals("(x is not null) OR (y > 10)", s);
    }

    @Test
    void appendWhere_addsWhereIfMissing_andPreservesParens() {
        String out = SqlPredicates.appendWhere("SELECT * FROM T", "a=1", "AND");
        assertEquals("SELECT * FROM T WHERE (a=1)", out);
    }

    @Test
    void appendWhere_appendsWithAnd_whenWhereExists() {
        String out = SqlPredicates.appendWhere("SELECT * FROM T WHERE (a=1)", "b=2", "AND");
        assertEquals("SELECT * FROM T WHERE (a=1) AND (b=2)", out);
    }

    @Test
    void appendWhere_ignoresTruePredicate_keepsSemicolon() {
        String out = SqlPredicates.appendWhere("SELECT * FROM T WHERE (a=1);", " 1 = 1 ", "AND");
        assertEquals("SELECT * FROM T WHERE (a=1);", out);
    }

    @Test
    void appendWhere_handlesEmptyInputSql() {
        String out = SqlPredicates.appendWhere("", "x > 0", "AND");
        assertEquals("WHERE (x > 0)", out);
    }

    @Test
    void appendWhere_handlesNullPredicate_returnsOriginal() {
        String out = SqlPredicates.appendWhere("SELECT 1", null, "AND");
        assertEquals("SELECT 1", out);
    }

    @Test
    void appendWhereAnd_singlePredicate() {
        assertEquals("SELECT * FROM T WHERE (a=1)",
            SqlPredicates.appendWhereAnd("SELECT * FROM T", "a=1"));
    }

    @Test
    void appendWhereOr_singlePredicate() {
        assertEquals("SELECT * FROM T WHERE (a=1) OR (b=2)",
            SqlPredicates.appendWhereOr("SELECT * FROM T WHERE (a=1)", "b=2"));
    }

    @Test
    void appendWhereAnd_multiplePredicates_mergedBeforeAppend() {
        String out = SqlPredicates.appendWhereAnd("SELECT * FROM T;", "a=1", "b>2", null, "1=1");
        assertEquals("SELECT * FROM T WHERE (a=1) AND (b>2);", out);
    }

    @Test
    void appendWhereAndDistinct_deduplicatesBeforeAppend() {
        String out = SqlPredicates.appendWhereAndDistinct("SELECT * FROM T", "a=1", "A=1", "b>2");
        assertEquals("SELECT * FROM T WHERE (a=1) AND (b>2)", out);
    }

    @Test
    void appendWhereOrDistinct_deduplicatesWithOr() {
        String out = SqlPredicates.appendWhereOrDistinct("SELECT * FROM T WHERE (c=3)",
                "x is not null", "(x IS NOT NULL)", "y>0");
        assertEquals("SELECT * FROM T WHERE (c=3) OR (x is not null) OR (y>0)", out);
    }
}
