package com.example.sql;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SQLUtils {

    public static String[] extractTableAndFlatten(String sql) {
        if (sql == null || sql.trim().isEmpty()) {
            return new String[]{"tmp", "SELECT * FROM tmp"};
        }

        // Requête normalisée en une seule ligne
        String flatSql = sql.replaceAll("\s+", " ").trim();

        // Extraction de la table après FROM
        String tableName = "tmp";
        String regex = "(?i)\bfrom\b\s+([a-zA-Z0-9_\.]+)";
        Matcher matcher = Pattern.compile(regex).matcher(flatSql);

        if (matcher.find()) {
            tableName = matcher.group(1).trim();
        }

        return new String[]{tableName, flatSql};
    }

    public static void main(String[] args) {

        String[] queries = {
            "SELECT * FROM clients",
            "SELECT nom,\nmontant\nFROM ventes WHERE montant > 100",
            "SELECT 1 + 1 LIMIT 1",
            "SELECT total,\nTVA\nWHERE total > 0",
            "SELECT age GROUP BY age FROM population"
        };

        for (String query : queries) {
            String[] result = extractTableAndFlatten(query.replace("\n", "
"));
            System.out.println("===============");
            System.out.println("Original query:
" + query.replace("\n", "
"));
            System.out.println("→ Table: " + result[0]);
            System.out.println("→ SQL:   " + result[1]);
        }
    }
}