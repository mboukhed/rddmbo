package com.example.sql;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SQLUtils {

    public static String extractOrAddFromTmp(String sql) {
        if (sql == null || sql.trim().isEmpty()) return "SELECT * FROM tmp";

        Pattern fromPattern = Pattern.compile("\bfrom\b\s+([a-zA-Z0-9_\.\"`\[\]]+)",
                                              Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
        Matcher fromMatcher = fromPattern.matcher(sql);
        if (fromMatcher.find()) {
            return sql.replaceAll("\s+", " ").trim();
        }

        Pattern insertPointPattern = Pattern.compile("(?i)\b(order\s+by|group\s+by|having|limit|union|intersect|except)\b");
        Matcher insertPointMatcher = insertPointPattern.matcher(sql);

        int insertPos = insertPointMatcher.find() ? insertPointMatcher.start() : sql.length();
        String before = sql.substring(0, insertPos).trim();
        String after = sql.substring(insertPos).trim();

        return (before + " FROM tmp" + (after.isEmpty() ? "" : " " + after)).replaceAll("\s+", " ").trim();
    }
}