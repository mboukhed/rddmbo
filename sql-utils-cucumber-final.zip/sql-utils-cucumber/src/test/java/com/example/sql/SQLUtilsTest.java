package com.example.sql;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SQLUtilsTest {

    @Test
    void testWithTable() {
        assertEquals("SELECT id, name FROM users", SQLUtils.extractOrAddFromTmp("SELECT id, name FROM users"));
    }

    @Test
    void testWithoutTable() {
        assertEquals("SELECT * FROM tmp", SQLUtils.extractOrAddFromTmp("SELECT *"));
    }

    @Test
    void testWithLimit() {
        assertEquals("SELECT 1 + 1 FROM tmp LIMIT 10", SQLUtils.extractOrAddFromTmp("SELECT 1 + 1 LIMIT 10"));
    }

    @Test
    void testWithGroupBy() {
        assertEquals("SELECT age FROM tmp GROUP BY age", SQLUtils.extractOrAddFromTmp("SELECT age GROUP BY age"));
    }

    @Test
    void testAlreadyWithTmp() {
        assertEquals("SELECT * FROM tmp WHERE x = 1", SQLUtils.extractOrAddFromTmp("SELECT * FROM tmp WHERE x = 1"));
    }

    @Test
    void testWithMultilineQuery() {
        String query = "SELECT\n  "Nom du client",\n  montant\nFROM ventes\nWHERE montant > 100";
        String expected = "SELECT "Nom du client", montant FROM ventes WHERE montant > 100";
        assertEquals(expected, SQLUtils.extractOrAddFromTmp(query));
    }

    @Test
    void testMultilineWithoutFrom() {
        String query = "SELECT\n  total,\n  TVA\nWHERE total > 0";
        String expected = "SELECT total, TVA FROM tmp WHERE total > 0";
        assertEquals(expected, SQLUtils.extractOrAddFromTmp(query));
    }
}