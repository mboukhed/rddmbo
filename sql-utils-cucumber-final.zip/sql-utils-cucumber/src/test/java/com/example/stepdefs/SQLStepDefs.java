package com.example.stepdefs;

import com.example.sql.SQLUtils;
import io.cucumber.java.en.*;
import static org.junit.jupiter.api.Assertions.*;

public class SQLStepDefs {

    private String input;
    private String output;

    @Given("une requête SQL {string}")
    public void une_requête_SQL(String sql) {
        this.input = sql;
    }

    @When("je la corrige avec extractOrAddFromTmp")
    public void je_la_corrige() {
        this.output = SQLUtils.extractOrAddFromTmp(input);
    }

    @Then("elle devient {string}")
    public void elle_devient(String expected) {
        assertEquals(expected, output);
    }
}