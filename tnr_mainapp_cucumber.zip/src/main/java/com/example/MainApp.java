
package com.example;

public class MainApp {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Hello world!");
        } else {
            for (String arg : args) {
                System.out.println("Arg: " + arg);
            }
        }
    }
}
