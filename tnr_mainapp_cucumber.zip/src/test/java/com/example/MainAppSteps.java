
package com.example;

import io.cucumber.java.en.*;
import java.io.*;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class MainAppSteps {

    private String output;

    @Given("I run the MainApp with arguments {string} and {string}")
    public void i_run_main_app_with_arguments(String arg1, String arg2) throws Exception {
        PrintStream originalOut = System.out;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        System.setOut(new PrintStream(baos));

        // Appel direct de main()
        MainApp.main(new String[]{arg1, arg2});

        System.out.flush();
        System.setOut(originalOut);
        output = baos.toString();
    }

    @Then("the output should contain {string}")
    public void the_output_should_contain(String expected) {
        assertTrue(output.contains(expected), "Expected to find: " + expected);
    }
}
