#!/bin/bash
mvn -B versions:set-property \
  -Dproperty=my.version.property \
  -DnewVersion=$(mvn -q -Dexpression=my.version.property -DforceStdout help:evaluate | sed "s/-SNAPSHOT//")
