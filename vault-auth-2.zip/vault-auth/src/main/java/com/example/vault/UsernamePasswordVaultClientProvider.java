
package com.example.vault;

import com.azure.identity.UsernamePasswordCredentialBuilder;
import com.azure.core.credential.TokenCredential;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.keys.KeyClient;
import com.azure.security.keyvault.keys.KeyClientBuilder;
import com.azure.security.keyvault.certificates.CertificateClient;
import com.azure.security.keyvault.certificates.CertificateClientBuilder;
import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;
import com.azure.security.keyvault.keys.models.KeyVaultKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Component
@Profile("vault-username-password")
public class UsernamePasswordVaultClientProvider implements VaultClientProvider {

    @Value("${azure.vault.url}")
    private String vaultUrl;

    @Value("${azure.client-id}")
    private String clientId;

    @Value("${azure.username}")
    private String username;

    @Value("${azure.password}")
    private String password;

    @Value("${azure.tenant-id}")
    private String tenantId;

    private SecretClient secretClient;
    private KeyClient keyClient;
    private CertificateClient certificateClient;

    private void init() {
        TokenCredential credential = new UsernamePasswordCredentialBuilder()
            .clientId(clientId)
            .username(username)
            .password(password)
            .tenantId(tenantId)
            .build();

        secretClient = new SecretClientBuilder().vaultUrl(vaultUrl).credential(credential).buildClient();
        keyClient = new KeyClientBuilder().vaultUrl(vaultUrl).credential(credential).buildClient();
        certificateClient = new CertificateClientBuilder().vaultUrl(vaultUrl).credential(credential).buildClient();
    }

    @Override
    public String getSecret(String name) {
        if (secretClient == null) init();
        return secretClient.getSecret(name).getValue();
    }

    @Override
    public KeyVaultKey getKey(String name) {
        if (keyClient == null) init();
        return keyClient.getKey(name);
    }

    @Override
    public KeyVaultCertificateWithPolicy getCertificate(String name) {
        if (certificateClient == null) init();
        return certificateClient.getCertificate(name);
    }
}
