
package com.example.vault;

import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.security.KeyStore;

public class SSLContextFactory {

    /**
     * Crée un SSLContext à partir d'un certificat Key Vault (PFX) et d'un mot de passe
     * @param cert Certificat chargé depuis Key Vault
     * @param password Mot de passe du keystore
     * @return SSLContext prêt à être utilisé
     * @throws Exception en cas d'erreur de chargement
     */
    public static SSLContext createSSLContext(KeyVaultCertificateWithPolicy cert, String password) throws Exception {
        KeyStore keyStore = VaultCertificateUtils.toKeyStore(cert, password);

        KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
        kmf.init(keyStore, password.toCharArray());

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(kmf.getKeyManagers(), null, null);

        return sslContext;
    }
}
