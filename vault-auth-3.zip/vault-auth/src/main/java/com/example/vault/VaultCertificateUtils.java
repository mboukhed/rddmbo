
package com.example.vault;

import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.util.Base64;

public class VaultCertificateUtils {

    /**
     * Convertit un certificat PFX retourné par Key Vault en KeyStore Java
     * @param certificateWithPolicy certificat retourné par Vault
     * @param password mot de passe du certificat
     * @return KeyStore Java
     * @throws Exception si erreur de conversion
     */
    public static KeyStore toKeyStore(KeyVaultCertificateWithPolicy certificateWithPolicy, String password) throws Exception {
        byte[] pfxBytes = Base64.getDecoder().decode(certificateWithPolicy.getCer());
        KeyStore ks = KeyStore.getInstance("PKCS12");
        ks.load(new ByteArrayInputStream(pfxBytes), password.toCharArray());
        return ks;
    }

    /**
     * Permet de lire la chaîne base64 brute du certificat
     */
    public static String extractBase64(KeyVaultCertificateWithPolicy cert) {
        return Base64.getEncoder().encodeToString(cert.getCer());
    }

    /**
     * Liste les alias disponibles dans le keystore
     */
    public static void printAliases(KeyStore ks) throws Exception {
        var aliases = ks.aliases();
        while (aliases.hasMoreElements()) {
            String alias = aliases.nextElement();
            Certificate cert = ks.getCertificate(alias);
            System.out.println("Alias : " + alias + ", Cert : " + cert.toString());
        }
    }
}
