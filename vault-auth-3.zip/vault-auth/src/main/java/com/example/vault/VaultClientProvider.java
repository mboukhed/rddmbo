
package com.example.vault;

import com.azure.security.keyvault.certificates.models.KeyVaultCertificateWithPolicy;
import com.azure.security.keyvault.keys.models.KeyVaultKey;

public interface VaultClientProvider {
    String getSecret(String name);
    KeyVaultKey getKey(String name);
    KeyVaultCertificateWithPolicy getCertificate(String name);
}
