
package com.example.vault;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;

import static org.junit.jupiter.api.Assertions.*;

@SpringJUnitConfig(classes = {
    ClientSecretVaultClientProvider.class
})
@ActiveProfiles("vault-client-secret")
@EnabledIfSystemProperty(named = "test.vault.enabled", matches = "true")
public class VaultClientProviderTest {

    @Autowired
    private VaultClientProvider vaultClientProvider;

    @Test
    public void testGetSecret() {
        String secretName = System.getProperty("test.vault.secret-name", "test-secret");
        String secretValue = vaultClientProvider.getSecret(secretName);
        assertNotNull(secretValue, "Le secret ne doit pas être null");
        System.out.println("Valeur du secret '" + secretName + "' = " + secretValue);
    }
}
