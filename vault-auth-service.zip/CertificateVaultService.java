package com.example.vault;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile("certificate")
@Service
public class CertificateVaultService implements VaultService {

    @Override
    public VaultClient getAuthenticatedClient() {
        // Auth with certificate
        return new VaultClient();
    }

    @Override
    public String getSecret(String key) {
        return "secret-from-cert-auth";
    }

    @Override
    public byte[] getCertificate(String certName) {
        return new byte[0];
    }
}