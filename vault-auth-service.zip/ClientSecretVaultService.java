package com.example.vault;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile("clientsecret")
@Service
public class ClientSecretVaultService implements VaultService {

    @Override
    public VaultClient getAuthenticatedClient() {
        // Auth with clientId + clientSecret
        return new VaultClient();
    }

    @Override
    public String getSecret(String key) {
        // Stub
        return "secret-from-clientsecret";
    }

    @Override
    public byte[] getCertificate(String certName) {
        // Stub
        return new byte[0];
    }
}