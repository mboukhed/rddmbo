package com.example.vault;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile("managed")
@Service
public class ManagedIdentityVaultService implements VaultService {

    @Override
    public VaultClient getAuthenticatedClient() {
        // Auth with managed identity
        return new VaultClient();
    }

    @Override
    public String getSecret(String key) {
        return "secret-from-managed-identity";
    }

    @Override
    public byte[] getCertificate(String certName) {
        return new byte[0];
    }
}