package com.example.vault;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Profile("userpass")
@Service
public class UsernamePasswordVaultService implements VaultService {

    @Override
    public VaultClient getAuthenticatedClient() {
        // Auth with username + password
        return new VaultClient();
    }

    @Override
    public String getSecret(String key) {
        return "secret-from-userpass";
    }

    @Override
    public byte[] getCertificate(String certName) {
        return new byte[0];
    }
}