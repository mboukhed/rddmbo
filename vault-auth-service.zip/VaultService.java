package com.example.vault;

public interface VaultService {
    VaultClient getAuthenticatedClient();
    String getSecret(String key);
    byte[] getCertificate(String certName);
}