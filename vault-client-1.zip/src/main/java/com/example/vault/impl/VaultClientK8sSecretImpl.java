package com.example.vault.impl;

import com.example.vault.VaultClient;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

@Component
@Profile("vault-k8s-secret")
public class VaultClientK8sSecretImpl implements VaultClient {

    @Override
    public Optional<String> getSecret(String path) {
        return Optional.of("k8s-secret-secret-for-" + path);
    }

    @Override
    public Optional<Map<String, String>> getSecretMap(String path) {
        return Optional.of(Map.of("key", "k8s-secret-value", "path", path));
    }

    @Override
    public Optional<String> getCertificate(String path) {
        return Optional.of("k8s-secret-certificate-base64-for-" + path);
    }

    @Override
    public Optional<byte[]> getBinary(String path) {
        return Optional.of(("k8s-secret-binary-content-for-" + path).getBytes());
    }

    @Override
    public Optional<String> getStructuredSecret(String path) {
        return Optional.of("{\"secret\": \"k8s-secret-structured\", \"path\": \"" + path + "\"}");
    }

    @Override
    public boolean isAvailable() {
        return true;
    }
}
