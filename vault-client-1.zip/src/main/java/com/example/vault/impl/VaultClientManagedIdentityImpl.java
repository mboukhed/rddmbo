package com.example.vault.impl;

import com.example.vault.VaultClient;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

@Component
@Profile("vault-managed-identity")
public class VaultClientManagedIdentityImpl implements VaultClient {

    @Override
    public Optional<String> getSecret(String path) {
        return Optional.of("managed-identity-secret-for-" + path);
    }

    @Override
    public Optional<Map<String, String>> getSecretMap(String path) {
        return Optional.of(Map.of("key", "managed-identity-value", "path", path));
    }

    @Override
    public Optional<String> getCertificate(String path) {
        return Optional.of("managed-identity-certificate-base64-for-" + path);
    }

    @Override
    public Optional<byte[]> getBinary(String path) {
        return Optional.of(("managed-identity-binary-content-for-" + path).getBytes());
    }

    @Override
    public Optional<String> getStructuredSecret(String path) {
        return Optional.of("{\"secret\": \"managed-identity-structured\", \"path\": \"" + path + "\"}");
    }

    @Override
    public boolean isAvailable() {
        return true;
    }
}
