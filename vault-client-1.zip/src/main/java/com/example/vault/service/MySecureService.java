package com.example.vault.service;

import com.example.vault.VaultClient;
import org.springframework.stereotype.Service;

@Service
public class MySecureService {

    private final VaultClient vaultClient;

    public MySecureService(VaultClient vaultClient) {
        this.vaultClient = vaultClient;
    }

    public void doSecureThing() {
        String secret = vaultClient.getSecret("myapp/secure/data").orElse("not found");
        System.out.println("Vault secret = " + secret);
    }
}
