package com.example.vault.impl;

import com.example.vault.VaultClient;
import com.azure.identity.ClientCertificateCredential;
import com.azure.identity.ClientCertificateCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.*;

@Component
@Profile("certificate")
public class CertificateVaultClient implements VaultClient {
    private final SecretClient secretClient;

    public CertificateVaultClient(@Value("${vault.url}") String vaultUrl,
                                  @Value("${vault.client-id}") String clientId,
                                  @Value("${vault.tenant-id}") String tenantId,
                                  @Value("${vault.certificate-path}") String certPath,
                                  @Value("${vault.certificate-password:}") String certPassword) {
        ClientCertificateCredential credential = new ClientCertificateCredentialBuilder()
                .clientId(clientId).tenantId(tenantId).pfxCertificate(new File(certPath))
                .pfxCertificatePassword(certPassword.isEmpty() ? null : certPassword).build();

        this.secretClient = new SecretClientBuilder().vaultUrl(vaultUrl).credential(credential).buildClient();
    }

    @Override public Optional<String> getSecret(String path) {
        try { return Optional.of(secretClient.getSecret(path).getValue()); } catch (Exception e) { return Optional.empty(); }
    }
    @Override public Optional<Map<String, String>> getSecretMap(String path) {
        try { return Optional.of(parseJsonToMap(secretClient.getSecret(path).getValue())); } catch (Exception e) { return Optional.empty(); }
    }
    @Override public Optional<String> getCertificate(String path) { return getSecret(path); }
    @Override public Optional<byte[]> getBinary(String path) { return getSecret(path).map(Base64.getDecoder()::decode); }
    @Override public Optional<String> getStructuredSecret(String path) { return getSecret(path); }
    @Override public boolean isAvailable() {
        try { secretClient.getVaultUrl(); return true; } catch (Exception e) { return false; }
    }
    private Map<String, String> parseJsonToMap(String json) {
        Map<String, String> map = new HashMap<>();
        json = json.trim().replaceAll("[{}"]", "");
        for (String entry : json.split(",")) {
            String[] kv = entry.split(":", 2);
            if (kv.length == 2) map.put(kv[0].trim(), kv[1].trim());
        }
        return map;
    }
}
