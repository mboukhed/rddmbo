package com.example.vault;

import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

@Service
public class ManagedIdentityVaultClient implements VaultClient {
    private static final String METADATA_URL =
        "http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net";
    private static final String VAULT_BASE_URL = System.getenv("VAULT_URL");

    private Optional<String> getAccessToken() {
        try {
            URL url = new URL(METADATA_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Metadata", "true");

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String body = reader.lines().reduce("", (a, b) -> a + b);
                int tokenStart = body.indexOf("access_token") + 15;
                int tokenEnd = body.indexOf(""", tokenStart);
                return Optional.of(body.substring(tokenStart, tokenEnd));
            }
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    private Optional<String> callVault(String path) {
        try {
            Optional<String> tokenOpt = getAccessToken();
            if (tokenOpt.isEmpty()) return Optional.empty();

            URL url = new URL(VAULT_BASE_URL + "/secrets/" + path + "?api-version=7.0");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Authorization", "Bearer " + tokenOpt.get());

            try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                return Optional.of(reader.lines().reduce("", (a, b) -> a + b));
            }
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public Optional<String> getSecret(String path) {
        return callVault(path);
    }

    public Optional<Map<String, String>> getSecretMap(String path) {
        return Optional.empty();
    }

    public Optional<String> getCertificate(String path) {
        return Optional.empty();
    }

    public Optional<byte[]> getBinary(String path) {
        return Optional.empty();
    }

    public Optional<String> getStructuredSecret(String path) {
        return callVault(path);
    }

    public boolean isAvailable() {
        return getAccessToken().isPresent();
    }
}