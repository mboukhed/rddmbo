package com.example.vault;

import java.util.Map;
import java.util.Optional;

public interface VaultClient {
    Optional<String> getSecret(String path);
    Optional<Map<String, String>> getSecretMap(String path);
    Optional<String> getCertificate(String path);
    Optional<byte[]> getBinary(String path);
    Optional<String> getStructuredSecret(String path);
    boolean isAvailable();
}