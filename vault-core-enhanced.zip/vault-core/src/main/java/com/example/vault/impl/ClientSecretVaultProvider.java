package com.example.vault.impl;

import com.example.vault.CachingVaultSecretProvider;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Optional;
import java.util.logging.Logger;

@Component
@Profile("client-secret")
public class ClientSecretVaultProvider extends CachingVaultSecretProvider {

    private static final Logger logger = Logger.getLogger(ClientSecretVaultProvider.class.getName());

    private final String clientId;
    private final String clientSecret;
    private final String tenantId;
    private final String vaultUrl;

    public ClientSecretVaultProvider(
        @Value("${vault.client-id}") String clientId,
        @Value("${vault.client-secret}") String clientSecret,
        @Value("${vault.tenant-id}") String tenantId,
        @Value("${vault.url}") String vaultUrl,
        @Value("${vault.cache.enabled:true}") boolean cacheEnabled,
        @Value("${vault.cache.ttl:300}") long ttlSeconds
    ) {
        super(cacheEnabled, ttlSeconds);
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.tenantId = tenantId;
        this.vaultUrl = vaultUrl;
    }

    @Override
    protected Optional<String> fetchSecret(String secretName) {
        try {
            String token = fetchAccessToken();
            String url = vaultUrl + "/secrets/" + secretName + "?api-version=7.4";
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + token);

            int code = conn.getResponseCode();
            if (code == 200) {
                String json = readAll(conn.getInputStream());
                JSONObject obj = new JSONObject(json);
                return Optional.of(obj.getString("value"));
            } else {
                logger.warning("Erreur HTTP Vault: " + code);
            }
        } catch (Exception e) {
            logger.severe("Erreur accès Vault: " + e.getMessage());
        }
        return Optional.empty();
    }

    private String fetchAccessToken() throws IOException {
        String body = "grant_type=client_credentials" +
                      "&client_id=" + clientId +
                      "&client_secret=" + clientSecret +
                      "&resource=https%3A%2F%2Fvault.azure.net";

        URL url = new URL("https://login.microsoftonline.com/" + tenantId + "/oauth2/token");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.getOutputStream().write(body.getBytes());

        String json = readAll(conn.getInputStream());
        return new JSONObject(json).getString("access_token");
    }

    private String readAll(InputStream is) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(is))) {
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
            return json.toString();
        }
    }
}