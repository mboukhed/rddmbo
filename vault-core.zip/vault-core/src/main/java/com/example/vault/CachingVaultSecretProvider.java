package com.example.vault;

import java.time.Instant;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public abstract class CachingVaultSecretProvider implements VaultSecretProvider {

    private final boolean cacheEnabled;
    private final long ttlSeconds;
    private final Map<String, CachedSecret> cache = new ConcurrentHashMap<>();

    public CachingVaultSecretProvider(boolean cacheEnabled, long ttlSeconds) {
        this.cacheEnabled = cacheEnabled;
        this.ttlSeconds = ttlSeconds;
    }

    @Override
    public Optional<String> getSecret(String secretName) {
        if (!cacheEnabled) {
            return fetchSecret(secretName);
        }

        CachedSecret cached = cache.get(secretName);
        if (cached != null && !cached.isExpired()) {
            return Optional.ofNullable(cached.value);
        }

        Optional<String> fresh = fetchSecret(secretName);
        fresh.ifPresent(val -> cache.put(secretName, new CachedSecret(val, ttlSeconds)));
        return fresh;
    }

    protected abstract Optional<String> fetchSecret(String secretName);

    public void invalidate(String secretName) {
        cache.remove(secretName);
    }

    public void clearCache() {
        cache.clear();
    }

    private static class CachedSecret {
        final String value;
        final Instant expiresAt;

        CachedSecret(String value, long ttlSeconds) {
            this.value = value;
            if (ttlSeconds <= 0) {
                this.expiresAt = Instant.MAX;
            } else {
                this.expiresAt = Instant.now().plusSeconds(ttlSeconds);
            }
        }

        boolean isExpired() {
            return Instant.now().isAfter(expiresAt);
        }
    }
}