package com.example.vault;

import java.util.Optional;

public interface VaultSecretProvider {
    Optional<String> getSecret(String secretName);
}