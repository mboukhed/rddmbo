package com.example.vault.impl;

import com.example.vault.CachingVaultSecretProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Optional;
import java.io.*;

@Component
@Profile("managed")
public class ManagedIdentityVaultProvider extends CachingVaultSecretProvider {

    private final String vaultUrl;

    public ManagedIdentityVaultProvider(
        @Value("${vault.url}") String vaultUrl,
        @Value("${vault.cache.enabled:true}") boolean cacheEnabled,
        @Value("${vault.cache.ttl:300}") long ttlSeconds
    ) {
        super(cacheEnabled, ttlSeconds);
        this.vaultUrl = vaultUrl;
    }

    @Override
    protected Optional<String> fetchSecret(String secretName) {
        try {
            String token = fetchManagedIdentityToken();
            String url = vaultUrl + "/secrets/" + secretName + "?api-version=7.4";
            HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + token);

            if (conn.getResponseCode() == 200) {
                StringBuilder json = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) json.append(line);
                }
                return extractJsonField(json.toString(), "value");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    private String fetchManagedIdentityToken() throws IOException {
        URL url = new URL("http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://vault.azure.net");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestProperty("Metadata", "true");
        conn.setRequestMethod("GET");

        StringBuilder json = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) json.append(line);
        }

        return extractJsonField(json.toString(), "access_token").orElseThrow();
    }

    private Optional<String> extractJsonField(String json, String field) {
        int idx = json.indexOf(""" + field + "":"");
        if (idx < 0) return Optional.empty();
        int start = idx + field.length() + 4;
        int end = json.indexOf(""", start);
        return Optional.of(json.substring(start, end));
    }
}