package com.example.vault.impl;

import com.example.vault.VaultClient;

import java.util.Map;
import java.util.Optional;

public class ClientSecretVaultClient extends HttpVaultClientSupport implements VaultClient {

    public ClientSecretVaultClient(String vaultUrl, String token) {
        super(vaultUrl, token);
    }

    @Override
    public Optional<String> getSecret(String path) {
        try {
            String json = sendGet("/v1/" + path);
            Map<String, String> map = SimpleJsonParser.parseFlatJson(json);
            return Optional.ofNullable(map.get("value"));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    @Override
    public Optional<Map<String, String>> getSecretMap(String path) {
        try {
            String json = sendGet("/v1/" + path);
            return Optional.of(SimpleJsonParser.parseFlatJson(json));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    @Override
    public Optional<String> getCertificate(String path) {
        return getSecret(path);
    }

    @Override
    public Optional<byte[]> getBinary(String path) {
        return getSecret(path).map(String::getBytes);
    }

    @Override
    public Optional<String> getStructuredSecret(String path) {
        return getSecret(path);
    }

    @Override
    public boolean isAvailable() {
        try {
            sendGet("/v1/sys/health");
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}