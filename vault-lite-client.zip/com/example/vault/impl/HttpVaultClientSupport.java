package com.example.vault.impl;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpVaultClientSupport {

    protected String vaultUrl;
    protected String vaultToken;

    public HttpVaultClientSupport(String vaultUrl, String vaultToken) {
        this.vaultUrl = vaultUrl;
        this.vaultToken = vaultToken;
    }

    protected String sendGet(String endpoint) throws IOException {
        URL url = new URL(vaultUrl + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setRequestProperty("X-Vault-Token", vaultToken);
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
                response.append(line);
            return response.toString();
        }
    }

    protected String sendPost(String endpoint, String jsonPayload) throws IOException {
        URL url = new URL(vaultUrl + endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("X-Vault-Token", vaultToken);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(jsonPayload.getBytes());
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null)
                response.append(line);
            return response.toString();
        }
    }
}