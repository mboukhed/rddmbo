package com.example.vault.impl;

import java.util.HashMap;
import java.util.Map;

public class SimpleJsonParser {

    public static Map<String, String> parseFlatJson(String json) {
        Map<String, String> map = new HashMap<>();
        json = json.trim();
        if (json.startsWith("{")) json = json.substring(1);
        if (json.endsWith("}")) json = json.substring(0, json.length() - 1);

        String[] pairs = json.split(",");
        for (String pair : pairs) {
            String[] kv = pair.split(":", 2);
            if (kv.length == 2) {
                String key = kv[0].trim().replaceAll("^[\"]|[\"]$", "");
                String value = kv[1].trim().replaceAll("^[\"]|[\"]$", "");
                map.put(key, value);
            }
        }
        return map;
    }
}