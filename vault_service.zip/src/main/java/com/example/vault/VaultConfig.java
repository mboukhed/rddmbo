package com.example.vault;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.vault.authentication.TokenAuthentication;
import org.springframework.vault.client.VaultEndpoint;
import org.springframework.vault.core.env.VaultPropertySource;
import org.springframework.vault.core.env.VaultPropertySources;
import org.springframework.vault.config.AbstractVaultConfiguration;

import java.net.URI;

@Configuration
@Profile("vault")
public class VaultConfig extends AbstractVaultConfiguration {

    @Value("${vault.uri}")
    private URI vaultUri;

    @Value("${vault.token}")
    private String vaultToken;

    @Override
    public VaultEndpoint vaultEndpoint() {
        return VaultEndpoint.from(vaultUri);
    }

    @Override
    public org.springframework.vault.authentication.ClientAuthentication clientAuthentication() {
        return new TokenAuthentication(vaultToken);
    }
}
