package com.example.vault;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.vault.core.VaultTemplate;
import org.springframework.vault.support.VaultResponse;

import java.util.Map;

@Service
@Profile("vault")
public class VaultConnectionService {

    private final VaultTemplate vaultTemplate;

    @Autowired
    public VaultConnectionService(VaultTemplate vaultTemplate) {
        this.vaultTemplate = vaultTemplate;
    }

    public String getClientId() {
        return readSecret("secret/application", "clientId");
    }

    public String getClientSecret() {
        return readSecret("secret/application", "clientSecret");
    }

    public String getTenantId() {
        return readSecret("secret/application", "tenantId");
    }

    private String readSecret(String path, String key) {
        VaultResponse response = vaultTemplate.read(path);
        if (response == null || response.getData() == null) {
            throw new IllegalStateException("Secret not found at path: " + path);
        }
        Map<String, Object> data = response.getData();
        Object value = data.get(key);
        if (value == null) {
            throw new IllegalStateException("Key not found in Vault secret: " + key);
        }
        return value.toString();
    }
}
