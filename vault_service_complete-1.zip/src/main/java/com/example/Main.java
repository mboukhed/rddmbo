package com.example;

import com.example.vault.VaultSimpleService;
import com.example.vault.AppConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) throws Exception {
        System.setProperty("vault.uri", "http://localhost:8200");
        System.setProperty("vault.token", "s.votreTokenIci");

        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        VaultSimpleService vaultService = context.getBean(VaultSimpleService.class);

        String clientId = vaultService.getClientId();
        String clientSecret = vaultService.getClientSecret();
        String tenantId = vaultService.getTenantId();

        System.out.println("Client ID: " + clientId);
        System.out.println("Client Secret: " + clientSecret);
        System.out.println("Tenant ID: " + tenantId);

        context.close();
    }
}
