
public interface WorkflowProcessor {

    default void applyWorkflow() {
        applyWorkflow(getDefaultWorkflow());
    }

    void applyWorkflow(Object workflow);

    default Object getDefaultWorkflow() {
        return java.util.Map.of("defaultStep", "start");
    }
}
