
import java.util.List;
import java.util.Map;

public class WorkflowProcessorImpl implements WorkflowProcessor {

    @Override
    public void applyWorkflow(Object workflow) {
        if (workflow instanceof String str) {
            if (str.trim().startsWith("{")) {
                applyJson(str);
            } else if (str.trim().startsWith("<")) {
                applyXml(str);
            } else {
                throw new IllegalArgumentException("Format string inconnu");
            }
        } else if (workflow instanceof List<?>) {
            applyList((List<?>) workflow);
        } else if (workflow instanceof Map<?, ?>) {
            applyMap((Map<?, ?>) workflow);
        } else {
            throw new IllegalArgumentException("Type non supporté : " + workflow.getClass());
        }
    }

    private void applyJson(String json) { System.out.println("Apply JSON: " + json); }
    private void applyXml(String xml) { System.out.println("Apply XML: " + xml); }
    private void applyList(List<?> steps) { System.out.println("Apply List: " + steps); }
    private void applyMap(Map<?, ?> map) { System.out.println("Apply Map: " + map); }
}
